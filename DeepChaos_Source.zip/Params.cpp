//---------------------------------------------------------------------------
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"

//---------------------------------------------------------------------------

TMainParams::TMainParams()
{
	ColorBarData.Level = 0;
	ColorBarData.Scala = 100;
	ColorBarData.ScalaLogPoint = 0;
	ColorBarData.LogFaktor = 1;

	ColorBarData.ColorTabelle[0].pos = 0;       				 // 0 -> ist f�r Level 0
	ColorBarData.ColorTabelle[0].color = 0x00FFFFFF;
	ColorBarData.ColorTabelle[0].isobreite = 0;
	ColorBarData.ColorTabelle[1].pos = COLORSMAX;			// Letzter[Index] ist f�r Max und Gr��er
	ColorBarData.ColorTabelle[1].color = 0x00000000;
	ColorBarData.ColorTabelle[1].isobreite = 0;

	MaxIter = 100;					// Anzahl - Erstellungsgrenzen
	VorlaufIter = 0;            		// Vorlauf
	ZusatzMode = 0;             		// "Anzeige mit:" On-Off Flags
	Erstellungsdauer = 0;       		// in Sekunden
	ItercountMax = 0;
	ItercountMin = 100; 				// Tats�chlich erreichte Iterationen
	RepeatJede = 1;                 	// Nur jede xte Iteration Zeigen
	BildSizeX = 150;					// Bildbreite in Pixel
	BildSizeY = 100;					// Bildh�he in Pixel
	BezierpX = 75;
	BezierpY = 50;
	Amode = 0;		  			// Anzeigemode
	Mmode = 0;  				// Menge-Art
	Emode = 0;					// Erstellungsmode
	EmodeNr = 0;				// ErstellungsNummer f�r Auswertungart
	ErstArt = 0;				// Erstellungsrechenart
	Rmode = 10;					// Rechengenauigkeit in Anz Bit ( 32 Bit Steps )
	BmodeR = 0;					// bei Ergebnisort: Referenz-Fl�che
	RelativM = 0;				// bei Z-Absolut: 	Relativmode
	RefSizeX = 111;             // bei Ergebnisort: Aufl�sungsfaktor  1 ... n
	BmodeB = 3;                 // bei Ergebnisort: Bereich ( Inside-Outside-Beide )
	AFBilder = 1;				// Anzahl Film Bilder
	ViewAngle = 1.0;            // Orbit sicht
	cx = 0;
	cy = 0;			        	// Bild Zentrum Koordinaten
	rx = 0;
	ry = 0;						// Referenz Zentrum f�r Ergebnisort
	jpx = 0;
	jpy = 0;                	// Julia Punkt
	tpx = 0;
	tpy = 0;                	// Test Punkt
	lsx = 0;
	lsy = 0;			    	// Linienstartpunkt
	lex = 0;
	ley = 0;					// Linienendpunkt
	zcx = 0;
	zcy = 0;					// letztes Zoomcenter
	imagx = 1.0;
	imagy = 0.0;				// Imagin�rpunkt f�r grafic-Berechnung
	BildSize = 3,6;				// Bildbreite
	ZoomSize = 1.0;				// Zoombreite
	RefSize = 4,01;				// Referenzbildbreite
	MaxRadius = 2.0;
	InnerMin = 0.0;
	InnerMax = 2.0;
	OuterMin = 2.0;
	OuterMax = 1e10;
	Zscala = 100;				// Farbenparameter
	Zlevel = 0;
	EmodeZusatz = 0;			// Zusatzparameter f�r Auswertungart ( Grenzwert )
	RefBildSV = 1;              // ReferenzBild Seitenverh�ltnis ( x / y = RefBildSV )
	isCycleZoom = false;	   	// true wenn zoom is Cycle
	isRefCycle = false;
	isOversamle = false;
	CTFile[0] = 0;
	BMFile[0] = 0;
	RBFile[0] = 0;

}
//---------------------------------------------------------------------------

TMainParams::~TMainParams()
{
}
//---------------------------------------------------------------------------

bigint* TMainParams::ParGetBigIntAdr( int nr )
{

switch ( nr )
	{
	case 0: return(&cx);     		// Achtung: Tabelle "BigIntEd" in DCWd synchron mit Parametern halten!!!!!!
	case 1: return(&cy);
	case 2: return(&rx);
	case 3: return(&ry);
	case 4: return(&jpx);
	case 5: return(&jpy);
	case 6: return(&tpx);
	case 7: return(&tpy);
	case 8: return(&lsx);
	case 9: return(&lsy);
	case 10: return(&lex);
	case 11: return(&ley);
	case 12: return(&zcx);
	case 13: return(&zcy);
	case 14: return(&imagx);
	case 15: return(&imagy);
	case 16: return(&refpx);
	case 17: return(&refpy);
	}
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

