//---------------------------------------------------------------------
#include <vcl.h>

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "BildForm.h"
#include "OrbitAnalyse.h"
#include "PhasenAnalyse.h"
#include "HelpForm.h"
#include "DatenBankForm.h"
#include "ZeitReihe.h"
#include "Animation.h"
#include <tchar.h>

#pragma hdrstop
//---------------------------------------------------------------------
USEFORM("PhasenAnalyse.cpp", PhasenWd);
USEFORM("OrbitAnalyse.cpp", OrbitWd);
USEFORM("HelpForm.cpp", HelpWd);
USEFORM("DatenBankForm.cpp", DbWd);
USEFORM("ZeitReihe.cpp", ZeitRWd);
USEFORM("ColorSelect.cpp", ColorsSelect);
USEFORM("ColorBar.cpp", ColorBarWd);
USEFORM("BildForm.cpp", BildWd);
USEFORM("ABOUT.CPP", AboutBox);
USEFORM("DCMAIN.CPP", DCWd);
USEFORM("Animation.cpp", AnimationWd);
//---------------------------------------------------------------------------
WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
		Application->Initialize();
		Application->Title = "DeepChaosV3";
		Application->CreateForm(__classid(TDCWd), &DCWd);
		Application->CreateForm(__classid(TAboutBox), &AboutBox);
		Application->CreateForm(__classid(TColorsSelect), &ColorsSelect);
		Application->CreateForm(__classid(THelpWd), &HelpWd);
		Application->CreateForm(__classid(TDbWd), &DbWd);
		Application->CreateForm(__classid(TPhasenWd), &PhasenWd);
		Application->CreateForm(__classid(TZeitRWd), &ZeitRWd);
		Application->CreateForm(__classid(TAnimationWd), &AnimationWd);
		Application->CreateForm(__classid(TAnimationWd), &AnimationWd);
		Application->ShowHint = true;
		Application->Run();
/*
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
*/
	return 0;
}
//---------------------------------------------------------------------

