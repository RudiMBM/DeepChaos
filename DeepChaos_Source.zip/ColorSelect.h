//----------------------------------------------------------------------------
#ifndef ColorSelectH
#define ColorSelectH
//----------------------------------------------------------------------------
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
#include <ComCtrls.hpp>
//----------------------------------------------------------------------------
class TColorsSelect : public TForm
{
__published:
	TButton *OKBtn;
	TButton *CancelBtn;
	TImage *ColorField;
	TLabel *NewColor;
	TEdit *IsoBreite;
	TLabel *Label1;
	TBevel *Bevel1;
	TBevel *Bevel2;
	TLabel *OldColor;
	TTrackBar *ThirtColor;
	TRadioGroup *ModellSelect;
	TPanel *Panel1;
	TPanel *Panel2;
	TPanel *Panel3;
	TPanel *Panel4;
	TPanel *Panel5;
	TPanel *Panel6;
	TPanel *Panel7;
	TPanel *Panel8;
	TImage *acz;
	TImage *acy;
	TImage *acx;
	TPanel *Panel10;
	TPanel *Panel11;
	TPanel *Panel12;
	TPanel *Panel13;
	TPanel *Panel14;
	TPanel *Panel16;
	TPanel *Panel17;
	TPanel *Panel18;
	TPanel *Panel19;
	TPanel *Panel15;
	TPanel *Panel21;
	TPanel *Panel22;
	TPanel *Panel23;
	TPanel *Panel24;
	TPanel *Panel25;
	TPanel *Panel26;
	TPanel *Panel27;
	TPanel *Panel28;
	TPanel *Panel29;
	TPanel *Panel31;
	TPanel *Panel32;
	TPanel *Panel33;
	TPanel *Panel34;
	TPanel *Panel35;
	TPanel *Panel39;
	TPanel *Panel46;
	TPanel *Panel47;
	TPanel *Panel48;
	TPanel *Panel49;
	TPanel *Panel50;
	TPanel *Panel51;
	TPanel *Panel52;
	TPanel *Panel53;
	TPanel *Panel54;
	TPanel *Panel55;
	TPanel *Panel56;
	TPanel *Panel57;
	TPanel *Panel58;
	TPanel *Panel59;
	TPanel *Panel62;
	TPanel *Panel60;
	TPanel *Panel61;
	TPanel *Panel63;
	TPanel *Panel64;
	TPanel *Panel65;
	TPanel *Panel66;
	TPanel *Panel68;
	TPanel *Panel69;
	TPanel *Panel70;
	TPanel *Panel71;
	TPanel *Panel72;
	TPanel *Panel73;
	TPanel *Panel74;
	TBevel *Bevel3;
	TLabel *Label2;
	TEdit *AktPos;
    TPanel *Panel76;
    TPanel *Panel77;
    TPanel *Panel78;
	TLabel *HexRotLb;
	TLabel *HexGr�nLb;
	TLabel *HexBlauLb;
	TLabel *Label3;
	TEdit *RotEd;
	TLabel *Label4;
	TEdit *GruenEd;
	TLabel *Label5;
	TEdit *BlauEd;
	TTrackBar *HelligkeitTB;
	TLabel *Label6;
	TBevel *Bevel4;
	TLabel *Label7;
	TEdit *FarbTabNrEd;
	void __fastcall PaintColorField(TObject *Sender);
	void __fastcall ColorFieldMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
	void __fastcall PanelClick(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall RotEdChange(TObject *Sender);
	void __fastcall FarbTabNrEdKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall OKBtnClick(TObject *Sender);

private:
	int		isobreiteOld;
public:
	virtual __fastcall TColorsSelect(TComponent* AOwner);

	int		newpos;
	int		MaxTabs;			//aktuell letzter belegter Farbtabplatz
};
//----------------------------------------------------------------------------
extern PACKAGE TColorsSelect *ColorsSelect;
//----------------------------------------------------------------------------
#endif    
