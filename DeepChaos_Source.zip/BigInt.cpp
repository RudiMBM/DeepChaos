#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "BigInt.h"


String	biERRORtext[] = {	"bigintERROR_ok",
							"bigintERRORdiv0",
							"bigintERRORovfl",
							"bigintERRORexov",
							"bigintERRORinperr",
							"bigintERRORleer",
							"bigintERRORsizing",
							"bigintERRORcontinue",
							"bigintERRORsign",
							"???" };
/*
int		BigIntPraez = KOMMADIGITS;  // = KOMMADIGITS;
int		BIP,BIPm,BIPm1,BIPa,BIPa1,BIPaz;
*/

bigint  maxRange;
int		GlobNachKommaStellen = KOMMADIGITS * WDIGITSST;

//---------------------------------------------------------------------------

bigint::bigint()
{
int	i;

vzpm = 1;
error = biERRORleer;
Laenge = ANZDIGITS;   			//  !!!!!! Flexible Laufzeitsize noch nicht vollst�ndig durchzogen !!!!!
Kommastellen = KOMMADIGITS;
}
//---------------------------------------------------------------------------

bigint::bigint(int n)
{
int	i,nn;

for ( i=0; i<ANZDIGITS; i++ )
	ea[i] = 0;
ea[ANZDIGITS-KOMMADIGITS-1] = ::abs(n);
vzpm = 1;
if ( n < 0 )
	vzpm = -1;
Laenge = ANZDIGITS;
Kommastellen = KOMMADIGITS;
error = biERROR_ok;
}
//---------------------------------------------------------------------------

void bigint::setSize(short L, short K)
{
int		i;

if ( error != biERRORleer )
	for ( i=0; i<Laenge; i++ )  	// nur bei Inhalt = 0 anwenden !
		if ( ea[i] != 0 )
			{
			error = biERRORsizing;
			return;
			}
Laenge = ((L+K) > ANZDIGITS)?ANZDIGITS:(L+K);
Kommastellen = ((L+K) > ANZDIGITS)?ANZDIGITS-L:K;
for ( i=0; i<Laenge; i++ )	// bei Vergr��erung l�schen
		ea[i] = 0;
vzpm = 1;
}
//---------------------------------------------------------------------------

void bigint::setBIP(int K)
{
/*                                  	//  !!!!!! Flexible Laufzeitsize noch nicht vollst�ndig durchzogen !!!!!
BigIntPraez = K - VORKOMMADIGITS;
BIP = BigIntPraez;
BIPm = ((VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez))*4;
BIPm1 = ((VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez)-1)*4;
BIPa = VORKOMMADIGITS + BigIntPraez;
BIPa1 = VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez;
BIPaz = (VORKOMMADIGITS + BigIntPraez)*2;
*/
}
//---------------------------------------------------------------------------

void bigint::setKommastellenAnzeige(int K)
{

if (( K < 1 )||( K > GlobNachKommaStellen ))
	{
	GlobNachKommaStellen = KOMMADIGITS * WDIGITSST;
	return;
	}
GlobNachKommaStellen = K;
}
//---------------------------------------------------------------------------

void bigint::setPraez(short K)
{
int		i;

for ( i=0; i<Laenge; i++ )  	// nur bei Inhalt = 0 anwenden !
	if ( ea[i] != 0 )
		{
		error = biERRORsizing;
		return;
		}
if ( K <= KOMMADIGITS )
	{
	if ( K > Kommastellen )
		for ( i=VORKOMMADIGITS+K; i<ANZDIGITS; i++ )	// bei Vergr��erung l�schen
			ea[i] = 0;
	Laenge = VORKOMMADIGITS + K;
	Kommastellen = K;
	}
else
	error = biERRORsizing;
}
//---------------------------------------------------------------------------

bigint bigint::operator=(const bigint& n)
{
int	s,d,l,sg,dg;

vzpm = 1;
s = 0;
d = 0;
sg = (Laenge - Kommastellen)-(n.Laenge - n.Kommastellen);
dg = (n.Laenge - n.Kommastellen)-(Laenge - Kommastellen);
while ( d < dg)
	ea[d++] = 0;
while ( s < sg)
	{
    if ( n.ea[s++] > 0 )
    	{
        error = biERRORovfl;
        return *this;
        }
    }
l = (n.Laenge < Laenge)?n.Laenge:Laenge;
while ( d < l )
	ea[d++] = n.ea[s++];
while ( d < Laenge )
	ea[d++] = 0;
vzpm = n.vzpm;
error = n.error;
return *this;
}
//---------------------------------------------------------------------------

bigint bigint::operator=(const long double& n)
{
int				d,l;
long double		nn;

nn = n;
if ( nn < 0 )
	{
    vzpm = -1;
    nn *= -1;
    }
else
    vzpm = 1;
d = 0;
while ( d < Laenge)												// bigint = 0
	ea[d++] = 0;
if ( nn > 0xffffffff )
	{
    error = biERRORinperr;
    return *this;
    }

d = ((Laenge - Kommastellen) - 1);
while ( d < Laenge )
	{
    if ( nn >= 1 )
    	{
        ea[d] = nn;								// ganzteiligen Wert �bernehmen
        nn -= ea[d];
        }
    nn *= 0x010000;
    nn *= 0x010000;
    d++;
    }

error = biERROR_ok;
return *this;
}
//---------------------------------------------------------------------------

bigint bigint::operator=(const int n)
{
signed long int		d,nn;

nn = n;
if ( nn < 0 )
	{
    vzpm = -1;
    nn *= -1;
    }
else
    vzpm = 1;
d = 0;
while ( d < Laenge)												// bigint = 0
	ea[d++] = 0;
ea[((Laenge - Kommastellen) - 1)] = nn;

error = biERROR_ok;
return *this;
}
//---------------------------------------------------------------------------

void bigint::addieren(unsigned *a,unsigned *b,unsigned *z)
{

_asm {
		xor		eax, eax				// CF = 0 !!
		mov		esi, a
		mov		edi, b
		mov		ebx, z
		movsx	ecx, [ebx].Laenge  	        	// Z�hler init
adduuu1:mov		eax, esi[ecx*4-4]
		adc		eax, edi[ecx*4-4]
		mov		ebx[ecx*4-4], eax
		loop	adduuu1
		}
}
//---------------------------------------------------------------------------

void bigint::subtrahieren(unsigned *a,unsigned *b,unsigned *z) 		// a - b = z
{

_asm {
		xor		eax, eax				// CF = 0 !!
		mov		esi, a
		mov		edi, b
		mov		ebx, z
		movsx	ecx, [ebx].Laenge  	        	// Z�hler init
subuuu1:mov		eax, esi[ecx*4-4]
		sbb		eax, edi[ecx*4-4]
		mov		ebx[ecx*4-4], eax
		loop	subuuu1
		}
}
//---------------------------------------------------------------------------

bigint bigint::operator+(const bigint& n)
{
bigint		ee;

ee = *this;
ee += n;
return ee;
}
//---------------------------------------------------------------------------

bigint bigint::operator-(const bigint& n)
{
bigint		ee;

ee = *this;
ee -= n;
return ee;
}
//---------------------------------------------------------------------------

void bigint::operator+=(const bigint& n)
{
unsigned	e,f,*eaa,*neaa;
int			i,s;

if ( error == biERROR_ok ) if ( n.error != biERROR_ok ) error = n.error;
if ( error != biERROR_ok ) return;

eaa = (unsigned*)&ea;
neaa = (unsigned*)&n.ea;

if ( vzpm == n.vzpm )
	{
	addieren(eaa,neaa,eaa);
	}
else
	{
	s = 0;
	i = 0;
	while ( i<ANZDIGITS && s==0 )
		{
		e = ea[i];
		f = n.ea[i];
		i++;
		if ( e > f )
			{
			s = 1;
			subtrahieren(eaa,neaa,eaa);
			}
		else if ( e < f )
			{
			s = -1;
			subtrahieren(neaa,eaa,eaa);
			vzpm = n.vzpm;
			}
		}
	if ( s == 0 )
		{
		//	for ( i=0; i<Laenge; i++ ) ea[i] = 0;
_asm {
            mov		edi, eaa
			movsx 	ecx, [edi].Laenge
            xor		eax, eax
plusist:	mov		edi[ecx*4-4], eax
			loop	plusist
}
		vzpm = 1;
		}
	}
}
//---------------------------------------------------------------------------

void bigint::operator-=(const bigint& n)
{
unsigned	e,ne,*eaa,*neaa;
int			i,s;

if ( error == biERROR_ok ) if ( n.error != biERROR_ok ) error = n.error;
if ( error != biERROR_ok ) return;

eaa = (unsigned*)&ea;
neaa = (unsigned*)&n.ea;

if ( vzpm != n.vzpm )
	{
	addieren(eaa,neaa,eaa);
	}
else
	{
	s = 0;
	i = 0;
	while ( i<ANZDIGITS && s==0 )
		{
		e = ea[i];
		ne = n.ea[i];
		i++;
		if ( e > ne )
			{
			s = 1;
			subtrahieren(eaa,neaa,eaa);
			}
		else if ( e < ne )
			{
			s = -1;
			subtrahieren(neaa,eaa,eaa);
			vzpm = n.vzpm * -1;
			}
		}
	if ( s == 0 )
		{
		//	for ( i=0; i<Laenge; i++ ) ea[i] = 0;
_asm {
			mov		edi, eaa
			movsx	ecx,[edi].Laenge
			xor		eax, eax
minist:		mov		edi[ecx*4-4], eax
			loop	minist
}
		vzpm = 1;
		}
	}
}
//---------------------------------------------------------------------------

bigint bigint::operator*(const bigint& n)
{
bigint		ee;
unsigned	zs[ANZDIGITSZR];	// Zwischenergebnis
int			g,z,zw;
int			i,j,k;
unsigned  	*zsp,*zspe,*eape,*eap,*np,*npe;

ee.error = biERROR_ok;
if ( error == biERROR_ok ) if ( n.error != biERROR_ok ) error = n.error;
if ( error != biERROR_ok )
	{
	ee.error = error;
	return ee;
	}

for ( i=0; i<ANZDIGITSZR; i++ )
	zs[i] = 0;

eap = (unsigned *)&ea[0];
eape = (unsigned *)&ea[Laenge-1];
np = (unsigned *)&n.ea[Laenge-1];
npe = (unsigned *)&n.ea[0];
zsp = (unsigned *)&zs[Laenge];

										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// EBP: BasePointer lokale Varibalen
										// ECX: Pointer ZS[]
										// ESI:	Pointer ea[]
										// EDI:	Pointer n.ea[]
_asm {
		mov		esi, eap
mile0:	mov		edi, np			// ea[] - loop
		mov		ecx, zsp
		add		zsp, 4
		xor		ebx, ebx		// g = 0
mile1:	mov		eax, [esi]      // n.ea[] - loop
		mul		[edi]
		add		eax, ebx
		mov		ebx, 0x0  		// g = 0;  CF unver�ndert !
		adc		ebx, 0x0
		add 	eax, [ecx]
		adc 	ebx, 0x0		// noch nicht ge�ndert ?????????
		mov     [ecx], eax
		add		ebx, edx
		sub		ecx, 4
		sub		edi, 4
		cmp		edi, npe
		jnb		mile1
		add		[ecx], ebx
mile4:	add		esi, 4
		cmp		esi, eape
		jbe		mile0
	}
if ( zs[Laenge-Kommastellen-1] != 0 )
	{
	ee.error = biERRORovfl;
	return ee;
	}

for ( i=0,j=Laenge-Kommastellen; i<Laenge; i++, j++ )		// Komma verschieben und speichern
	ee.ea[i] = zs[j];

if ( vzpm == n.vzpm )
	ee.vzpm = 1;
else
	ee.vzpm = -1;
return ee;
}
//---------------------------------------------------------------------------

void bigint::operator*=(const bigint& n)
{
unsigned	zs[ANZDIGITSZR];	// Zwischenergebnis
long		i,j,k;
unsigned	*zsp,*zspe,*eape,*eap,*np,*npe;

if ( error == biERROR_ok ) if ( n.error != biERROR_ok ) error = n.error;
if ( error != biERROR_ok ) return;
zsp = (unsigned *)&zs[0];							// Zwischenspeicher l�schen
eape = (unsigned *)&zs[Laenge + Laenge];
_asm {
			mov	eax,zsp
			xor edx,edx
	 back:	mov [eax],edx
			add	eax, 4
			cmp	eax,eape
			jb 	back
	 }

eap = (unsigned *)&ea[0];
eape = (unsigned *)&ea[Laenge-1];
np = (unsigned *)&n.ea[Laenge-1];
npe = (unsigned *)&n.ea[0];
zsp = (unsigned *)&zs[Laenge];

										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// EBP: BasePointer lokale Varibalen
										// ECX: Pointer ZS[]
										// ESI:	Pointer ea[]
										// EDI:	Pointer n.ea[]
_asm {
		mov		esi, eap
mil0:	mov		edi, np			// ea[] - loop
		mov		ecx, zsp
		add		zsp, 4
		xor		ebx, ebx		// ebx = g = 0
mil1:	mov		eax, [esi]      // acc = ea[x];          			n.ea[] - loop
		mul		[edi]           // edx,acc = acc * n.ea[x];
		add		eax, ebx        // acc += g;
		mov		ebx, 0x0  		// g = 0;  CF unver�ndert !
		adc		ebx, 0x0
		add 	eax, [ecx]
		adc 	ebx, edx
		mov     [ecx], eax
		sub		ecx, 4
		sub		edi, 4
		cmp		edi, npe
		jnb		mil1
		add		[ecx], ebx
mil4:	add		esi, 4
		cmp		esi, eape
		jbe		mil0
	}
if ( zs[Laenge-Kommastellen-1] != 0 )
	{
	error = biERRORovfl;
	return;
	}

eap = (unsigned *)&ea[0];              					// Komma verschieben und speichern
zsp = (unsigned *)&zs[Laenge-Kommastellen];
eape = (unsigned *)&ea[Laenge];

_asm {
			mov	eax,eap
			mov	edx,zsp
kvus:		mov ebx,[edx]
			mov [eax],ebx
			add	eax, 4
			add	edx, 4
			cmp	eax,eape
			jb 	kvus
	 }

if ( vzpm == n.vzpm )
	vzpm = 1;
else
	vzpm = -1;
if ( error == biERROR_ok )
	error = n.error;
}
//---------------------------------------------------------------------------
void bigint::mal2()
{
int			er;
unsigned	*eap,*eape;

er = biERROR_ok;
eap = &ea[0];
eape = &ea[Laenge-1];
_asm {
									//	esi	= ptr ea[0]
									//	edi	= ptr ea-end
			mov		edi, eape
			xor		eax,eax				// cf = 0    zieht von Rechts 0 rein   ( bei ohne Chaos )
/*
//          Dauert schei� langeeeeee !!!!!
            mov 	eax, [edi] 		// Periodische Bitkombinationen suchen f�r Chaos-Korrekte Rundung
            mov		esi, eax
            mov		ebx, [edi-4]
            mov		cl, 32
mal2p:      rcr		ebx, 1			// h�here Bits von links reinholen
			rcr		eax, 1			// Letztes Vergleichswort mit Original [edi]
			rcr		edx, 1			// Left Bit von edx am Schlu� wieder reinschieben
            cmp     eax, esi
            je		mal2p1
            loop	mal2p			// Falls in 32 Bits keine Periode gefunden wurde, ist CF zuf�llig !
mal2p1:		rcl		edx,1
*/
			mov		esi, eap
mal2b:		mov		eax, [edi]
			rcl		eax, 1
			mov		[edi], eax
			lahf
			sub		edi, 4
			cmp		edi, esi
			jb		mal2e
			sahf
			jmp		mal2b

mal2e:		sahf
			jnc		mal2ok
			mov		eax, biERRORovfl
			mov		er, eax
mal2ok:		nop
		}
error = er;
}
//---------------------------------------------------------------------------
void bigint::malXmal2( const bigint& n)
{
unsigned	zs[ANZDIGITSZR];	// Zwischenergebnis
long		k;
unsigned	*zsp,*zspe,*eape,*eap,*np,*npe;

if ( error == biERROR_ok ) if ( n.error != biERROR_ok ) error = n.error;
if ( error != biERROR_ok ) return;

_asm {
            lea		edx, [zs]
			xor 	eax,eax
            mov	   	ecx, ANZDIGITSZR
backx:		mov 	edx[ecx*4-4],eax
			loop	backx
	 }

eap = (unsigned *)&ea[0];
eape = (unsigned *)&ea[Laenge-1];
np = (unsigned *)&n.ea[Laenge-1];
npe = (unsigned *)&n.ea[0];
zsp = (unsigned *)&zs[Laenge];

										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// EBP: BasePointer lokale Varibalen
										// ECX: Pointer ZS[]
										// ESI:	Pointer ea[]
										// EDI:	Pointer n.ea[]
_asm {
		mov		esi, eap
mil0x:	mov		edi, np				// ea[] - loop
		mov		ecx, zsp
		add		zsp, 4
		xor		ebx, ebx			// ebx = g = 0
mil1x:	mov		eax, [esi]   	   	// acc = ea[x];          			n.ea[] - loop
		mul		[edi]        	   	// edx,acc = acc * n.ea[x];
		add		eax, ebx     	   	// acc += g;
		mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
		adc		ebx, 0x0
		add 	eax, [ecx]
		adc 	ebx, edx
		mov     [ecx], eax
		sub		ecx, 4
		sub		edi, 4
		cmp		edi, npe
		jnb		mil1x
		add		[ecx], ebx
mil4x:	add		esi, 4
		cmp		esi, eape
		jbe		mil0x
	}

if ( zs[Laenge-Kommastellen-1] != 0 )
	{
	error = biERRORovfl;
	return;
	}
                                    		// Zwischenergebnis chaosgerecht multiplizieren mit 2 durch shiften
eap = (unsigned *)&ea[0];					// oberste 2 Stellen werden eh' weggeschmissen
zsp = (unsigned *)&zs[Laenge-Kommastellen];	// Nur oberen Teil schieben + 1 Wort f�r Carry-In
k = error;
_asm {
									//	esi	= ptr ea[0]
									//	edi	= ptr ea-end
			mov		esi, zsp
			mov		edi, eap
            mov		edx, [ebp+8]
            movsx	ecx, [edx].Laenge
			mov		eax, esi[ecx*4]
            rcl		eax,1					// �bertrag holen
malx2b:		mov		eax, esi[ecx*4-4]
			rcl		eax, 1
			mov		edi[ecx*4-4], eax
            loop	malx2b
			jnc		malx2ok
			mov		eax, biERRORovfl
			mov		k, eax
malx2ok:	nop
		}
error = k;

if ( vzpm == n.vzpm )
	vzpm = 1;
else
	vzpm = -1;
if ( error == biERROR_ok )
	error = n.error;
}
//---------------------------------------------------------------------------
void bigint::div2()
{
int			er;
unsigned	*eap,*eape;

er = biERROR_ok;
eap = &ea[0];
eape = &ea[Laenge-1];
	_asm {
			mov		esi, eape
			mov		edi, eap
			xor		eax,eax			// cf = 0
div2b:		mov		eax, [edi]
			rcr		eax, 1
			mov		[edi], eax
			lahf
			add		edi, 4
			cmp		edi, esi
			jg		div2e
			sahf
			jmp		div2b

div2e:		nop
		}
error = er;
}
//---------------------------------------------------------------------------
void bigint::pwr2()
{
int 	i,d;

for ( i=ANZDIGITS-1; i>=0; i-- )                              /* TODO : Fertigmachen */
	{
	ea[i] = 0;
	}
}
//---------------------------------------------------------------------------
void bigint::sqrt()
{
long double		fsqrt;
bigint			d,r;
int				i;

if ( this->error != biERROR_ok ){
	zero();
	return;
	}
if ( isZero() )
	return;
fsqrt = Sqrt( *this );										// ungeaue Wurzel ermitteln
d = fsqrt;

for ( i=0; i<3; i++) {										// ergebnis mit Heron-Verfahren optimieren
	r = *this;
	r /= d;
	r += d;
	r.div2();
	d = r;
	}
*this = d;
}
//---------------------------------------------------------------------------
void bigint::bintrunc(const bigint& n)		// hinter erstem Bit von n alle bits in ea l�schen
{
unsigned	mask,m;
int			i;

i = 0;
while ( n.ea[i] == 0 )			// erste stelle suchen
	{
	i++;
	if (i >= Laenge)
		return;
	}
m = mask = n.ea[i];
while ( m > 1 )					// mask auff�llen
	{
	m >>= 1;
	mask |= m;
	}
mask ^= 0xFFFFFFFF;
ea[i] = ea[i] & mask; 			// halbwort mit maske l�schen
i++;
while ( i < Laenge )			// rest l�schen
	{
	ea[i] = 0;
	i++;
	}
}
//---------------------------------------------------------------------------

void bigint::operator*=(const int n)
{
unsigned	*eap,un,d,l;

un = ::abs(n);
eap = &ea[Laenge-1];
l = Laenge;
_asm {                         			// Mit Shiftoperatorfehler !!!
		mov		esi, eap
		xor		ecx, ecx
		mov		ebx, l
		xor		edx, edx
		xor		eax, eax
mulcl:	mov		eax, [esi]
		mul		un
		add		eax, ecx
		xor		ecx, ecx
		adc		ecx, 0
		mov		[esi], eax
		add		ecx, edx
		sub		esi, 4
		sub		ebx, 1
		jnz		mulcl
		mov		d, ecx
		}
if ( n < 0 ) vzpm *= -1;
if ( d != 0 ) error = biERRORovfl;
}
//---------------------------------------------------------------------------

void bigint::operator/=(const int n)
{
int		nn;

if ( n == 0 )
	error = biERRORdiv0;
else if ( n > 0x0ffff )
	{
    bigint	ln;

	ln = n;
    *this /= ln; 								// div bis 0x07fffffff
	//error = biERRORinperr;
    }
else
	zsdiv( (unsigned *)&ea, n, Laenge ); 		// div bis 0x0ffff
}
//---------------------------------------------------------------------------

void bigint::operator/=(const long double d)
{
long double	di;
int		li;

if ( d == 0 )
	error = biERRORdiv0;
else
	{
	if( fabsl(d) < 1.0 )
		{
		di = 1.0 / d;
		li = di;
		*this *= li;
		}
	else
		{
		li = d;
		*this /= li;
		}
	}
}
//---------------------------------------------------------------------------

void bigint::operator/=(const bigint &n)
{
bigint	ee;
bigint	dv;
bigint  th;
int		resultbit,resultindex,tsign;

ee = 0;
if ( n.is0() )
	error = biERRORdiv0;
if ( error ) return;

if ( vzpm == n.vzpm )
	tsign = 1;
else
	tsign = -1;

resultbit = 0x00000001;
resultindex = Laenge - Kommastellen - 1;
dv = n;
th = *this;
vzpm = dv.vzpm = +1;
while ( th > dv )				// linksschieben bis beide linksb�ndig
	{
    dv.mal2();
	resultbit <<= 1;
    if ( resultbit == 0 )
    	{
		resultbit = 0x00000001;
		resultindex -= 1;
		if ( resultindex < 0 )
        	{
            error = biERRORovfl;
            return;
            }
        }
    }
while ( resultindex < Laenge ) 		// incrementelles subtrahieren
	{
	if ( th >= dv )
    	{
		th -= dv;
        ee.ea[resultindex] |= resultbit;
        }
//	dv.div2();
	th.mal2();
   	resultbit >>= 1;
	resultbit &= 0x07FFFFFFF;
	if ( resultbit == 0 )
   		{
        resultbit = 0x080000000;
   	    resultindex += 1;
       	}
    }
*this = ee;
vzpm = tsign;
}
//---------------------------------------------------------------------------

bool   bigint::operator>(const int n)
{
unsigned	ee;
short		s,i;

if ( n < 0 )
	s = -1;
else
	s = 1;
ee = ::abs(n);

if ( vzpm == s )
	{
		if ((Laenge-Kommastellen)>1)
			for ( i=0; i<((Laenge-Kommastellen)-1); i++ )	// h�here Digits gr��er?
				if ( ea[i] > 0 )
					return ( vzpm == -1 );
		if ( ea[(Laenge-Kommastellen)-1] == ee )
        	{
			for ( i=(Laenge-Kommastellen); i<Laenge; i++ )	//noch Kommastellen vorhanden?
				if ( ea[i] > 0 )
					return true;
            return false;
            }
		if ( ea[(Laenge-Kommastellen)-1] < ee )
			return ( vzpm == -1 );
		return ( vzpm == 1 );
	}
else
	return ( vzpm == 1 );
}
//---------------------------------------------------------------------------

bool   bigint::operator>(const bigint& n)
{
int		i;

if ( vzpm == n.vzpm )
	{
	i = 0;
	do
		{
		if ( ea[i] > n.ea[i] )
			{
			if ( vzpm == 1 )
				return true;
			else
				return false;
			}
		if ( ea[i] < n.ea[i] )
			{
			if ( vzpm == 1 )
				return false;
			else
				return true;
			}
		i++;
		}
	while ( i < Laenge );
	}
else
	if ((vzpm == 1) && (n.vzpm == -1))
		return true;

return false;
}
//---------------------------------------------------------------------------

bool   bigint::operator<(const bigint& n)
{
int		i;

if ( vzpm == n.vzpm )
	{
	i = 0;
	do
		{
		if ( ea[i] < n.ea[i] )
			{
			if ( vzpm == 1 )
				return true;
			else
				return false;
			}
		if ( ea[i] > n.ea[i] )
			{
			if ( vzpm == 1 )
				return false;
			else
				return true;
			}
		i++;
		}
	while ( i < Laenge );
	}
else
	if ((vzpm == -1) && (n.vzpm == 1))
		return true;

return false;
}
//---------------------------------------------------------------------------

bool   bigint::operator>=(const bigint& n)
{
int		i;

if ( vzpm == n.vzpm )
	{
	i = 0;
	do
		{
		if ( ea[i] > n.ea[i] )
			{
			if ( vzpm == 1 )
				return true;
			else
				return false;
			}
		if ( ea[i] < n.ea[i] )
			{
			if ( vzpm == 1 )
				return false;
			else
				return true;
			}
		i++;
		}
	while ( i < Laenge );
	}
else
	if ((vzpm == 1) && (n.vzpm == -1))
		return true;
	else
		return false;

return true;
}
//---------------------------------------------------------------------------

bool   bigint::operator==(const bigint& n)
{
int		i;

if ( vzpm == n.vzpm )
	{
	i = 0;
	do
		{
		if ( ea[i] != n.ea[i] )
			{
			return false;
			}
		i++;
		}
	while ( i < Laenge );
	}
else
	return false;

return true;
}
//---------------------------------------------------------------------------

bool   bigint::isinMask(const bigint& n, const bigint& mask )
{
int		i;

if ( vzpm == n.vzpm )
	{
	i = 0;
	do
		{
		if ( (ea[i] & mask.ea[i]) != (n.ea[i] & mask.ea[i]) )
			{
			return false;
			}
		i++;
		}
	while ( i < Laenge );
	}
else
	return false;

return true;
}
//---------------------------------------------------------------------------

bool   bigint::is0() const
{
int	i;

for ( i=0; i<Laenge; i++ )
	if ( ea[i] != 0 )
    	return false;
return true;
}
//---------------------------------------------------------------------------

bool   bigint::isNeg()
{

if ( vzpm == -1 )
   return true;
return false;
}
//---------------------------------------------------------------------------

bool   bigint::isinRange()
{
int i;

i = 0;
while ( ea[i] == 0 )
    {
    i++;
    }
if ( i < ANZDIGITS-1 )
    return true;
if ( i == ANZDIGITS-1 )
    if ( ea[i] > 0x00FFFFFF )
        return true;
return false;
}
//---------------------------------------------------------------------------

void bigint::sizemask() 		// Erstellen einer Maske 0xfff...ff00....00 mit Wechsel bei h�chstwertiger Stelle
{
int			i,j;
unsigned	e;

i = 0;
while( i<Laenge & ea[i]==0 )
	ea[i++] = 0xffffffffffff;
e = ea[i];
_asm {
		mov		ecx,31
		mov		eax,e
sa:     bts     eax,ecx
		jc		sb
		dec		ecx
		jnz		sa
		jmp		sc

sb:		btr		eax,ecx
		dec		ecx
		jnz		sb
sc:		mov		e,eax
		}
ea[i] = e;
i++;
while( i<Laenge )
	ea[i++] = 0x0;
error = biMaske;
}
//---------------------------------------------------------------------------

bool bigint::isZero()
{
int	i;

if ( error != biERROR_ok )
	return false;
for ( i=0; i<Laenge; i++ )
	{
	if ( ea[i] != 0 )
		return false;
	}
return true;
}
//---------------------------------------------------------------------------

void bigint::zero()
{
int	i;

for ( i=Laenge-1; i>=0; i-- )
	{
	ea[i] = 0;
	}
vzpm = 1;
error = biERROR_ok;
}
//---------------------------------------------------------------------------

void bigint::neg()
{

vzpm *= -1;
error = biERROR_ok;
}
//---------------------------------------------------------------------------

void bigint::abs()
{

vzpm = +1;
error = biERROR_ok;
}
//---------------------------------------------------------------------------

int bigint::str2bighex(TEdit *an)
{
AnsiString	n;
int			i,dg,p;

n = an->Text;
if ( n[1] == '-' ) vzpm = -1; else vzpm = 1;
p = 3;
for ( dg=0; dg<Laenge-Kommastellen; dg++ )
		{
	    ea[dg] = StrToIntDef( "0x" + n.SubString(p,8), 0 );
        p += 9;
    	}
p += 1;
for ( ; dg<Laenge; dg++ )
		{
	    ea[dg] = StrToIntDef( "0x" + n.SubString(p,8), 0 );
        p += 9;
		}
return biERROR_ok;
}
//---------------------------------------------------------------------------

int bigint::bighex2str(TEdit *an, bool leadblank)
{
AnsiString	n;
int			i,dg;

if ( error != biERROR_ok )
	{
	n = biERRORtext[error];
	}
else {
	if ( vzpm == -1 ) n = n + "-"; else n = n + "+";
	for ( dg=0; dg<Laenge-Kommastellen; dg++ )
		{
	    n = n + " " + IntToHex((int)ea[dg],8);
    	}
	n = n + ",";
	for ( ; dg<Laenge; dg++ )
		{
	    n = n + " " + IntToHex((int)ea[dg],8);
    	}
    }

an->Text = n;
return error;
}
//---------------------------------------------------------------------------

int bigint::bighex2str(char *as, bool leadblank)
{
AnsiString	n;
int			i,dg;

if ( error != biERROR_ok )
	{
	n = biERRORtext[error];
	}
else {
	if ( vzpm == -1 ) n = n + "-"; else n = n + "+";
	for ( dg=0; dg<Laenge-Kommastellen; dg++ )
		{
	    n = n + " " + IntToHex((int)ea[dg],8);
    	}
	n = n + ",";
	for ( ; dg<Laenge; dg++ )
		{
	    n = n + " " + IntToHex((int)ea[dg],8);
    	}
    }

strcpy(as, n.c_str());
return error;
}
//---------------------------------------------------------------------------

int bigint::bigint2str(TEdit *an, bool leadblank)
{
int		rt;
String	az;

rt = bigint2str(az,leadblank);
an->Text = az;
return rt;
}

int bigint::bigint2str(TLMDEdit *an, bool leadblank)
{
int		rt;
String	az;

rt = bigint2str(az,leadblank);
an->Text = az;
return rt;
}
//---------------------------------------------------------------------------

int bigint::bigint2str(String& n, bool leadblank)
{
unsigned	zs[ANZDIGITSZR];	// Zwischenergebnis
int			p,pa;
String		el;
int			i,f,vks,c;

if ( error != biERROR_ok )
	{
	n = biERRORtext[error];
	return error;
	}

for ( i=0; i<Laenge; i++ ) 		// umcopieren
	zs[i] = ea[i];

p = 0; 							// Vorkomma-Register umgekehrt auslesen
vks = 0;
do {
	c = (( zsdiv((unsigned *)&zs,10,Laenge-Kommastellen) & 0x0F )) | 0x30;
	el += Char(c);
	p++;
	vks++;
	f = 0;
	for ( i=0; i<Laenge-Kommastellen; i++ )
		f += (zs[i] == 0);					// Wenn alle Vorkommastellen verarbeitet sind, sind alle zs[0...x] null
	}
while ( f != Laenge-Kommastellen );

el += L' ';
p++;
if ( vzpm == -1 ) el[p] = L'-';				// Vorzeichen

pa = 1;
n = "";
vks = (Laenge-Kommastellen)*WDIGITSST - vks;
if ( leadblank ) n = n.StringOfChar(' ',vks);

while ( p > 0 )						// Vorkomma-Ziffernfolge wieder umkehren
	n += el[p--];
n += L',';

//vks = Kommastellen * WDIGITSST;
vks = GlobNachKommaStellen;
do {
	c = (( zsshiftadd(zs,0,ANZDIGITS-KOMMADIGITS) & 0x0F )) | 0x30;
	n += Char(c);
	vks--;
	f = 0;
	for ( i=Laenge-Kommastellen; i<Laenge; i++ )
		f += (zs[i] != 0);
	}
while ( (f != 0)&&(vks>0) );

return error;
}
//---------------------------------------------------------------------------

int bigint::str2bigint(TEdit *an)
{
int		anl;
Char*	az;
/*
anl = an->GetTextLen() + 3;
az = new Char [anl];
wcscpy(az, an->Text.w_str());
anl = str2bigint(az);
delete[] az;
*/
return anl;

}

int bigint::str2bigint(TLMDEdit *an)
{
int		anl;

anl = str2bigint(an->Text);
/*
Char	*az;

anl = an->GetTextLen() + 3;
az = new Char[anl];
wcscpy(az, an->Text.w_str());
anl = str2bigint(az);
delete[] az;
*/
return anl;

}
//---------------------------------------------------------------------------

int bigint::str2bigint(String n)
{
unsigned	zs[ANZDIGITSZR];	// Zwischenergebnis
int			i,j,k,km,ex,s,sl;
int			np;
unsigned	d,c;

error = biERROR_ok;
for ( i=0; i<(Laenge+Laenge); i++ )
	zs[i] = 0;

km = false;								// noch kein Komma da
k = 0;
vzpm = 1;
sl = n.Length();
np = 1;
while ( np <= sl )
	{
	c = n[np++];
	if ( (c >= L'0')&&(c <= L'9') )
		{
		if ( km ) k++;						// Nachkommstellen z�hlen
		zsshiftadd(zs,c & 0x0f, EASTART);
		}
	if ( (c == L',')||(c == L'.') ) km = true;
	if ( c == L'-' ) vzpm = -1;
	if ( (c == L'e')||(c == L'E') ) break;
	}

ex = 0;										// Exponent ermitteln ( Nur wenn Zahl in Expoform )
s = 1;
while ( np <= sl )
	{
	c = n[np++];
	if ( (c >= L'0')&&(c <= L'9') )
		{
		ex *= 10;
		ex += n[np] & 0x0f;
		}
	if ( c == L'-' ) s = -1;
	}
k -= ( ex * s );

while ( k > 0 ) 				// Expon.-Kommastellen berichtigen, rechts-schieben
	{
	if ( k > 4 )
		{
		i = 10000;
		k -= 4;
		}
	else
		{
		for ( i = 1; k > 0; k-- )
			i *= 10;
		}
	zsdiv((unsigned *)zs,i,(Laenge+Laenge));  		// Dividiert durch max 0xffff !
	}
while ( k < 0 ) 				// Expon.-Kommastellen berichtigen, links-schieben
	{
	zsshiftadd(zs, 0, EASTART);
	k++;
	}

if ( zs[Laenge-(Laenge-Kommastellen)-1] != 0 )
	{
	error = biERRORovfl;
	return error;
	}

for ( i=0,j=((Laenge+Laenge)/2)-(Laenge-Kommastellen); i<Laenge; i++, j++ )		// Komma verschieben und speichern
	ea[i] = zs[j];

return error;
}
//---------------------------------------------------------------------------
int bigint::zsdiv( unsigned *eap, unsigned di, int imax )
{
int			i;
unsigned	d,u;

d = di;
u = 0;
i = imax;
	_asm {
			mov		esi, eap
zsdiv1:		mov		eax, [esi]
			shr		eax, 16
			mov		ecx, u
			shl		ecx, 16
			add		eax, ecx
			xor		edx, edx
			div		d
			shl		eax, 16
			mov		ebx, eax
			mov		eax, [esi]
			and		eax, 0x0000FFFF
			shl		edx, 16
			add		eax, edx
			xor		edx, edx
			div		d
			add		ebx,eax
			mov		[esi], ebx
			add		esi, 4
			mov		u, edx
			sub		i, 1
			jnz		zsdiv1
			}
return u;
}
//---------------------------------------------------------------------------
int bigint::zsshiftadd( unsigned* zs, unsigned di, int imax )
{
int			i;
unsigned	d,e,zero;

		zero = 0;
		d = di;
		for ( i=Laenge-1; i>=imax; i-- )
			{
			e = zs[i];						// Zahl einschreiben
			_asm {
				mov		eax, e
				mov		ecx, 10
				mul		ecx
				add		eax, d
				adc		edx, zero
				mov		e, eax
				mov		d, edx
				}
			zs[i] = e;
			}
return d;
}
//---------------------------------------------------------------------------

bigint::operator int()
{
long ee;

ee = ( ea[(Laenge-Kommastellen)-1] );
if	( ee < 0 )
	{
    ee = 0;
	}
return  ( ee * vzpm );
}
//---------------------------------------------------------------------------
bigint::operator long double()
{
union udata	{ long double ild; unsigned __int16 iui[5]; };
udata		ud;										// ud.iui[4] :  ist vorzeichen und exponent
													// ud.iui[3] :  Most signifikant Digit
													// ud.iui[0] :  Last signifikant Digit
													// 1.0E+0  hat ud.iui[4] == 0x3FFF
int			i,j,l,e;
unsigned	*eap,*eape;
unsigned	eadup[3] = { 0, 0, 0 };

if ( error != biERROR_ok )
	return ( NaN );
ud.ild = 0;
i = 0;
e = 0x3FFE + (( Laenge - Kommastellen ) * 32  );	// gr��ter positiver Exponent

while ( i < Laenge) { 								// erstes ea.digit > 0 suchen
	if ( ea[i] > 0 )
		break;;
	i++;
	e -= 32;
	}
if ( i == Laenge )
	return ( ud.ild );
for ( j=0; j<3; j++ ) { 							// Duplikat schieben - nicht Original
	eadup[j] = ea[i+j];
	if ( ( i + j ) >= Laenge )
		break;
	}
if ( i < Laenge ) {
	j = 31;
	eap = &eadup[0];
	l = ( Laenge - i );
	if ( l > 3 )
		l = 3;
	eape = &eadup[l-1];
	while ( j > 0 ) {
		if (( eadup[0] & 0x80000000 ) > 0 )
			break;
_asm  	{
		mov		edi, eape
		xor		eax, eax				// cf = 0    zieht von Rechts 0 rein
		mov		esi, eap
mal2b:	mov		eax, [edi]
		rcl		eax, 1
		mov		[edi], eax
		lahf
		sub		edi, 4
		cmp		edi, esi
		jb		mal2e
		sahf
		jmp		mal2b

mal2e:	nop
		}
		j--;
		e--;
		}
	}
ud.iui[3] = eadup[0]>>16;
ud.iui[2] = eadup[0] & 0x0000FFFF;
if ( l > 1) {
	ud.iui[1] = eadup[1]>>16;
	ud.iui[0] = eadup[1] & 0x0000FFFF;
	}
ud.iui[4] = e & 0x0000FFFF;
if ( ud.iui[3] == 0 )								// war this == 0 ?
	ud.iui[4] = 0;
if ( vzpm == -1 )
	ud.iui[4] |= 0x8000;
return ( ud.ild );
}
//---------------------------------------------------------------------------
int	bigint::bigintError()
{

return error;
}
//---------------------------------------------------------------------------
//	zur Erhaltung der Genauigkeit wird gerechnet:
//	return = sqrt((a * x)*(a * x) + (b * x)*(b *x)) / x
//
bigint bigint::pyt( const bigint& ai, const bigint& bi )
{
bigint		a,b;
int			i,j,as,bs,s;

a = ai;
as = 0;
while ( ai.ea[as] == 0 )
	{
	as++;
	if ( as >= ANZDIGITS )
		{
		return bi;						// ai == 0
		}
	}
b = bi;
bs = 0;
while ( bi.ea[bs] == 0 )
	{
	bs++;
	if ( bs >= ANZDIGITS )
		{
		return ai;						// bi == 0
		}
	}
s = ( as < bs )?as:bs;
if ( s > VORKOMMADIGITS )				// nicht schieben, wenn 1.Nachkommadigit voll
	{
	i = VORKOMMADIGITS;
	j = s;
	while ( j < ANZDIGITS )
		{
		a.ea[i] = ai.ea[j];
		b.ea[i++] = bi.ea[j++];
		}
	}
a *= a;
b *= b;
b += a;
b.sqrt();
if ( s > VORKOMMADIGITS )				// nicht zuruckschieben, wenn 1.Nachkommadigit voll war
	{
	i = ANZDIGITS-1;
	j = i - ( s - VORKOMMADIGITS );
	while ( i >= s )
		a.ea[i--] = b.ea[j--];
	while ( i >= 0 )
		a.ea[i--] = 0;
	return a;
	}
else
	return b;
}
//---------------------------------------------------------------------------



