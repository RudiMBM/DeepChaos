#ifndef BigIntH
#define BigIntH

#include "LMDEdit.hpp"

//---------------------------------------------------------------------------


#define	biERROR_ok		0

#define biERRORdiv0		1
#define	biERRORovfl		2
#define biERRORexov		3
#define biERRORinperr	4
#define biERRORleer		5
#define biERRORsizing	6
#define biERRORcont		7
#define biERRORsign		8
#define biMaske			9

#define biERRORread		10100


#define	EASTART			0
#define	ANZDIGITS		10
#define KOMMADIGITS		8
#define VORKOMMADIGITS  2
#define	ANZDIGITSZR		20

#define	WDIGITS			10000000000		// Maximale Zahl pro Digit
#define WDIGITSST		10        		// Stellen von WDIGITS  z.B.  10 => 1
#define EEMIN       	1e-30			// expoformat f�r BigIntToFloat => EE = KOMMADIGITS*WDIGITSST !!!

#define TRUE			1
#define FALSE			0

//---------------------------------------------------------------------------

class bigint
{

public:
					bigint();
					bigint(int);

		operator 	long double();						// casting Bigint --> Float
		operator 	int();								// casting bigint --> Int

		bigint 		operator=(const bigint&);
		bigint		operator=(const int);
		bigint		operator=(const long double&);

		bigint 		operator+(const bigint&);
		void   		operator+=(const bigint&);

		bigint 		operator-(const bigint&);
		void   		operator-=(const bigint&);

		bigint 		operator*(const bigint&);
		void   		operator*=(const int);
		void   		operator*=(const bigint&);

		bigint 		operator/(const bigint&);

		void   		operator/=(const int);
		void   		operator/=(const long double);
		void   		operator/=(const bigint&);

		bool   		operator>(const int);
		bool   		operator>(const bigint&);
		bool   		operator>=(const bigint&);
		bool   		operator==(const bigint&);

		bool   		operator<(const bigint&);

		bool		is0() const;
		bool        isNeg();
		bool        isinRange();
		bool   		isinMask(const bigint&, const bigint& );
		bool		isZero();

		void		zero();
		void   		mal2();
		void   		malXmal2( const bigint&);
		void   		div2();
		void   		pwr2();
        void		sqrt();
		void		neg();
		void		abs();
		void		sizemask();
		bigint		pyt( const bigint&, const bigint& );

		void		setSize(short L, short K);
		void		setPraez(short K);
		void		setBIP(int K);
		void		setKommastellenAnzeige(int K);
		void		bintrunc(const bigint&);

		int 		bigint2str(String& n, bool leadblank); 		// String erzeugen
		int 		bighex2str(char *, bool leadblank); 		// String erzeugen
		int 		bigint2str(TEdit*, bool leadblank); 		// String erzeugen
		int 		bigint2str(TLMDEdit *an, bool leadblank);
		int 		bighex2str(TEdit*, bool leadblank); 		// String erzeugen
		int			str2bigint(String n);
		int 		str2bigint(TEdit*);
		int 		str2bigint(TLMDEdit*);
		int 		str2bighex(TEdit*);

		int			bigintError();

private:
		void 		addieren(unsigned *a,unsigned *b,unsigned *z);
		void 		subtrahieren(unsigned *a,unsigned *b,unsigned *z);
		int 		zsshiftadd( unsigned* zs, unsigned di, int imax );
		int 		zsdiv( unsigned *eap, unsigned di, int imax );

		unsigned	ea[ANZDIGITS];		// Ergebins-Zahlenarray
		char		vzpm,error,Laenge,Kommastellen;
};

//---------------------------------------------------------------------------
#endif
