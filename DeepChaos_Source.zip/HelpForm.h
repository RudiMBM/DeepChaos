//---------------------------------------------------------------------------

#ifndef HelpFormH
#define HelpFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class THelpWd : public TForm
{
__published:	// IDE-verwaltete Komponenten
	TListBox *HelpText;
	TStatusBar *StatusBar;
	void __fastcall HelpTextMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall HelpTextKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall HelpTextDblClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall FormDestroy(TObject *Sender);


private:	// Benutzer Deklarationen
	TStringList		*CommandChars;
	int				cnr;			// Kommandozeilennummer

	void __fastcall Commando( int c );


public:		// Benutzer Deklarationen
	__fastcall THelpWd(TComponent* Owner);

				String				Sf;
};
//---------------------------------------------------------------------------
extern PACKAGE THelpWd *HelpWd;
//---------------------------------------------------------------------------
#endif
