#include <vcl.h>
#include <math.h>

#include "LMDComboBox.hpp"

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "ColorBar.h"
#include "BildForm.h"
#include "OrbitAnalyse.h"
#include "PhasenAnalyse.h"
#include "HelpForm.h"
#include "DatenBankForm.h"
#include "ZeitReihe.h"
#include "DCMAIN.h"
#include "About.h"

extern	TStringList			*D_Namen;

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
MbmAnz::MbmAnz( )
{

PbPos = 0;
PosibleTasks = 1;
biiCallBack = NULL;
posCallBack = NULL;
}
//---------------------------------------------------------------------------
MbmAnz::~MbmAnz( )
{

}
//---------------------------------------------------------------------------
char*	MbmAnz::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

return ah;
}

//---------------------------------------------------------------------------
int		MbmAnz::getDarstellung( int index )
{

return DCWd->AktivesFenster->Auswertungsliste[index];
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
void	MbmAnz::writeAuswertungsListe(TLMDComboBox* em, int idx, int i )
{
int		j,m,p;

TStringList *sl = new TStringList();
try
	{
    p = 0;
    for ( j=0; j<i; j++ )
		{
		m = DCWd->AktivesFenster->Auswertungsliste[j];
		sl->Add(D_Namen->Strings[m]);
        if ( m == idx )
        	p = j;
        }
	em->Items->Assign(sl);
    em->ItemIndex = p;
	}
__finally
	{
  	delete sl;
	}
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
BigIntIter*	MbmAnz::openAuswertung( int aa )
{

switch ( aa )
	{
	case  D_Mandelbrot:				return ( new BigIntIter ); 			break;
	case  D_Apfelmaennchen:			return ( new Apfelmaennchen ); 		break;
	case  D_Bubblebrot:				return ( new Bubblebrot ); 			break;
	case  D_Lotusbrot:				return ( new Lotusbrot ); 			break;
	case  D_Runout:					return ( new Runout ); 				break;
	case  D_xyKoordinaten:			return ( new Apfelmaennchen ); 		break;
	case  D_Steigung:				return ( new Steigung ); 			break;
	case  D_Cyclebrot:				return ( new Cyclebrot ); 			break;
	case  D_CenterOfOrbit:			return ( new CenterOfOrbit ); 		break;
	case  D_SizeOfOrbit:			return ( new SizeOfOrbit );			break;
	case  D_Mindiff:				return ( new Mindiff ); 			break;
	case  D_Pabw:					return ( new Pabw ); 				break;
	case  D_Zmindiff:				return ( new Zmindiff ); 			break;
	case  D_ZyclusIter:				return ( new ZyclusIter ); 			break;
	case  D_Zyclus:					return ( new Zyclus ); 				break;
	case  D_Grenzzyclus:			return ( new Grenzzyclus(100) );	break;
	case  D_MinSwingIn:				return ( new MinSwingIn ); 			break;
	case  D_SeekTops:				return ( new SeekTops ); 			break;
	case  D_Actiondetect:			return ( new Actiondetect ); 		break;
	case  D_StartPointDiffergent:	return ( new StartPointDiffergent );break;
	case  D_AereaOfOrbit:			return ( new AereaOfOrbit ); 		break;
	case  D_SternSeek:				return ( new SternSeek ); 			break;
	case  D_FirstIter:				return ( new FirstIter ); 			break;
	case  D_EWeg:					return ( new EWeg ); 				break;
	case  D_Grundwelle:			    return ( new Grundwelle ); 		    break;
	case  D_SteigungPeriode:		return ( new SteigungPeriode );		break;
	case  D_LastPeak:				return ( new LastPeak );			break;
	case  D_MinCount:				return ( new MinCount );			break;
	}
}
//---------------------------------------------------------------------------
void	MbmAnz::SetBase( TMainParams *v )
{

v->InnerMin = 0;
v->InnerMax = 100;
v->OuterMin = 0;
v->OuterMax = 100;
v->MaxRadius = 2;
v->MaxIter = 100;
v->VorlaufIter = 0;
v->Amode = 0;
v->EmodeNr = 1;
v->EmodeZusatz = 0.5;
v->Rmode = 0;
v->BmodeR = 0;
v->RefSizeX = 111;
v->BmodeB = 3;
v->ZusatzMode = 0;
v->Zscala = 100;
v->Zlevel = 0;
SetFullSize(v);
v->jpx.zero();
v->jpy.zero();
v->tpx.zero();
v->tpy.zero();
v->imagx = 1.0;
v->imagy = 0.0;
}
//---------------------------------------------------------------------------
void	MbmAnz::SetFullSize( TMainParams *v )
{

switch ( v->Mmode )
	{
	case 0:                             		// Mandelbrotmenge
				v->cx.zero();
				v->cy.zero();
				v->BildSize = 4.1;
				break;
	case 1:                               		// Juliamenge
				v->cx.zero();
				v->cy.zero();
				v->BildSize = 5.0;
				break;
	}
}
//---------------------------------------------------------------------------

void 	MbmAnz::SetOrbitKoo( bigint *xbi, bigint *ybi )
{

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
void	MbmAnzMI::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Mandelbrot;
awl[i++] = D_Bubblebrot;
awl[i++] = D_MinCount;
awl[i++] = D_Cyclebrot;
awl[i++] = D_Lotusbrot;
awl[i++] = D_Grundwelle;
awl[i++] = D_SternSeek;
awl[i++] = D_AereaOfOrbit;
awl[i++] = D_Runout;
awl[i++] = D_LastPeak;
awl[i++] = D_Steigung;
awl[i++] = D_SteigungPeriode;
awl[i++] = D_SeekTops;
awl[i++] = D_Actiondetect;
awl[i++] = D_StartPointDiffergent;
awl[i++] = D_Zyclus;

MbmAnz::writeAuswertungsListe( em, idx, i );
}
//---------------------------------------------------------------------------
char*	MbmAnzMI::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: 				ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die \nmaximale Iterationsanzahl ermittelt.";
							break;
	case D_Mandelbrot: 		ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird angezeigt \nob er im Verlauf der Iteration divergiert oder konvergiert.";
							break;
	case D_Apfelmaennchen:	ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die Iterationsanzahl ermittelt, \nbei der das Ergebnis von Z das erste Minimum hat.";
							break;
	case D_Bubblebrot: 		ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird das Minimum von Z ermittelt \nund dessen Betrag angezeigt.";
							break;
	case D_Mindiff: 		ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die Iterationsdifferenz ermittelt, \nzwischen der das Ergebnis Z das erste Minimum hat \nund der, die das zweite Minimum hat.";
							break;
	case D_Pabw: 			ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird das erste und zweite Minimum von Z ermittelt, \nund dessen Differenz angezeigt.";
							break;
	case D_Zmindiff: 		ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt werden insgesamt 3 Minima von Z ermittelt, \nnicht in der zeitlichen Abfolge, sondern in ihrer Wertigkeit.\nDie Iterationsanzahl zwischen Minimum 1 und 2 wird von \nder Iterationsanzahl zwischen Minimum 2 und 3 abgezogen. \nDamit ist ablesbar, ob eine Periode stabil ist, oder ob sie variiert.";
							break;
	case D_Zyclus: 			ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird der Grenzzyclus berechnet, \nindem die Folge verglichen wird.";
							break;
	case D_Grenzzyclus: 	ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt werden die Iterationsschritte gez�hlt, \ndie mit jeweils immer gr��erem Z auftreten \nbis Zmax �berschritten wird.\n( Nur f�r Orte, die divergieren. )";
							break;
	case D_MinSwingIn: 		ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wir der Wert von Z ermittelt, \nf�r die Iteration, bei der die Folge zu divergieren beginnt.\n( Nur f�r Orte, die divergieren. )";
							break;
	case D_SeekTops:		ah =    "Apfelm�nnchen-Auswertung---> Versuch statt Betr(z) f�r Abbruch Betr(i) und Betr(r) vergleichen";
							break;
    }
return ah;
}//---------------------------------------------------------------------------
MbmAnzMI::MbmAnzMI( )
{

PosibleTasks = 100;
biiCallBack = NULL;
}
//---------------------------------------------------------------------------
MbmAnzMI::~MbmAnzMI( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzMI::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize;
delta /= Width;

PbMax = Width * Height;
PbPos = 0;
}
//---------------------------------------------------------------------------
void	MbmAnzMI::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				x,y,p;
long double		ze;
bigint			jx,jy,ex,ey;
BigIntIter		*bii;
IStatus			is;
long double 	*ErgTab;

bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;
if ( Params->Mmode >= 1 ) {
	jx = Params->jpx;
	jy = Params->jpy;
	}
else {
	jx.zero();
	jy.zero();
	}

ErgTab = ergtab;

ey = delta;
ey *= Height / 2;
ey += Params->cy;
for ( y=0; y<Height; y++ )
	{
	ex = delta;
	ex.neg();
	ex *= Width / 2;
	ex += Params->cx;
	for ( x=0; x<Width; x++ )
		{
		if (((( y * Width ) + x ) % TaskAnz ) == TaskNr )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if ( Params->VorlaufIter > 0 )
				is = bii->iterate_PreRun(Params->VorlaufIter);
			is = bii->iterate_run(Params->MaxIter);
			ze = bii->zi;
			switch ( Params->BmodeB ){
				case 1:	if ( is == outside )
							*ErgTab = 0;
						else
							*ErgTab = ze;
						break;
				case 2:	if ( is == inside )
							*ErgTab = NaN;
						else
							*ErgTab = ze;
						break;
				case 3:	*ErgTab = ze;
						break;
				}
			if ( is == inside )
				{
				if ( ze < Params->InnerMin ) Params->InnerMin = ze;
				if ( ze > Params->InnerMax ) Params->InnerMax = ze;
				}
			if ( is == outside )
				{
				if ( ze < Params->OuterMin ) Params->OuterMin = ze;
				if ( ze > Params->OuterMax ) Params->OuterMax = ze;
				}
			if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
			if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
			}
		ErgTab++;
		ex += delta;
		p = ( y * Width ) + x;
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= delta;
	if ( StopSignal ) break;
	}
PbPos = 1;
delete bii;
}

//---------------------------------------------------------------------------
void	MbmAnzMI::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
long double		ze;
bigint			jx,jy,ex,ey;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->tpx.bigintError() != 0 ) return;
if ( Params->tpy.bigintError() != 0 ) return;

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jx,jy,ex,ey,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if ( Params->VorlaufIter > 0 )
	is = bii->iterate_PreRun(Params->VorlaufIter);

if ( biiCallBack == NULL )
	is = bii->iterate_run(Params->MaxIter);			// Endergebnis liefern
else
	{
	while ( bii->itercount < Params->MaxIter )		// Einzelergebnisse liefern
		{
		is = bii->iterate_run(1);
		biiCallBack(bii);
		}
	}
ze = bii->zi;

delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
void	MbmAnzMZ::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_MinCount;
awl[i++] = D_Cyclebrot;
awl[i++] = D_Lotusbrot;
awl[i++] = D_Grundwelle;
awl[i++] = D_CenterOfOrbit;
awl[i++] = D_SizeOfOrbit;
awl[i++] = D_SternSeek;
awl[i++] = D_Steigung;
awl[i++] = D_SteigungPeriode;
awl[i++] = D_FirstIter;
awl[i++] = D_EWeg;
awl[i++] = D_Runout;
awl[i++] = D_LastPeak;
awl[i++] = D_StartPointDiffergent;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzMZ::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die \nmaximale Iterationsanzahl ermittelt.";
    		break;
	case 1: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird angezeigt \nob er im Verlauf der Iteration divergiert oder konvergiert.";
			break;
	case 2: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die Iterationsanzahl ermittelt, \nbei der das Ergebnis von Z das erste Minimum hat.";
    		break;
	case 3: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird das Minimum von Z ermittelt \nund dessen Betrag angezeigt.";
    		break;
	case 11: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird die Iterationsdifferenz ermittelt, \nzwischen der das Ergebnis Z das erste Minimum hat \nund der, die das zweite Minimum hat.";
    		break;
	case 12: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird das erste und zweite Minimum von Z ermittelt, \nund dessen Differenz angezeigt.";
			break;
	case 13: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt werden insgesamt 3 Minima von Z ermittelt, \nnicht in der zeitlichen Abfolge, sondern in ihrer Wertigkeit.\nDie Iterationsanzahl zwischen Minimum 1 und 2 wird von \nder Iterationsanzahl zwischen Minimum 2 und 3 abgezogen. \nDamit ist ablesbar, ob eine Periode stabil ist, oder ob sie variiert.";
    		break;
	case 15: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wird der Grenzzyclus berechnet, \nindem die Folge verglichen wird.";
			break;
	case 16: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt werden die Iterationsschritte gez�hlt, \ndie mit jeweils immer gr��erem Z auftreten \nbis Zmax �berschritten wird.\n( Nur f�r Orte, die divergieren. )";
    		break;
	case 17: ah = 	"f�r jeden Punkt in dem gew�hlen Ausschnitt wir der Wert von Z ermittelt, \nf�r die Iteration, bei der die Folge zu divergieren beginnt.\n( Nur f�r Orte, die divergieren. )";
    		break;
	}
return ah;
}//---------------------------------------------------------------------------
MbmAnzMZ::MbmAnzMZ( )
{

PosibleTasks = 100;
}
//---------------------------------------------------------------------------
MbmAnzMZ::~MbmAnzMZ( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzMZ::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{
int				i;
long double		*e;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )					// ergebnistabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*e++ = 0;
	i--;
	}

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize;
delta /= Width;

PbMax = Width * Height;
PbPos = 0;

}
//---------------------------------------------------------------------------
void	MbmAnzMZ::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,p;
long double		ze,*ErgTab;
bigint			jx,jy,ex,ey,zmin,zmax,zref;
BigIntIter		*bii;
IStatus			is;

zmin = 999999.9;
zmax.zero();
zref.zero();
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );
ErgTab = ergtab;

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;
jx = Params->jpx;
jy = Params->jpy;

//i = Params->BmodeR + 1;				// 1- oder 2-Pass durchlauf, absolut oder Relativ     // wozu eigentlich ?????????????
i = 1;
for ( ; i>0; i-- )
	{
	ey = delta;
	ey *= Height / 2;
	ey += Params->cy;
	for ( y=0; y<Height; y++ )
		{
		ex = delta;
		ex.neg();
		ex *= Width / 2;;
		ex += Params->cx;
		for ( x=0; x<Width; x++ )
			{
			if (((( y * Width ) + x ) % TaskAnz ) == TaskNr )
				{
				if (( Params->Mmode & 0x01 ) == 0 )
					is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
				if (( Params->Mmode & 0x01 ) == 1 )
					is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
				if ( Params->VorlaufIter > 0 )
					is = bii->iterate_PreRun(Params->VorlaufIter);
				is = bii->iterate_run(Params->MaxIter);
				if ( i == 2 )									// 1.Durchlauf f�r Ermittlung zref
					{
					if ( (((int)is) & Params->BmodeB ) == 0 )   	// Erg. nicht beachten, wenn falscher Bereich
						{
						if ( zmin > bii->za ) zmin = bii->za;
						if ( zmax < bii->za ) zmax = bii->za;
						}
					}
				else    										// 2. Durchlauf Bild f�llen
					{
					if ( (((int)is) & Params->BmodeB ) == 0 )
						ze = zref;                		  		// Erg. l�schen, wenn falscher Bereich
					else
						{
						//bii->za -= zref;							// ????????
						ze = bii->za;
						}
					*ErgTab = ze;
					if ( is == inside )
						{
						if ( ze < Params->InnerMin ) Params->InnerMin = ze;
						if ( ze > Params->InnerMax ) Params->InnerMax = ze;
						}
					if ( is == outside )
						{
						if ( ze < Params->OuterMin ) Params->OuterMin = ze;
						if ( ze > Params->OuterMax ) Params->OuterMax = ze;
						}
					if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
					if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
					}
				}
			ErgTab++;
			ex += delta;
			p = ( y * Width ) + x;
			if ( p > PbPos ) PbPos = p;
			if ( StopSignal ) break;
			}
		ey -= delta;
		if ( StopSignal ) break;
		}
	if ( i == 2 )
		{
		zmin += zmax;
		zmin.div2();
		zref = zmin;
		}
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzMZ::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
long double		ze;
bigint			jx,jy,ex,ey;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->tpx.bigintError() != 0 ) return;
if ( Params->tpy.bigintError() != 0 ) return;

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
   	is = bii->iterate_start(jx,jy,ex,ey,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
   	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if ( Params->VorlaufIter > 0 )
	is = bii->iterate_PreRun(Params->VorlaufIter);
is = bii->iterate_run(Params->MaxIter);
ze = bii->za;

delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Buddabrot  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Aufsummierung aller Orbits
*/

void	MbmAnzBB::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzBB::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der letzten Iteration ermittelt und dieser im Bild markiert.";
			break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzBB::MbmAnzBB( )
{

PosibleTasks = 100;  //4;
}
//---------------------------------------------------------------------------
MbmAnzBB::~MbmAnzBB( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzBB::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{
int				i;
long double		*e;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;
PbPos = 0;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )					// ergebnistabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*e++ = 0;
	i--;
	}

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize; 				// Anzeige Bereich
delta /= Width;

}
//---------------------------------------------------------------------------
void	MbmAnzBB::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,xe,ye,s,HeightF,WidthF,p;
long double		*Im,xld,yld,deltald,refsizeradius;
bigint			jy,jx,ey,ex,xbi,ybi,cxl,cxr,cyt,cyb,deltaF;
BigIntIter		*bii;
IStatus			is;
bool			rechnen;

bii = openAuswertung( D_Apfelmaennchen );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

deltald = delta;

cxl = delta; 								// anzeigegrenzen
cxl *= Width / 2;
cxr = cxl;
cxr += Params->cx;
cxl.neg();
cxl += Params->cx;
cyt = delta;
cyt *= Height / 2;
cyb = cyt;
cyt += Params->cy;
cyb.neg();
cyb += Params->cy;

WidthF = Params->RefSizeX;  				// Scanbereich
deltaF = Params->RefSize;
deltaF /= WidthF;
HeightF = WidthF / Params->RefBildSV;
refsizeradius = Params->RefSize / 2.0;

PbMax = WidthF * HeightF;

jx = Params->jpx;
jy = Params->jpy;

rechnen = true;
ey = deltaF;
ey *= HeightF / 2;
ey += Params->ry;
for ( y=0; y<HeightF; y++ )
	{
	ex = deltaF;
	ex.neg();
	ex *= WidthF / 2;
	ex += Params->rx;
	for ( x=0; x<WidthF; x++ )
		{
		if ( Params->isRefCycle )
			{
			xld = ex - Params->rx;
			yld = ey - Params->ry;
			xld *= xld;
			yld *= yld;
			xld += yld;
			yld = sqrtl(xld);
			rechnen = ( yld <= refsizeradius );
			}
		if ((((( y * WidthF ) + x ) % TaskAnz ) == TaskNr ) & rechnen==true )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if ( Params->VorlaufIter > 0 )
				is = bii->iterate_run(Params->VorlaufIter);			// erst bis Anfang-Iter laufen, dann alle punkte einzeln
			is = bii->iterate_run(1);

			while ( (is == inside) && (bii->itercount < Params->MaxIter) )
				{
				if ( (((int)is) & Params->BmodeB ) > 0 )
					{
					xbi = bii->ex;									// arbeitet schneller  und vorweggenommen
					ybi = bii->ey;                                  /* TODO : Hier x-y getauscht, weil irgendwo Fehler, hiermit korrigiert.
																		..weils pl�tzlich wieder ging, zur�ckgenommen!   ????*/
					if ( xbi > cxl )
						if ( xbi < cxr )
							if ( ybi > cyb )
								if ( ybi < cyt )
									{
									xbi -= cxl;                			// Pixelposition der laufenden Iteration berechnen
									xld = xbi;
									xld /= deltald;
									xe = xld;
									yld = cyt - ybi;
									yld /= deltald;
									ye = yld;
									s = ( ye * Width ) + xe;
									Im = ergtab + s;
									(*Im)++;
									i = *Im;
									if ( is == inside )
										{
										if ( i < Params->InnerMin ) Params->InnerMin = i;
										if ( i > Params->InnerMax ) Params->InnerMax = i;
										}
									if ( is == outside )
										{
										if ( i < Params->OuterMin ) Params->OuterMin = i;
										if ( i > Params->OuterMax ) Params->OuterMax = i;
										}
									}
					}
				is = bii->iterate_run(1);
				if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
				if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
				}
			}
		ex += deltaF;
		p = ( y * WidthF ) + x;
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= deltaF;
	if ( StopSignal ) break;
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzBB::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  BuddabrotRevers  ##################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Aufsummierung aller Orbits    -  Reverse Funktion
*/

void	MbmAnzBBr::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzBBr::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der letzten Iteration ermittelt und dieser im Bild markiert.";
			break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzBBr::MbmAnzBBr( )
{

PosibleTasks = 100;  //4;
}
//---------------------------------------------------------------------------
MbmAnzBBr::~MbmAnzBBr( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzBBr::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{
int				i;
long double		*e;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;
PbPos = 0;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )					// ergebnistabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*e++ = 0;
	i--;
	}

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize; 				// Anzeige Bereich
delta /= Width;

}
//---------------------------------------------------------------------------
void	MbmAnzBBr::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,xe,ye,s,HeightF,WidthF,p;
long double		*Im,xld,yld,deltald,refsizeradius,zs;
bigint			jy,jx,ey,ex,xbi,ybi,cxl,cxr,cyt,cyb,deltaF,zxl,zxr,zyt,zyb,zsbi;
BigIntIter		*bii;
IStatus			is;
bool			rechnen;

bii = openAuswertung( D_Apfelmaennchen );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

deltald = delta;

cxl = delta; 								// anzeigegrenzen
cxl *= Width / 2;
cxr = cxl;
cxr += Params->cx;
cxl.neg();
cxl += Params->cx;
cyt = delta;
cyt *= Height / 2;
cyb = cyt;
cyt += Params->cy;
cyb.neg();
cyb += Params->cy;

zs =  Params->ZoomSize / 2.0;
zsbi = zs;
zxl = Params->zcx;
zxl -= zsbi; 								// Zoomgrenzen f�r Messbereich auswahl
zxr = Params->zcx;
zxr += zsbi;
zyt = Params->zcy;
zyt += zsbi;
zyb = Params->zcy;
zyb -= zsbi;

WidthF = Params->RefSizeX;  				// Scanbereich
deltaF = Params->RefSize;
deltaF /= WidthF;
HeightF = WidthF / Params->RefBildSV;
refsizeradius = Params->RefSize / 2.0;

PbMax = WidthF * HeightF;

jx = Params->jpx;
jy = Params->jpy;

rechnen = true;
ey = deltaF;
ey *= HeightF / 2;
ey += Params->ry;
for ( y=0; y<HeightF; y++ )
	{
	ex = deltaF;
	ex.neg();
	ex *= WidthF / 2;
	ex += Params->rx;
	for ( x=0; x<WidthF; x++ )
		{
		if ( Params->isRefCycle )
			{
			xld = ex - Params->rx;
			yld = ey - Params->ry;
			xld *= xld;
			yld *= yld;
			xld += yld;
			yld = sqrtl(xld);
			rechnen = ( yld <= refsizeradius );
			}
		if ((((( y * WidthF ) + x ) % TaskAnz ) == TaskNr ) & rechnen==true )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if ( Params->VorlaufIter > 0 )
				is = bii->iterate_run(Params->VorlaufIter);			// erst bis Anfang-Iter laufen, dann alle punkte einzeln
			is = bii->iterate_run(1);

			while ( (is == inside) && (bii->itercount < Params->MaxIter) )
				{
				if ( (((int)is) & Params->BmodeB ) > 0 )
					{
					xbi = bii->ex;									// arbeitet schneller  und vorweggenommen
					ybi = bii->ey;
					if ( xbi > zxl )
						if ( xbi < zxr )
							if ( ybi > zyb )
								if ( ybi < zyt )
																	// Orbitpunkt ist nun innerhalb der Zoom-Messgrenzen
					if ( ex > cxl )
						if ( ex < cxr )
							if ( ey > cyb )
								if ( ey < cyt )
									{       						// Orbitursprung ist innerhalb der Anzeigefl�che
									xbi = ex;
									ybi = ey;
									xbi -= cxl;            			// Pixelposition der laufenden Iteration berechnen
									xld = xbi;
									xld /= deltald;
									xe = xld;
									yld = cyt - ybi;
									yld /= deltald;
									ye = yld;
									s = ( ye * Width ) + xe;
									Im = ergtab + s;
									(*Im)++;
									i = *Im;
									if ( is == inside )
										{
										if ( i < Params->InnerMin ) Params->InnerMin = i;
										if ( i > Params->InnerMax ) Params->InnerMax = i;
										}
									if ( is == outside )
										{
										if ( i < Params->OuterMin ) Params->OuterMin = i;
										if ( i > Params->OuterMax ) Params->OuterMax = i;
										}
									}
					}
				is = bii->iterate_run(1);
				if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
				if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
				}
			}
		ex += deltaF;
		p = ( y * WidthF ) + x;
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= deltaF;
	if ( StopSignal ) break;
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzBBr::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Ergebnisort  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/


void	MbmAnzEO::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_Cyclebrot;
awl[i++] = D_Runout;
awl[i++] = D_LastPeak;
awl[i++] = D_CenterOfOrbit;
awl[i++] = D_StartPointDiffergent;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzEO::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der letzten Iteration ermittelt und dieser im Bild markiert.";
			break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzEO::MbmAnzEO( )
{

PosibleTasks = 100;
}
//---------------------------------------------------------------------------
MbmAnzEO::~MbmAnzEO( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzEO::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{
int				i;
long double		*e;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;
Params->FertigBisX = 0;
Params->FertigBisY = 0;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )					// ergebnistabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*e++ = 0;
	i--;
	}

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize; 				// Anzeige Bereich
delta /= Width;
}
//---------------------------------------------------------------------------
void	MbmAnzEO::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,xe,ye,s,HeightF,WidthF,p;
long double		*Im,xld,yld,deltald,refsizeradius;
bigint			jy,jx,ey,ex,xbi,ybi,cxl,cxr,cyt,cyb,deltaF;
BigIntIter		*bii;
IStatus			is;
bool 			rechnen;

bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

deltald = delta;

cxl = delta; 								// anzeigegrenzen
cxl *= Width / 2;
cxr = cxl;
cxr += Params->cx;
cxl.neg();
cxl += Params->cx;
cyt = delta;
cyt *= Height / 2;
cyb = cyt;
cyt += Params->cy;
cyb.neg();
cyb += Params->cy;

WidthF = Params->RefSizeX;  				// Scanbereich
deltaF = Params->RefSize;
deltaF /= WidthF;
HeightF = WidthF / Params->RefBildSV;
refsizeradius = Params->RefSize / 2.0;

PbMax = WidthF * HeightF;

jx = Params->jpx;
jy = Params->jpy;

rechnen = true;
ey = deltaF;
ey *= HeightF / 2;
ey += Params->ry;
for ( y=0; y<HeightF; y++ )
	{
	ex = deltaF;
	ex.neg();
	ex *= WidthF / 2;
	ex += Params->rx;
	for ( x=0; x<WidthF; x++ )
		{
		if ( Params->isRefCycle )
			{
			xld = ex - Params->rx;
			yld = ey - Params->ry;
			xld *= xld;
			yld *= yld;
			xld += yld;
			yld = sqrtl(xld);
			rechnen = ( yld <= refsizeradius );
			}
		if ((((( y * WidthF ) + x ) % TaskAnz ) == TaskNr ) & rechnen==true )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if ( Params->VorlaufIter > 0 )
				is = bii->iterate_run(Params->VorlaufIter);			// erst bis Anfang-Iter laufen, dann alle punkte einzeln
			is = bii->iterate_run(Params->MaxIter);

			if ( ((((int)is) & Params->BmodeB ) > 0 ) && ( bii->itercount >= Params->VorlaufIter ) )
					{
					xbi = bii->ex;									// arbeitet schneller  und vorweggenommen
					ybi = bii->ey;
					if ( xbi > cxl )
						if ( xbi < cxr )
							if ( ybi > cyb )
								if ( ybi < cyt )
									{
									xbi -= cxl;                			// Pixelposition der laufenden Iteration berechnen
									xld = xbi;
									xld /= deltald;
									xe = xld;
									yld = cyt - ybi;
									yld /= deltald;
									ye = yld;
									s = ( ye * Width ) + xe;
									Im = ergtab + s;
									(*Im)++;
									i = *Im;
									if ( is == inside )
										{
										if ( i < Params->InnerMin ) Params->InnerMin = i;
										if ( i > Params->InnerMax ) Params->InnerMax = i;
										}
									if ( is == outside )
										{
										if ( i < Params->OuterMin ) Params->OuterMin = i;
										if ( i > Params->OuterMax ) Params->OuterMax = i;
										}
									}
				if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
				if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
				}
			}
		ex += deltaF;
		p = ( y * WidthF ) + x;
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= deltaF;
	if ( StopSignal ) break;
	}
delete bii;
PbPos = 1;
}
/*                                       alte Version
int				i,x,y,xe,ye,s,hF,wF;
long double		*e,*Im,xld,yld,deltald;
bigint			jy,jx,ey,ex,delta,xbi,ybi;
BigIntIter		*bii;
IStatus			is;

PbPos = 0;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

delta = Params->BildSize; 				// Anzeige Bereich
delta /= Width;
deltald = delta;

delta = Params->RefSize;
delta /= Width;

jx = Params->jpx;
jy = Params->jpy;

hF = Height * Params->BmodeF;
wF = Width * Params->BmodeF;
delta /= Params->BmodeF;            // Aufl�sungsfaktor
PbMax = hF;
ey = delta;
ey *= Height / 2;
cyb = ey + Params->cy;
//ey.neg();
cyt = ey + Params->cy;
ey += Params->ry;
y = Params->FertigBisY;
if ( Params->FertigBisY > 0 )
	{
	ybi = delta;
	ybi *= y;
	ey -= ybi;
	}
for ( ; y<hF; y++ )
	{
	ex = delta;
	ex *= Width / 2;
	cxr = ex + Params->cy;
	ex.neg();
	cxl = ex + Params->cy;
	ex += Params->rx;
	if ( Params->FertigBisX > 0 )
		{
		xbi = delta;
		xbi *= x;
		ex += xbi;
		Params->FertigBisX = 0;				// nur Rest der Zeile
		}
	x = Params->FertigBisX;
	for ( ; x<wF; x++ )
		{
		if (( Params->Mmode & 0x01 ) == 0 )
			is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
		if (( Params->Mmode & 0x01 ) == 1 )
			is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
		is = bii->iterate_run(Params->MaxIter);

		if ( ((((int)is) & Params->BmodeB ) > 0 ) && ( bii->itercount >= Params->VorlaufIter ) )
				{
				xbi = bii->ex;									// arbeitet schneller  und vorweggenommen
				ybi = bii->ey;
				if ( xbi > cxl )
					if ( xbi < cxr )
						if ( ybi > cyt )
							if ( ybi < cyb )
								{
								//xbi = bii->ex;      // erl.       			// Pixelposition des Ergebnisses berechnen
								xbi -= cxl;
								xld = xbi;
								xld /= deltald;
								xe = xld;
								//ybi = bii->ey;     // erl.
								ybi -= cyt;
								yld = ybi;
								yld /= deltald;
								ye = yld;
								s = ( ye * Width ) + xe;
								Im = ergtab + s;
								*Im += 1;
								if ( *Im > Params->InnerMax )
									{
									Params->InnerMax = *Im;
									Params->OuterMax = *Im;
									}
								}
				}
		if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
		ex += delta;
		}
	PbPos = y;
	Application->ProcessMessages();
	if ( StopSignal ) break;
	ey -= delta;
	}

Params->FertigBisX = x;
Params->FertigBisY = y;
delete bii;
*/

//---------------------------------------------------------------------------
void	MbmAnzEO::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
bigint			jy,jx,ey,ex;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
   	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
   	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );

is = bii->iterate_run(Params->MaxIter);
ie->ex = bii->ex;
ie->ey = bii->ey;
delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Ergebnisort - Ursprung   #################################################################################################################################################
//-----------------------------------------------------------------------------------------------------------------------------------------------------
/*
Erforderlich ist als Vorbereitung eine Erstellung im Mode Ergebnisort im Hauptfenster.
Diese Ergebnisse werden als Ausgabe f�r diesen 2.Pass verwendet.

*/


void	MbmAnzEU::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_Cyclebrot;
awl[i++] = D_Runout;
awl[i++] = D_LastPeak;
awl[i++] = D_CenterOfOrbit;
awl[i++] = D_StartPointDiffergent;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzEU::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der letzten Iteration ermittelt und dieser im Bild markiert.";
    		break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
    		break;
    }
return ah;
}
//---------------------------------------------------------------------------
MbmAnzEU::MbmAnzEU( )
{
PosibleTasks = 100;
}
//---------------------------------------------------------------------------
MbmAnzEU::~MbmAnzEU( )
{

delete[] ScanTab;
}
//---------------------------------------------------------------------------
void	MbmAnzEU::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{
int				i,*e;
long double		*ed;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;
Params->FertigBisX = 0;
Params->FertigBisY = 0;

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

ed = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )					// ergebnistabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*ed++ = 0;
	i--;
	}

delta = Params->BildSize;
delta /= Width;

WidthF = Params->RefSizeX;  				// Scanbereich
deltaF = Params->RefSize;
deltaF /= WidthF;
HeightF = WidthF / Params->RefBildSV;
refsizeradius = Params->RefSize / 2.0;
ScanTab = new int[ HeightF * WidthF ];
e = ScanTab;
i = ( HeightF * WidthF ) - 1;
while ( i >= 0 )						// Scantabelle l�schen  Nur Einmal, nicht in jeder Task!!!!
	{
	*e++ = 0;
	i--;
	}
}
//---------------------------------------------------------------------------
void	MbmAnzEU::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,xe,ye,s,p,pass,*Im,WidthFF;
long double		xld,yld,deltald,*ErgTab;
bigint			jy,jx,ey,ex,xbi,ybi,cxl,cxr,cyt,cyb,zx,zy;
BigIntIter		*bii;
IStatus			is;
bool 			rechnen;

bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

deltald = deltaF;

cxl = deltaF; 								// Scangrenzen
cxl *= WidthF / 2;
cxr = cxl;
cxr += Params->rx;
cxl.neg();
cxl += Params->rx;
cyt = deltaF;
cyt *= HeightF / 2;
cyb = cyt;
cyt += Params->ry;
cyb.neg();
cyb += Params->ry;
WidthFF = WidthF;
zx = Params->rx;
zy = Params->ry;

jx = Params->jpx;
jy = Params->jpy;

for (pass = 0; pass < 2; pass++)
	{
	ErgTab = ergtab;
	rechnen = true;
	if (pass==1)
		{
		deltaF = delta;
		HeightF = Height;
		WidthF = Width;
		zx = Params->cx;
		zy = Params->cy;
		}
	PbMax = WidthF * HeightF;
	PbPos = 0;
	ey = deltaF;
	ey *= HeightF / 2;
	ey += zy;
	for ( y=0; y<HeightF; y++ )
		{
		ex = deltaF;
		ex.neg();
		ex *= WidthF / 2;
		ex += zx;
		for ( x=0; x<WidthF; x++ )
			{
    		if ( Params->isRefCycle )
    			{
    			xld = ex - Params->rx;
    			yld = ey - Params->ry;
    			xld *= xld;
    			yld *= yld;
    			xld += yld;
    			yld = sqrtl(xld);
    			rechnen = ( yld <= refsizeradius );
    			}
    		if ((((( y * WidthF ) + x ) % TaskAnz ) == TaskNr ) & rechnen==true )
    			{
    			if (( Params->Mmode & 0x01 ) == 0 )
    				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
    			if (( Params->Mmode & 0x01 ) == 1 )
    				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
    			if ( Params->VorlaufIter > 0 )
    				is = bii->iterate_run(Params->VorlaufIter);			// erst bis Anfang-Iter laufen, dann alle punkte einzeln
    			is = bii->iterate_run(Params->MaxIter);
    
    			if ( ((((int)is) & Params->BmodeB ) > 0 ) && ( bii->itercount >= Params->VorlaufIter ) )
    					{
    					xbi = bii->ex;									// arbeitet schneller  und vorweggenommen
    					ybi = bii->ey;
						if ( xbi > cxl )
    						if ( xbi < cxr )
    							if ( ybi > cyb )
    								if ( ybi < cyt )
										{
    									xbi -= cxl;                			// Pixelposition der laufenden Iteration berechnen
    									xld = xbi;
    									xld /= deltald;
    									xe = xld;
    									yld = cyt - ybi;
    									yld /= deltald;
										ye = yld;
										s = ( ye * WidthFF ) + xe;
										Im = ScanTab + s;
										if (pass == 0)
											{ 
											(*Im)++;
											}
										else
											{
											i = *Im;
											*ErgTab = i;
											if ( is == inside )
												{
												if ( i < Params->InnerMin ) Params->InnerMin = i;
												if ( i > Params->InnerMax ) Params->InnerMax = i;
												}
											if ( is == outside )
												{
												if ( i < Params->OuterMin ) Params->OuterMin = i;
												if ( i > Params->OuterMax ) Params->OuterMax = i;
												}
											}    
										}
    				if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
    				if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;
    				}
				}
			ErgTab++;
    		ex += deltaF;
    		p = ( y * WidthF ) + x;
    		if ( p > PbPos ) PbPos = p;
    		if ( StopSignal ) break;
    		}
    	ey -= deltaF;
    	if ( StopSignal ) break;
    	}
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzEU::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
bigint			jy,jx,ey,ex;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
   	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
   	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );

is = bii->iterate_run(Params->MaxIter);
ie->ex = bii->ex;
ie->ey = bii->ey;
delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Ergebnisort entlang einer Linie ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/


void	MbmAnzEL::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_Runout;
awl[i++] = D_CenterOfOrbit;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzEL::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der letzten Iteration ermittelt und dieser im Bild markiert.";
    		break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Ort der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
    		break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzEL::MbmAnzEL( )
{


}
//---------------------------------------------------------------------------
MbmAnzEL::~MbmAnzEL( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzEL::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

}
//---------------------------------------------------------------------------
void	MbmAnzEL::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,x,y,xe,ye,s,hF,wF;
long double		*e,*Im,xld,yld,deltald;
bigint			jy,jx,ey,ex,deltax,deltay,xbi,ybi;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

Height = Params->BildSizeY;
Width = Params->BildSizeX;

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

Params->InnerMin = 0;
Params->OuterMin = 0;
Params->InnerMax = 0;
Params->OuterMax = 0;
Params->ItercountMax = 0;

deltay = Params->BildSize;
deltay /= Width;
deltald = deltay;

deltay = Params->lsy;
deltay -= Params->ley;
deltay /= Height;

deltax = Params->lsx;
deltax -= Params->lex;
deltax /= Width;

jx = Params->jpx;
jy = Params->jpy;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )			// ergebnistabelle l�schen
	{
	*e++ = 0;
	i--;
	}

hF = Params->RefSizeX;                 /* TODO : ????????? */
wF = Params->RefSizeX;
deltax /= Params->RefSizeX;            // Aufl�sungsfaktor
deltay /= Params->RefSizeX;
PbMax = hF;
ey = deltay;
ey *= Height / 2;
cyb = ey + Param->cy;
//ey.neg();
cyt = ey + Param->cy;
ey += Params->ry;
ex = deltay;
ex *= Width / 2;
cxr = ex + Param->cx;
ex.neg();
cxl = ex + Param->cx;
ex += Params->rx;
for ( y=0, x=0; y<hF; y++, x++ )
	{
		{
		if (( Params->Mmode & 0x01 ) == 0 )
			is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
		if (( Params->Mmode & 0x01 ) == 1 )
			is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
		is = bii->iterate_run(Params->MaxIter);

		if ( ((((int)is) & Params->BmodeB ) > 0 ) && ( bii->itercount >= Params->VorlaufIter ) )
				{
				if ( bii->ex > cxl )
					if ( bii->ex < cxr )
						if ( bii->ey > cyt )
							if ( bii->ey < cyb )
								{
								xbi = bii->ex;             			// Pixelposition des Ergebnisses berechnen
								xbi -= cxl;
								xld = xbi;
								xld /= deltald;
								xe = xld;
								ybi = bii->ey;
								ybi -= cyt;
								yld = ybi;
								yld /= deltald;
								ye = yld;
								s = ( ye * Width ) + xe;
								Im = ergtab + s;
								*Im += 1;
								if ( *Im > Params->InnerMax )
									{
									Params->InnerMax = *Im;
									Params->OuterMax = *Im;
									}
								}
				}
		if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
		}
	PbPos = y;
	Application->ProcessMessages();
	if ( StopSignal ) break;
	ey -= deltay;
	ex += deltax;
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzEL::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
bigint			jy,jx,ey,ex;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
switch ( Params->Emode )
	{
    default:	bii = new Apfelmaennchen; 	break;
    case  1:	bii = new Bubblebrot; 		break;
    case  2:	bii = new Runout;	 		break;
    case  3:	bii = new SizeOfOrbit; 		break;
	}
bii->SetParam( Params );

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
   	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
   	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );

is = bii->iterate_run(Params->MaxIter);
ie->ex = bii->ex;
ie->ey = bii->ey;
delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  ErgebnisWinkel  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es wird der Winkel vom Nullpunkt aus zum Ergebnisort angezeigt. 0..360 Grad
*/


void	MbmAnzEW::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_Runout;
awl[i++] = D_CenterOfOrbit;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzEW::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Winkel der letzten Iteration ermittelt und dieser im Bild markiert.";
			break;
	case 1: ah = 	"f�r jeden Punkt in einer Referenzmenge wird der Winkel der Iteration ermittelt, \nbei der das Ergebnis Z das erste Miniumum hat und dieser im Bild markiert.";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzEW::MbmAnzEW( )
{

PosibleTasks = 100;
}
//---------------------------------------------------------------------------
MbmAnzEW::~MbmAnzEW( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzEW::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

//Param = ParIn;
}
//---------------------------------------------------------------------------
void	MbmAnzEW::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				x,y,p;
long double		ze,xw,yw,hw,s,wi;
bigint			jx,jy,ex,ey;
BigIntIter		*bii;
IStatus			is;
long double 	*ErgTab;

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize;
delta /= Width;

jx = Params->jpx;
jy = Params->jpy;

PbMax = Width * Height;
ErgTab = ergtab;
ey = delta;
ey *= Height / 2;
ey += Params->cy;
for ( y=0; y<Height; y++ )
	{
	ex = delta;
	ex.neg();
	ex *= Width / 2;
	ex += Params->cx;
	for ( x=0; x<Width; x++ )
		{
		if ((((( y * Height ) + x ) + TaskNr ) % TaskAnz ) == 0 )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if ( Params->VorlaufIter > 0 )
				is = bii->iterate_PreRun(Params->VorlaufIter);
			is = bii->iterate_run(Params->MaxIter);
			xw = bii->ex;
			yw = bii->ey;
			hw = sqrtl( (xw*xw)+(yw*yw) );
			if ( hw == 0 )
				s = 0.0;
			else
				s = yw / hw;
			wi = asin( s );
			if ( xw < 0 )
				wi = M_PI - wi;
			else
				if ( yw < 0 )
					wi = M_PI + M_PI + wi;
			if ( wi > ( M_PI + M_PI ) )
				wi = 0;
			ze = wi * 57.295779513082320876798154814105;				// 2 PI == 360�
			*ErgTab = ze;
			if ( is == inside )
				{
				if ( ze < Params->InnerMin ) Params->InnerMin = ze;
				if ( ze > Params->InnerMax ) Params->InnerMax = ze;
				}
			if ( is == outside )
				{
				if ( ze < Params->OuterMin ) Params->OuterMin = ze;
				if ( ze > Params->OuterMax ) Params->OuterMax = ze;
				}
			if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
			if ( bii->itercount < Params->ItercountMin ) Params->ItercountMin = bii->itercount;

			}
		ErgTab++;
		ex += delta;
		p = ( x + 1 ) * ( y + 1 );
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= delta;
	if ( StopSignal ) break;
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzEW::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
long double		ze,xw,yw,hw,s,wi;
bigint			jx,jy,ex,ey;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->tpx.bigintError() != 0 ) return;
if ( Params->tpy.bigintError() != 0 ) return;

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
is = bii->iterate_run(Params->MaxIter);
ze = bii->zi;

		ze = 0;
		xw = bii->ex;
		yw = bii->ey;
		hw = sqrtl( (xw*xw)+(yw*yw) );
			if ( hw == 0 )
				s = 0.0;
			else
				s = yw / hw;
			wi = asin( s );
			if ( xw < 0 )
				wi = M_PI - wi;
			else
				if ( yw < 0 )
					wi = M_PI + M_PI + wi;
			if ( wi > ( M_PI + M_PI ) )
				wi = 0;
		ze = wi * 57.295779513082320876798154814105;				// 2 PI == 360�

delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Reverse Buddabrot  oder Distance zum Tp-Ort  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/

void	MbmAnzRB::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_Bubblebrot;
awl[i++] = D_Runout;
awl[i++] = D_LastPeak;
awl[i++] = D_CenterOfOrbit;
awl[i++] = D_StartPointDiffergent;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzRB::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"?????";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzRB::MbmAnzRB( )
{

PosibleTasks = 100;
}
//---------------------------------------------------------------------------
MbmAnzRB::~MbmAnzRB( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzRB::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

Height = Params->BildSizeY;
Width = Params->BildSizeX;
StopSignal = false;

Params->InnerMin = 10e+100;
Params->OuterMin = 10e+100;
Params->InnerMax = 10e-100;
Params->OuterMax = 10e-100;
Params->ItercountMax = 0;
Params->ItercountMin = 999999999;

delta = Params->BildSize;
delta /= Width;

PbMax = Width * Height;
PbPos = 0;
}
//---------------------------------------------------------------------------
void	MbmAnzRB::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				x,y,p;
long double		ze;
bigint			jy,jx,ey,ex,delta,xbi,ybi;
BigIntIter		*bii;
IStatus			is;
long double 	*ErgTab;

bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;
jx = Params->jpx;
jy = Params->jpy;

ErgTab = ergtab;
delta = Params->BildSize;
delta /= Width;

ey = delta;
ey *= Height / 2;
ey += Params->cy;
for ( y=0; y<Height; y++ )
	{
	ex = delta;
	ex *= Width / 2;
	ex.neg();
	ex += Params->cx;
	for ( x=0; x<Width; x++ )
		{
		if ((((( y * Height ) + x ) + TaskNr ) % TaskAnz ) == 0 )
			{
			if (( Params->Mmode & 0x01 ) == 0 )
				is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			if (( Params->Mmode & 0x01 ) == 1 )
				is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
			is = bii->iterate_run(Params->MaxIter);

			if ( is == outofRange )
				*ErgTab = 0.0;
			else
				{
				xbi  = Params->tpx;
				xbi -= bii->ex;
				xbi *= xbi;
				ybi  = Params->tpy;
				ybi -= bii->ey;
				ybi *= ybi;
				ybi += xbi;
				ze = sqrtl(((long double)ybi));
				*ErgTab = ze;
				if ( is == inside )
					{
					if ( ze < Params->InnerMin ) Params->InnerMin = ze;
					if ( ze > Params->InnerMax ) Params->InnerMax = ze;
					}
				if ( is == outside )
					{
					if ( ze < Params->OuterMin ) Params->OuterMin = ze;
					if ( ze > Params->OuterMax ) Params->OuterMax = ze;
					}
				}
			if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;
			}
		ErgTab++;
		ex += delta;
		p = ( y * Width ) + x;
		if ( p > PbPos ) PbPos = p;
		if ( StopSignal ) break;
		}
	ey -= delta;
	if ( StopSignal ) break;
	}
delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzRB::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
// Orbit Analyse ##################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
void	MbmAnzOa::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;
awl[i++] = D_CenterOfOrbit;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzOa::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"jeder Punkt im Verlauf der Iteration eines einzelnen Ortes wird im Bild markiert.";
    		break;
    }
return ah;
}
//---------------------------------------------------------------------------
MbmAnzOa::MbmAnzOa( )
{

biiCallBack = NULL;
oadCallBack = NULL;
}
//---------------------------------------------------------------------------
MbmAnzOa::~MbmAnzOa( )
{

}
//---------------------------------------------------------------------------

void 	MbmAnzOa::SetOrbitKoo( bigint *xbi, bigint *ybi )
{

ox = xbi;
oy = ybi;
}
//---------------------------------------------------------------------------
void	MbmAnzOa::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

//Param = ParIn;
ox = &Params->tpx;
oy = &Params->tpy;
}
//---------------------------------------------------------------------------
void	MbmAnzOa::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,s,xe,ye,imBild;
long double		*Im,xld,yld,deltald;
bigint			jy,jx,ey,ex,delta,xbi,ybi;
BigIntIter		*bii;
IStatus			is;
long double  	a,b,c,cc;

a = Params->ViewAngle;
b = 1.0 - a;
c = Width;
c /= Params->MaxIter;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

Height = Params->BildSizeY;
Width = Params->BildSizeX;

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

Params->InnerMin = 0;
Params->OuterMin = 0;
Params->InnerMax = 0;
Params->OuterMax = 0;
Params->ItercountMax = 0;
Params->ItercountMin = 9999999999;

delta = Params->BildSize;
delta /= Width;
deltald = delta;

jx = Params->jpx;
jy = Params->jpy;

Im = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )			// ergebnistabelle l�schen
	{
	*Im++ = 0;
	i--;
	}
bmin = 200000000;

cxl = delta; 								// anzeigegrenzen
cxl *= Width / 2;
cxr = cxl;
cxr += Params->cx;
cxl.neg();
cxl += Params->cx;
cyt = delta;
cyt *= Height / 2;
cyb = cyt;
cyt += Params->cy;
cyb.neg();
cyb += Params->cy;

ey = *oy;
ex = *ox;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if ( posCallBack != NULL )
	{
							xbi = ex;             			// Pixelposition der ersten Iteration berechnen
							xbi -= cxl;
							xld = xbi;
							xld *= a;
							xld /= deltald;
							xe = xld;
							ybi = cyt;
							ybi -= ey;
							yld = ybi;
							yld /= deltald;
							ye = yld;
							s = ( ye * Width ) + xe;
							Im = ergtab + s;
							*Im += 1;
	posCallBack( xld, yld );
	}
if ( Params->VorlaufIter > 0 )
	is = bii->iterate_PreRun(Params->VorlaufIter);

do {
	is = bii->iterate_run(Params->RepeatJede);
	iNummer = bii->zi;
	imBild = false;
			if ( bii->ex > cxl )
				if ( bii->ex < cxr )
					if ( bii->ey > cyb )
						if ( bii->ey < cyt )
							{
							xbi = bii->ex;             			// Pixelposition der laufenden Iteration berechnen
							xbi -= cxl;
							xld = xbi;
							xld *= a;
							xld /= deltald;
							cc = c;
							cc *= iNummer;
							cc *= b;
							xe = xld + cc;
							ybi = cyt;
							ybi -= bii->ey;
							yld = ybi;
							yld /= deltald;
							ye = yld;
							if ( posCallBack != NULL )
								posCallBack( xld + cc, yld );
							s = ( ye * Width ) + xe;
							Im = ergtab + s;
							*Im += 1;
							if ( oadCallBack != NULL )
								oadCallBack( xld + cc, yld, *Im );
							if ( *Im > Params->InnerMax )
								{
								Params->InnerMax = *Im;
								Params->OuterMax = *Im;
								}
							imBild = true;
							}
			if (bmin > bii->za )
				if  ( bii->za > 0)
					{
					mini = bii->zi;
					bmin = bii->za;
					minx = bii->ex;
					miny = bii->ey;
					}
			if ( posCallBack != NULL )
				if ( !imBild )
					posCallBack( PointisOutside, PointisOutside );
			if ( StopSignal ) break;
	} while ( (is == inside) && (bii->itercount < Params->MaxIter) );
if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;

delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzOa::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
bigint			jy,jx,ey,ex;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if ( Params->VorlaufIter > 0 )
	is = bii->iterate_PreRun(Params->VorlaufIter);

if ( biiCallBack == NULL )
	is = bii->iterate_run(Params->MaxIter);			// Endergebnis liefern
else
	{
	while ( bii->itercount < Params->MaxIter )		// Einzelergebnisse liefern
		{
		is = bii->iterate_run(1);
		biiCallBack(bii);
		}
	}

ie->ex = bii->ex;
ie->ey = bii->ey;
delete bii;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
// Chaos Analyse ##################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
void	MbmAnzCa::getAuswertungsListe(TLMDComboBox* em, int idx)
{
int		i,a;
int		*awl;
awl = DCWd->AktivesFenster->Auswertungsliste;

a = awl[em->ItemIndex];
for ( i=0; i<D_Max_Anzahl; i++ )
	awl[i] = 0;
i = 0;
awl[i++] = D_Apfelmaennchen;

MbmAnz::writeAuswertungsListe( em, a, i );
}

//---------------------------------------------------------------------------
char*	MbmAnzCa::getAuswertungsHelp(TLMDComboBox* em)
{
char	*ah = "Funktionsbeschreibung";

switch ( em->ItemIndex )
	{
	case 0: ah = 	"jeder Punkt im Verlauf der Iteration eines einzelnen Ortes wird im Bild markiert.";
			break;
	}
return ah;
}
//---------------------------------------------------------------------------
MbmAnzCa::MbmAnzCa( )
{


}
//---------------------------------------------------------------------------
MbmAnzCa::~MbmAnzCa( )
{

}
//---------------------------------------------------------------------------
void	MbmAnzCa::NeueAuswertung( TMainParams* Params, long double *ergtab, int TaskAnz )
{

//Param = ParIn;
}
//---------------------------------------------------------------------------
#define	ZN_END	300

void	MbmAnzCa::Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr )
{
int				i,s,xe,ye,faktor,fz;
long double		*e,xld,yld,deltald;
bigint			jy,jx,ey,ex,delta,xbi,ybi,zx,zy,zn[ZN_END];
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

if ( Params->cx.bigintError() != 0 ) return;
if ( Params->cy.bigintError() != 0 ) return;

Params->InnerMin = 0;
Params->OuterMin = 0;
Params->InnerMax = 0;
Params->OuterMax = 0;
Params->ItercountMax = 0;

delta = Params->BildSize;
delta /= Width;
deltald = delta;

jx = Params->jpx;
jy = Params->jpy;

zx.zero();				// zx == zn-1  		aufgetragen in X - Achse
zy.zero();				// zy == zn         aufgetragen in Y - Achse
for ( i=0; i<ZN_END; i++ )
	zn[i].zero();
faktor = Params->RefSizeX;
if ( faktor > ZN_END ) faktor = ZN_END;

e = ergtab;
i = ( Height * Width ) - 1;
while ( i >= 0 )			// ergebnistabelle l�schen
	{
	*e++ = 0;
	i--;
	}

ey = delta;
ey *= Width / 2;
cyb = ey + Params->cy;
cxr = ey + Params->cx;
//ey.neg();
cyt = ey + Params->cy;
cxl = ey + Params->cx;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
fz = 0;
do {
	is = bii->iterate_run(1);
	zx = bii->za;
	i = fz % ZN_END;
	zn[i] = zx;
	i = fz - faktor;
	if ( i >= 0 )
		{
		i = i % ZN_END;
		zy = zn[i];

			if ( zx > cxl )
				if ( zx < cxr )
					if ( zy > cyt )
						if ( zy < cyb )
							{
							xbi = zx;             			// Pixelposition der laufenden Iteration berechnen
							xbi -= cxl;
							xld = xbi;
							xld /= deltald;
							xe = xld;
							ybi = zy;
							ybi -= cyt;
							yld = ybi;
							yld /= deltald;
							ye = yld;
							s = ( ye * Width ) + xe;
							e = ergtab + s;
							*e += 1;
							if ( *e > Params->InnerMax )
								{
								Params->InnerMax = *e;
								Params->OuterMax = *e;
								}
							}
			Application->ProcessMessages();
			if ( StopSignal ) break;
		}
	fz++;
	} while ( (is == inside) && (bii->itercount < Params->MaxIter) );
if ( bii->itercount > Params->ItercountMax ) Params->ItercountMax = bii->itercount;

delete bii;
PbPos = 1;
}

//---------------------------------------------------------------------------
void	MbmAnzCa::TestIter( TMainParams* Params, TDIterErgebnis* ie )
{
bigint			jy,jx,ey,ex;
BigIntIter		*bii;
IStatus			is;

StopSignal = false;
bii = openAuswertung( Params->Emode );
bii->SetParam( Params );

jx = Params->jpx;
jy = Params->jpy;

ey = Params->tpy;
ex = Params->tpx;
if (( Params->Mmode & 0x01 ) == 0 )
	is = bii->iterate_start(jy,jx,ey,ex,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );
if (( Params->Mmode & 0x01 ) == 1 )
	is = bii->iterate_start(ey,ex,jy,jx,Params->MaxIter,Params->MaxRadius, Params->EmodeNr, Params->EmodeZusatz );

is = bii->iterate_run(Params->MaxIter);
ie->ex = bii->ex;
ie->ey = bii->ey;
delete bii;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

