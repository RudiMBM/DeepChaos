#include <vcl.h>
#include <math.h>

#include 	"Global.h"
#include 	"bigint.h"
#include 	"StructDefs.h"
#include 	"Params.h"
//#include 	"Colorbar.h"

#include 	"BigIntIter.h"
#include	"IterArt.h"


//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Iterart Basisklasse  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/
//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Art::Iter_Art()
{
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Art::~Iter_Art()
{

}


//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Bigint  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/
//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Bigint::Iter_Bigint() : Iter_Art()
{
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Bigint::~Iter_Bigint()
{

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Bigint::Vorbereiten()
{

BII->ax2  = BII->ax;
BII->ax2 *= BII->ax;
BII->ay2  = BII->ay;
BII->ay2 *= BII->ay;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Bigint::Rechnen()
{

    BII->ax.malXmal2( BII->ay );			//  oder:  BII->ax *= BII->ay;   BII->ax.mal2();
    BII->ax += BII->cx;

   	BII->ay  = BII->ay2;
    BII->ay -= BII->ax2;
    BII->ay += BII->cy;

	BII->ax2  = BII->ax;
    BII->ax2 *= BII->ax;
	BII->ay2  = BII->ay;
    BII->ay2 *= BII->ay;
    BII->r = BII->ax2;
    BII->r += BII->ay2;

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Floatingpoint  ######################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/
//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Float::Iter_Float() : Iter_Art()
{
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Float::~Iter_Float()
{

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Float::Vorbereiten()
{

ay  = BII->ay;
ax  = BII->ax;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;
cx = BII->cx;
cy = BII->cy;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Float::Rechnen()
{

    ax *= ay;
    ax *= 2.0;
    ax += cx;

   	ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += ay2;
BII->r = r;
BII->ax = ax;
BII->ay = ay;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Grafisch Floatigpoint  #############################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/
//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Grafic::Iter_Grafic() : Iter_Art()
{

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
Iter_Grafic::~Iter_Grafic()
{

}


//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Grafic::Vorbereiten()
{

s0 = (long double)BII->Pm->imagy; 			// sin und cos des Imagin�rpunktes vorbereiten
c0 = (long double)BII->Pm->imagx;
r0 = sqrtl((s0*s0)+(c0*c0));
s0 /= r0;
c0 /= r0;

xo = (long double)BII->cx;
yo = (long double)BII->cy;
xy = (long double)BII->ax;					// Anfangsbedingung iA = 0,0
yy = (long double)BII->ay;
rq = (xy*xy)+(yy*yy);
r = sqrtl(rq);

}

//------------------------------------------------------------------------------------------------------------------------------------------------------
void Iter_Grafic::Rechnen()
{

if ( r == 0 )
	{
	s = c = 0;
	}
else
	{
	s = xy / r;
	c = yy / r;
	}
ry = (r*r)/r0;

sy = (s*c0)-(c*s0);
cy = (c*c0)+(s*s0);

xy = (s*cy)+(c*sy);
xy *= ry;
xy += xo;
yy = (c*cy)-(s*sy);
yy *= ry;
yy += yo;
r = (xy*xy)+(yy*yy);
BII->r = r;
BII->ax = xy;
BII->ay = yy;

}


//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Assembler  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/
//------------------------------------------------------------------------------------------------------------------------------------------------------

Iter_Asm::Iter_Asm() : Iter_Art()
{
}
//------------------------------------------------------------------------------------------------------------------------------------------------------

Iter_Asm::~Iter_Asm()
{

}
//------------------------------------------------------------------------------------------------------------------------------------------------------

void Iter_Asm::Load( unsigned long *axin, __int8 *axsin, bigint *axpi )
{

_asm {
			mov		esi,axin
			mov		ebx,0x0
			mov		ecx,ANZDIGITSZR
itclear1:	mov     esi[ecx*4-4],ebx
			loop    itclear1
			add		esi,VORKOMMADIGITS*4
			mov		edi,axpi.ea
			mov		ecx,ANZDIGITS
itload1:	mov		eax,edi[ecx*4-4]
			mov		esi[ecx*4-4],eax
			loop	itload1
			mov		esi,axpi
			mov		al,[esi].vzpm
			mov		edi,axsin
			mov		Byte Ptr [edi],al
	}
}
//------------------------------------------------------------------------------------------------------------------------------------------------------

void Iter_Asm::Vorbereiten()
{

MaxIterL = 1;
itct = 0;

BIP = BigIntPraez;
BIPm = ((VORKOMMADIGITS + BigIntPraez))*4;
BIPm1 = ((VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez)-1)*4;
BIPa = VORKOMMADIGITS + BigIntPraez;
BIPa1 = VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez;
BIPaz = (VORKOMMADIGITS + BigIntPraez)*2;

ay  = BII->ay;
ax  = BII->ax;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;
cx = BII->cx;
cy = BII->cy;

icxP = &cx;
icyP = &cy;
ayP  = &(BII->ay);
axP  = &(BII->ax);
rP  = &(BII->r);
rmaxP = &(BII->zmaxbi);

Load( &axg[0], &axsg, &ax );
Load( &ayg[0], &aysg, &ay );
Load( &ax2g[0], &ax2sg, &ax2 );
Load( &ay2g[0], &ay2sg, &ay2 );
}
//------------------------------------------------------------------------------------------------------------------------------------------------------

void Iter_Asm::Rechnen()
{

_asm {
			push	ebp
			mov		eax,[ebp+8]
			mov		ebp,eax
itloop:
			// ayg = ayg * axg ----------------------------------------------------
			mov		ecx,[ebp].BIPa			// ayg nach ayhelp umcopieren
itaxmayc:   mov		eax,dword ptr [ebp].ayg[ecx*4 +(VORKOMMADIGITS-1)*4]
			mov		dword ptr [ebp].ayhg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itaxmayc
			mov		ecx,[ebp].BIPaz				// ayg = 0
itaxmayc3:	mov		dword ptr [ebp].ayg[ecx*4-4],0x0
			loop	itaxmayc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer [ebp].ayg[]    (ziel)
										// ESI:	Pointer ih[]			( ml2 )
										// EDI:	Pointer axg[]           	( ml1 )
			lea		esi,[ebp].axg+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ebp].ml1,esi
			lea		esi,[ebp].ayhg
			add		esi,[ebp].BIPm1
			mov		[ebp].ml2,esi

			lea		esi,[ebp].ayhg+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,[ebp].ayg
			add		ecx,[ebp].BIPm
			mov		[ebp].iyl,ecx
it2axmay0:	lea		edi,[ebp].axg
			add		edi,[ebp].BIPm1
			mov		ecx,[ebp].iyl
			add		[ebp].iyl,4
			xor		ebx,ebx				// g = 0
it2axmay1:	mov		eax,[esi]			// ay2g[] - loop
			mul		[edi]				// acc = [ebp].ayg[0] * [ebp].ayg[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi,[ebp].ml1
			jnb		it2axmay1
			add		[ecx],ebx
			add		esi,4
			cmp		esi,[ebp].ml2
			jbe		it2axmay0
			mov		al, byte ptr [ebp].axsg
			cmp		al, byte ptr [ebp].aysg
			jne		it2axmay2
			mov		byte ptr [ebp].aysg,0x01			// vzpm = "+"
			jmp		itmal2w

it2axmay2:  mov     byte ptr [ebp].aysg, 0xff       	// vzpm = "-"
itmal2w:

			// ayg *= 2 ---------------------------------------------------------
			mov		ecx,[ebp].BIPa
			add		ecx,1
			clc									// cf = 0
itmal2b:	rcl		[ebp].ayg[ecx*4+(VORKOMMADIGITS-1)*4],1
			loop    itmal2b

			// ayg += icx -------------------------------------------------------
			mov		al,byte ptr [ebp].aysg
			mov		esi,[ebp].icxP
			cmp     al,byte ptr [esi].vzpm
			jne		itstarts
			mov		ecx,[ebp].BIPa			// addieren
			clc
itstarta:	mov     eax,[esi].ea[ecx*4-4]
			adc     [ebp].ayg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itstarta
			jmp		itw1

itstarts:	mov		ecx,[ebp].BIPa			// subtrahieren, erst vergleichen
			mov		ebx,0x0
itstarts1:	mov		eax,dword ptr [esi].ea[ebx*4]
			//mov		edx,dword ptr [ebp].ayg[(ebx+VORKOMMADIGITS)*4] // nur f�r Test !!!!
			cmp		eax,dword ptr [ebp].ayg[ebx*4+VORKOMMADIGITS*4]
			ja		itstartsi
			jb		itstartsk
			inc		ebx
			loop	itstarts1				// ecx -=1 , If ecx > 0 then goback
			lea		esi,[ebp].ayg			// ayg = +0
			mov		ebx,0x0
			mov		ecx,[ebp].BIPa1
itclear1:	mov     esi[ecx*4-4],ebx
			loop    itclear1
			mov     byte ptr [ebp].aysg,0x01
			jmp		itw1

itstartsk:	mov		ecx,[ebp].BIPa			// ayg > k ...... ayg -= k
			clc
itstartsk1:	mov		eax,[esi].ea[ecx*4-4]
			sbb     [ebp].ayg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itstartsk1
			jmp		itw1

itstartsi:	mov		ecx,[ebp].BIPa			// ayg < k   .....  ayg = k - ayg
			clc
itstartsi1:	mov		eax,[esi].ea[ecx*4-4]
			sbb     eax,[ebp].ayg[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].ayg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itstartsi1
			mov		al,byte ptr [esi].vzpm	// Vorzeichen von k
			mov     byte ptr [ebp].aysg,al
itw1:

			// axg = ax2g - ay2g --------------------------------------------------
			mov		al,byte ptr [ebp].ay2sg
			cmp     al,byte ptr [ebp].ax2sg
			je		itax2ay2s
			mov		ecx,[ebp].BIPa			// addieren
			clc
itax2ay2a:	mov     eax,[ebp].ax2g[ecx*4+(VORKOMMADIGITS-1)*4]
			adc     eax,[ebp].ay2g[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itax2ay2a
			mov		al,byte ptr [ebp].ax2sg		// Vorzeichen von ax2g
			mov     byte ptr [ebp].axsg,al
			jmp		itw2

itax2ay2s:	mov		ecx,[ebp].BIPa			// subtrahieren, erst vergleichen
			mov		ebx,0x0
itax2ay2s1:	mov		eax,dword ptr [ebp].ax2g[ebx*4+VORKOMMADIGITS*4]
			//mov		edx,dword ptr ay2g[(ebx+VORKOMMADIGITS)*4] // nur f�r Test !!!!
			cmp		eax,dword ptr [ebp].ay2g[ebx*4+VORKOMMADIGITS*4]
			ja		itax2ay2si
			jb		itax2ay2sk
			inc		ebx
			loop	itax2ay2s1				// ecx -=1 , If ecx > 0 then goback
			lea		esi,[ebp].axg		 			// axg = +0
			mov		ebx,0x0
			mov		ecx,[ebp].BIPa1
itclear2:	mov     esi[ecx*4-4],ebx
			loop    itclear2
			mov     byte ptr [ebp].axsg,0x01
			jmp		itw2

itax2ay2sk:	mov		ecx,[ebp].BIPa				// ay2g > ax2g ......
			clc
itax2ay2sk1:mov		eax,[ebp].ay2g[ecx*4+(VORKOMMADIGITS-1)*4]
			sbb     eax,[ebp].ax2g[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itax2ay2sk1
			mov		al,byte ptr [ebp].ay2sg		// Vorzeichen von ay2g
			neg		al
			mov     byte ptr [ebp].axsg,al
			jmp		itw2

itax2ay2si:	mov		ecx,[ebp].BIPa				// ay2g < ax2g   .....
			clc
itax2ay2si1:mov		eax,[ebp].ax2g[ecx*4+(VORKOMMADIGITS-1)*4]
			sbb     eax,[ebp].ay2g[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itax2ay2si1
			mov		al,byte ptr [ebp].ax2sg		// Vorzeichen von ax2g
			mov     byte ptr [ebp].axsg,al

			// axg += icy ----------( alt: axg += c ) ----------------------------
itw2:		mov		al,byte ptr [ebp].axsg
			mov		esi,[ebp].icyP
			cmp     al,byte ptr [esi].vzpm
			jne		itaxcs
			mov		ecx,[ebp].BIPa				// addieren
			clc
itaxca:		mov     eax,[esi].ea[ecx*4-4]
			adc     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itaxca
			jmp		itw3

itaxcs:		mov		ecx,[ebp].BIPa				// subtrahieren, erst vergleichen
			mov		ebx,0x0
itaxcs1:	mov		eax,dword ptr [esi].ea[ebx*4]
			//mov		edx,dword ptr axg[(ebx+(VORKOMMADIGITS))*4] // nur f�r Test !!!!
			cmp		eax,dword ptr [ebp].axg[ebx*4+VORKOMMADIGITS*4]
			ja		itaxcsi
			jb		itaxcsk
			inc 	ebx
			loop	itaxcs1					// ecx -=1 , If ecx > 0 then goback
			lea		esi,[ebp].axg   			// axg = +0
			mov		ebx,0x0
			mov		ecx,[ebp].BIPa1
itclear3:	mov     esi[ecx*4-4],ebx
			loop    itclear3
			mov     byte ptr [ebp].axsg,0x01
			jmp		itw3

itaxcsk:	mov		ecx,[ebp].BIPa				// axg > c ...... axg -= c
			clc
itaxcsk1:	mov		eax,[esi].ea[ecx*4-4]
			sbb     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itaxcsk1
			jmp		itw3

itaxcsi:	mov		ecx,[ebp].BIPa				// axg < c   .....  axg = c - axg
			clc
itaxcsi1:	mov		eax,[esi].ea[ecx*4-4]
			sbb     eax,[ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].axg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itaxcsi1
			mov		al,byte ptr [esi].vzpm	// Vorzeichen von c
			mov     byte ptr [ebp].axsg,al

			// ax2g = axg * axg ---------------------------------------------------
itw3:		mov		ecx,[ebp].BIPaz				// ax2g = 0
it2axc3:	mov		dword ptr [ebp].ax2g[ecx*4-4],0x0
			loop	it2axc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer ax2g[]
										// ESI:	Pointer axg[]
										// EDI:	Pointer axg[]
			lea		edi,[ebp].axg+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ebp].ml1,edi
			lea		esi,[ebp].axg
            add		esi,[ebp].BIPm1
			mov		[ebp].ml2,esi

			lea		esi,[ebp].axg+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,[ebp].ax2g
			add		ecx,[ebp].BIPm
			mov		[ebp].iyl,ecx
it2axm0:	lea		edi,[ebp].axg
			add		edi,[ebp].BIPm1
			mov		ecx,[ebp].iyl
			add		[ebp].iyl,4
			xor		ebx,ebx				// g = 0
it2axm1:	mov		eax,[esi]			// ax2g[] - loop
			mul		[edi]				// acc = axg[0] * axg[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi, [ebp].ml1
			jnb		it2axm1
			add		[ecx], ebx
			add		esi, 4
			cmp		esi, [ebp].ml2
			jbe		it2axm0
			mov		byte ptr[ebp].ax2sg,0x01		// vzpm = "+"

			// ay2g = ayg * ayg ---------------------------------------------------
			mov		ecx,[ebp].BIPaz					// ay2g = 0
it2ayc3:	mov		dword ptr [ebp].ay2g[ecx*4-4],0x0
			loop	it2ayc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer ay2g[]
										// ESI:	Pointer [ebp].ayg[]
										// EDI:	Pointer [ebp].ayg[]
			lea		edi,[ebp].ayg+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ebp].ml1,edi
			lea		esi,[ebp].ayg
            add		esi,[ebp].BIPm1
			mov		[ebp].ml2,esi

			lea		esi,[ebp].ayg+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,[ebp].ay2g
            add		ecx,[ebp].BIPm
			mov		[ebp].iyl,ecx
it2aym0:	lea		edi,[ebp].ayg
			add		edi,[ebp].BIPm1
			mov		ecx,[ebp].iyl
			add		[ebp].iyl,4
			xor		ebx,ebx				// g = 0
it2aym1:	mov		eax,[esi]			// ay2g[] - loop
			mul		[edi]				// acc = [ebp].ayg[0] * [ebp].ayg[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi, [ebp].ml1
			jnb		it2aym1
			add		[ecx], ebx
			add		esi, 4
			cmp		esi, [ebp].ml2
			jbe		it2aym0
			mov		byte ptr[ebp].ay2sg,0x01		// vzpm = "+"

			// v = ax2g + ay2g ---------------------------------------------------
			mov		ecx,[ebp].BIPa					// addieren v = ayhg
			clc
itvadd:		mov     eax,[ebp].ax2g[ecx*4+(VORKOMMADIGITS-1)*4]
			adc     eax,[ebp].ay2g[ecx*4+(VORKOMMADIGITS-1)*4]
			mov     [ebp].ayhg[ecx*4+(VORKOMMADIGITS-1)*4],eax
			loop	itvadd

			// Ende einer einzelnen Iteration ----------------------------------
			inc		[ebp].itct

			// Vergleich  v >= vmax -- oder -- ic >= imax ----------------------
			mov		eax,[ebp].itct
			cmp		eax,[ebp].MaxIterL
			jae		itend        		// ende wegen i
			mov		ecx,ANZDIGITS
			mov 	esi,[ebp].rmaxP                         	// max-Radius
			lea		edi,[ebp].ayhg+VORKOMMADIGITS*4
rvergl:		mov		eax,dword ptr [edi]
			cmp		eax,dword ptr [esi]
			jge		itend				// ende wegen v
			add		esi,4
			add		edi,4
			loop	rvergl
			jmp		itloop

			//------------------------------------------------------------------
			// Iterationsende --- Daten �bergeben ------------------------------
			//------------------------------------------------------------------
itend:
			mov		ecx,ANZDIGITS
			mov 	esi,[ebp].rP                         	// Radius
mode0e1:	mov		eax,[ebp].ayhg[ecx*4-4+VORKOMMADIGITS*4]
			mov		[esi].ea[ecx*4-4],eax
			loop	mode0e1
			mov		byte ptr [esi].vzpm, 0x01
			mov		byte ptr [esi].error, biERROR_ok

			mov		ecx,ANZDIGITS
			mov		esi,[ebp].axP    						// endkoordinaten x
mode0e3:	mov		eax,[ebp].axg[ecx*4-4+VORKOMMADIGITS*4]
			mov		[esi].ea[ecx*4-4],eax
			loop	mode0e3
			mov		al,byte ptr [ebp].axsg
			mov		byte ptr [esi].vzpm, al
			mov		byte ptr [esi].error, biERROR_ok

			mov		ecx,ANZDIGITS
			mov		esi,[ebp].ayP                            // endkoordinaten y
mode0e5:	mov		eax,[ebp].ayg[ecx*4-4+VORKOMMADIGITS*4]
			mov		[esi].ea[ecx*4-4],eax
			loop	mode0e5
			mov		al,byte ptr [ebp].aysg
			mov		byte ptr [esi].vzpm, al
			mov		byte ptr [esi].error, biERROR_ok

/*
	ax.malXmal2( ay );
	ax += cx;

   	ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += ay2;
BII->r = r;
BII->ax = ax;
BII->ay = ay;
*/
			pop ebp
	}
}

//------------------------------------------------------------------------------------------------------------------------------------------------------

