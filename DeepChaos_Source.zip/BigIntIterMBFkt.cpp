
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vcl.h>
#include <math.h>

#include "BigInt.h"
#include "BigIntIterMBFkt.h"

//---------------------------------------------------------------------------


extern	int		BigIntPraez;

				// dyn.Berechnungsl�ngen bereitstellen
				// BIP   entspricht:	Pr�zision ( Anzahl der zu berechnenden Nachkommaw�rter )
				// BIPm1 entspricht:  	(VORKOMMADIGITS+ANZDIGITS)-1)*4
				// BIPa  entspricht:  	ANZDIGITS
				// BIPaz entspricht:  	ANZDIGITSZR
extern	int		BIP,BIPm1,BIPa,BIPa1,BIPaz;

bigint 			*icxP;		// Berechnungsgrundlagen
bigint 			*icyP;
bigint 			*spxP;
bigint 			*spyP;
TDMbmParameter 	*parmP;
				bigint		 	MaxRadiusL,ErL;
				unsigned		MaxIterL;
				unsigned		MinIterL;
				int				Emode,EmodeNr;		// Erstellungsmode
TDIterErgebnis 	*ergP;

bool			ContEnable,FirstRun;
long			iyl,ml1,ml2;
//long			maske;								// Pr�zisionsmaske f�r Aufl�sung

unsigned long	ax[ANZDIGITSZR];
unsigned long	ay[ANZDIGITSZR];
unsigned long	ax2[ANZDIGITSZR];
unsigned long	ay2[ANZDIGITSZR];
unsigned long	ayh[ANZDIGITSZR];					// Hilfsvariable, am Ende als V verwendet
char			axs,ays,ayhs,ax2s,ay2s;      		// Signs

/*
unsigned long	iyhmin[ANZDIGITSZR],icmin;
unsigned long	iyhmax[ANZDIGITSZR];
unsigned long	rd[ANZDIGITSZR];					// Radiusdurchschnitt
unsigned long	rdold[ANZDIGITSZR];					// Radiusdurchschnitt old letzter Radius

unsigned long	iow[(ANZDIGITS+2)*OBERWELLEN];		// Struktur f�r V bei n Oberwellen:
													// int[ANZDIGITS] letztes V f�r vergleich
													// int up-down merker
													// int z�hler

unsigned long	trv[TRACKLEVELS];					// Trackverlauf
													/* TODO : iow & trv tynamisch anlegen !! */

long double		x,y,s,c,w;
unsigned long	lastiter,u,ul;
+7
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

bigintiter::bigintiter()
{

BIP = BigIntPraez;
BIPm1 = ((VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez)-1)*4;
BIPa = VORKOMMADIGITS + BigIntPraez;
BIPa1 = VORKOMMADIGITS + VORKOMMADIGITS + BigIntPraez;
BIPaz = (VORKOMMADIGITS + BigIntPraez)*2;

ContEnable = false;
FirstRun = true;
}
//---------------------------------------------------------------------------
unsigned bigintiter::iterate( bigint *icx,bigint *icy,bigint *spx,bigint *spy,
										TDMbmParameter *parm,TDIterErgebnis *erg )
{

icxP = icx;
icyP = icy;
spxP = spx;
spyP = spy;
parmP = parm;
ergP = erg;

ContEnable = false;
FirstRun = true;
iterateinit();
return ( iteratenow());
}
//---------------------------------------------------------------------------
unsigned bigintiter::iterate_start( bigint *icx,bigint *icy,bigint *spx,bigint *spy,
										TDMbmParameter *parm,TDIterErgebnis *erg )
{

icxP = icx;
icyP = icy;
spxP = spx;
spyP = spy;
parmP = parm;
ergP = erg;

ContEnable = true;
FirstRun = true;
iterateinit();
return ( true );
}
//---------------------------------------------------------------------------
unsigned bigintiter::iterate_cont()
{

if ( ContEnable == false )
	{
    //error = biERRORcont;
	return 0;
    }
                       /* TODO : Register zur�ckladen */
return ( iteratenow());
}
//---------------------------------------------------------------------------
unsigned bigintiter::iterate_all()
{

ContEnable = false;
return ( iteratenow());
}
//---------------------------------------------------------------------------
void bigintiter::iterateinit()
{

MaxRadiusL = parmP->MaxRadius;
MaxRadiusL *= parmP->MaxRadius;	// Max Radius wird hoch zwei verglichen !   /* TODO : Diese mul ist integer!! auf bigint �ndern */
MaxIterL = parmP->MaxIter;
MinIterL = parmP->MinIter;
Emode = parmP->Emode;
EmodeNr = parmP->EmodeNr;

_asm {
			//  ic = 0 ---------------------------------------------------------
			mov		esi,dword ptr [ebp+8]
			mov		[esi].ic,0

			lea		esi,ax              // Juliapoint laden
			call	itclear
			mov		edi,[spxP]
			call	itload
			mov		byte ptr [axs],al
			lea		esi,ay
			call	itclear
			mov		edi,[spyP]
			call	itload
			mov		byte ptr [ays],al

			lea		esi,ayh             // Datenfelder initialisieren
			call	itclear
			lea		esi,ax2
			call	itclear
			lea		esi,ay2
			call	itclear
			mov		[ayhs],1            // Signs = +
			mov		[ax2s],1
			mov		[ay2s],1
			jmp		itstartv

			// -----------------------------------------------------------------

itclear:	mov		ebx,0x0
itclear2:	mov		ecx,[BIPaz]
itclear1:	mov     esi[(ecx-1)*4],ebx
			loop    itclear1
			ret

itload:		mov		ecx,[BIPa]
itload1:	mov		ebx,edi[(ecx-1)*4]
			mov     esi[(ecx+VORKOMMADIGITS-1)*4],ebx
			loop    itload1
			mov		al,byte ptr [edi].vzpm
			ret

itstartv:
	}
iteratenow();
FirstRun = false;
}
//---------------------------------------------------------------------------
unsigned bigintiter::iteratenow()
{

asm {
			cmp		FirstRun, TRUE
            je		firststart
firstnow:   mov     FirstRun, FALSE


itloop:     mov		ebx,[Emode]     // Datenaufbereitung pro Durchlauf
   			cmp		ebx,NEXTANGLE
			jne		itloopw

			lea		esi,ax		// ax,ay nach xm,ym f�r n�chste Differenz Mode 11 copieren ---------
			lea		edi,xm
            call	copym
			mov		al,[axs]
            mov		[xms],al
			lea		esi,ay
			lea		edi,ym
            call	copym
			mov		al,[ays]
            mov		[yms],al

itloopw:
			// ay = ay * ax ----------------------------------------------------
		    mov		ecx,[BIPa]			// ay nach ayhelp umcopieren
itaxmayc:   mov		eax,dword ptr ay[(ecx+(VORKOMMADIGITS-1))*4]
			mov		dword ptr ayh[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itaxmayc
itaxmayc2:	mov		ecx,[BIPaz]				// ay = 0
itaxmayc3:	mov		dword ptr ay[(ecx-1)*4],0x0
			loop	itaxmayc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer ay[]    (ziel)
										// ESI:	Pointer ih[]			( ml2 )
										// EDI:	Pointer ax[]           	( ml1 )
			lea		esi,ax+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ml1],esi
			lea		esi,ayh
            add		esi,[BIPm1]
			mov		[ml2],esi

			lea		esi,ayh+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,ay
            add		ecx,[BIPm1]
			mov		[iyl],ecx
it2axmay0:	lea		edi,ax
            add		edi,[BIPm1]
			mov		ecx,[iyl]
			add		[iyl],4
			xor		ebx,ebx				// g = 0
it2axmay1:	mov		eax,[esi]			// ay2[] - loop
			mul		[edi]				// acc = ay[0] * ay[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi,[ml1]
			jnb		it2axmay1
			add		[ecx],ebx
			add		esi,4
			cmp		esi,[ml2]
			jbe		it2axmay0
			mov		al, byte ptr [axs]
			cmp		al, byte ptr [ays]
			jne		it2axmay2

			mov		byte ptr [ays],0x01			// vzpm = "+"
			jmp		itmal2w

it2axmay2:  mov     byte ptr [ays], 0xff       	// vzpm = "-"

			// ay *= 2 ---------------------------------------------------------
itmal2w:	mov		ecx,[BIPa]
			add		ecx,1
			clc									// cf = 0
itmal2b:	rcl		ay[(ecx+(VORKOMMADIGITS-1))*4],1
			loop    itmal2b

			// ay += icx ---- ( alt: ay += k ) ---------------------------------
itstart:	mov		al,byte ptr [ays]
			mov		esi,[icxP]
			cmp     al,byte ptr [esi].vzpm
			jne		itstarts
			mov		ecx,[BIPa]			// addieren
			clc
itstarta:	mov     eax,[esi].ea[(ecx-1)*4]
			adc     ay[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itstarta
			jmp		itw1

itstarts:	mov		ecx,[BIPa]			// subtrahieren, erst vergleichen
			mov		ebx,0x0
itstarts1:	mov		eax,dword ptr [esi].ea[ebx*4]
			//mov		edx,dword ptr ay[(ebx+VORKOMMADIGITS)*4] // nur f�r Test !!!!
			cmp		eax,dword ptr ay[(ebx+(VORKOMMADIGITS))*4]
			ja		itstartsi
			jb		itstartsk
			inc		ebx
			loop	itstarts1				// ecx -=1 , If ecx > 0 then goback
			lea		esi,ay			// ay = +0
			call	itclear
			mov     byte ptr [ays],0x01
			jmp		itw1

itstartsk:	mov		ecx,[BIPa]			// ay > k ...... ay -= k
			clc
itstartsk1:	mov		eax,[esi].ea[(ecx-1)*4]
			sbb     ay[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itstartsk1
			jmp		itw1

itstartsi:	mov		ecx,[BIPa]			// ay < k   .....  ay = k - ay
			clc
itstartsi1:	mov		eax,[esi].ea[(ecx-1)*4]
			sbb     eax,ay[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ay[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itstartsi1
			mov		al,byte ptr [esi].vzpm	// Vorzeichen von k
			mov     byte ptr [ays],al

			// ax = ax2 - ay2 --------------------------------------------------
itw1:		mov		al,byte ptr [ay2s]
			cmp     al,byte ptr [ax2s]
			je		itax2ay2s
			mov		ecx,[BIPa]			// addieren
			clc
itax2ay2a:	mov     eax,ax2[(ecx+(VORKOMMADIGITS-1))*4]
			adc     eax,ay2[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itax2ay2a
			mov		al,byte ptr [ax2s]		// Vorzeichen von ax2
			mov     byte ptr [axs],al
			jmp		itw2

itax2ay2s:	mov		ecx,[BIPa]			// subtrahieren, erst vergleichen
			mov		ebx,0x0
itax2ay2s1:	mov		eax,dword ptr ax2[(ebx+(VORKOMMADIGITS))*4]
			//mov		edx,dword ptr ay2[(ebx+VORKOMMADIGITS)*4] // nur f�r Test !!!!
			cmp		eax,dword ptr ay2[(ebx+(VORKOMMADIGITS))*4]
			ja		itax2ay2si
			jb		itax2ay2sk
			inc		ebx
			loop	itax2ay2s1				// ecx -=1 , If ecx > 0 then goback
			lea		esi,ax		 			// ax = +0
			call	itclear
			mov     byte ptr [axs],0x01
			jmp		itw2

itax2ay2sk:	mov		ecx,[BIPa]				// ay2 > ax2 ......
			clc
itax2ay2sk1:mov		eax,ay2[(ecx+(VORKOMMADIGITS-1))*4]
			sbb     eax,ax2[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itax2ay2sk1
			mov		al,byte ptr [ay2s]		// Vorzeichen von ay2
			neg		al
			mov     byte ptr [axs],al
			jmp		itw2

itax2ay2si:	mov		ecx,[BIPa]				// ay2 < ax2   .....
			clc
itax2ay2si1:mov		eax,ax2[(ecx+(VORKOMMADIGITS-1))*4]
			sbb     eax,ay2[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itax2ay2si1
			mov		al,byte ptr [ax2s]		// Vorzeichen von ax2
			mov     byte ptr [axs],al

			// ax += icy ----------( alt: ax += c ) ----------------------------
itw2:		mov		al,byte ptr [axs]
			mov		esi,[icyP]
			cmp     al,byte ptr [esi].vzpm
			jne		itaxcs
			mov		ecx,[BIPa]				// addieren
			clc
itaxca:		mov     eax,[esi].ea[(ecx-1)*4]
			adc     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itaxca
			jmp		itw3

itaxcs:		mov		ecx,[BIPa]				// subtrahieren, erst vergleichen
			mov		ebx,0x0
itaxcs1:	mov		eax,dword ptr [esi].ea[ebx*4]
			//mov		edx,dword ptr ax[(ebx+(VORKOMMADIGITS))*4] // nur f�r Test !!!!
			cmp		eax,dword ptr ax[(ebx+(VORKOMMADIGITS))*4]
			ja		itaxcsi
			jb		itaxcsk
			inc 	ebx
			loop	itaxcs1					// ecx -=1 , If ecx > 0 then goback
			lea		esi,ax   			// ax = +0
			call	itclear
			mov     byte ptr [axs],0x01
			jmp		itw3

itaxcsk:	mov		ecx,[BIPa]				// ax > c ...... ax -= c
			clc
itaxcsk1:	mov		eax,[esi].ea[(ecx-1)*4]
			sbb     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itaxcsk1
			jmp		itw3

itaxcsi:	mov		ecx,[BIPa]				// ax < c   .....  ax = c - ax
			clc
itaxcsi1:	mov		eax,[esi].ea[(ecx-1)*4]
			sbb     eax,ax[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ax[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itaxcsi1
			mov		al,byte ptr [esi].vzpm	// Vorzeichen von c
			mov     byte ptr [axs],al

firststart:	// ax2 = ax * ax ---------------------------------------------------
itw3:		mov		ecx,[BIPaz]				// ax2 = 0
it2axc3:	mov		dword ptr ax2[(ecx-1)*4],0x0
			loop	it2axc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer ax2[]
										// ESI:	Pointer ax[]
										// EDI:	Pointer ax[]
			lea		edi,ax+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ml1],edi
			lea		esi,ax
            add		esi,[BIPm1]
			mov		[ml2],esi

			lea		esi,ax+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,ax2
            add		ecx,[BIPm1]
			mov		[iyl],ecx
it2axm0:	lea		edi,ax
			add		edi,[BIPm1]
			mov		ecx,[iyl]
			add		[iyl],4
			xor		ebx,ebx				// g = 0
it2axm1:	mov		eax,[esi]			// ax2[] - loop
			mul		[edi]				// acc = ax[0] * ax[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi, [ml1]
			jnb		it2axm1
			add		[ecx], ebx
			add		esi, 4
			cmp		esi, [ml2]
			jbe		it2axm0
			mov		byte ptr [ax2s],0x01		// vzpm = "+"

			// ay2 = ay * ay ---------------------------------------------------
itw4:		mov		ecx,[BIPaz]					// ay2 = 0
it2ayc3:	mov		dword ptr ay2[(ecx-1)*4],0x0
			loop	it2ayc3
										// EAX:	Low word
										// EDX:	High Word
										// EBX: g ( �bertrag )
										// ECX: Pointer ay2[]
										// ESI:	Pointer ay[]
										// EDI:	Pointer ay[]
			lea		edi,ay+((VORKOMMADIGITS)*4)	// Loopabbruchadr. laden
			mov		[ml1],edi
			lea		esi,ay
            add		esi,[BIPm1]
			mov		[ml2],esi

			lea		esi,ay+((VORKOMMADIGITS)*4)		// Startadr. laden
			lea		ecx,ay2
            add		ecx,[BIPm1]
			mov		[iyl],ecx
it2aym0:	lea		edi,ay
			add		edi,[BIPm1]
			mov		ecx,[iyl]
			add		[iyl],4
			xor		ebx,ebx				// g = 0
it2aym1:	mov		eax,[esi]			// ay2[] - loop
			mul		[edi]				// acc = ay[0] * ay[n]
			add		eax,ebx             // acc += g
			mov		ebx, 0x0  			// g = 0;  CF unver�ndert !
			adc		ebx, 0x0
			add 	eax, [ecx]
			adc 	ebx, 0x0
			mov     [ecx], eax
			add		ebx, edx
			sub		ecx, 4
			sub		edi, 4
			cmp		edi, [ml1]
			jnb		it2aym1
			add		[ecx], ebx
			add		esi, 4
			cmp		esi, [ml2]
			jbe		it2aym0
			mov		byte ptr [ay2s],0x01		// vzpm = "+"

			// v = ax2 + ay2 ---------------------------------------------------
			mov		ecx,[BIPa]					// addieren v = ayh
			clc
itvadd:		mov     eax,ax2[(ecx+(VORKOMMADIGITS-1))*4]
			adc     eax,ay2[(ecx+(VORKOMMADIGITS-1))*4]
			mov     ayh[(ecx+(VORKOMMADIGITS-1))*4],eax
			loop	itvadd

            // Vorbereitungen abgeschlossen ? ----------------------------------
   			cmp		FirstRun, TRUE
            je		mode0e

			// Ende einer einzelnen Iteration ----------------------------------
            mov		esi,dword ptr [ebp+8]
			inc		[esi].ic
            mov		eax,[esi].ic

			// Vergleich  v >= vmax -- oder -- ic >= imax ----------------------
nextiter:	mov		eax,dword ptr ayh[(VORKOMMADIGITS)*4]
			cmp		eax,dword ptr MaxRadiusL.ea[(0)*4]    /* TODO : v-vergleich einf�gen */
			jge		itendce				// ende wegen v
            mov		esi,dword ptr [ebp+8]
			mov		eax,[esi].ic
			cmp		eax,[MaxIterL]
			jae		itendce        		// ende wegen i
   			cmp		ContEnable, TRUE
            jne		itloop
            				               /* TODO : Register sichern */
			jmp		itend				// Ergebnisdaten aufbereiten und Pause

            // ANZITER:  keine weitere analyse ---------------------------------
mode0:
			jmp		nextiter

			//------------------------------------------------------------------
copyiyh:    push	ecx
			push	eax
			mov		ecx,[BIPaz]				// ayh Register nach [edi] copieren
copyiyh1:	mov		eax,ayh[(ecx-1)*4]
			mov		edi[((ecx-1)*4)],eax
			loop	copyiyh1
			pop		eax
			pop		ecx
			ret


			//------------------------------------------------------------------
			// Iterationsende --- Daten �bergeben ------------------------------
			//------------------------------------------------------------------
itendce:	mov		ContEnable, FALSE				// absolutes Ende
itend:		mov		lastiter,eax
			// Ergebnisdaten aufbereiten ---------------------------------------
mode0e:		mov		ecx,ANZDIGITS
            lea 	esi,ErL                         	// Radius
mode0e1:	mov		eax,ayh[((ecx-1)+(VORKOMMADIGITS))*4]
			mov		[esi].ea[((ecx-1)*4)],eax
			loop	mode0e1
			mov		byte ptr [esi].vzpm, 0x01
			mov		byte ptr [esi].error, biERROR_ok

mode0e2:	mov		ecx,ANZDIGITS
			mov		esi,[ergP]
            lea 	esi,[esi].ex     						// endkoordinaten x
mode0e3:	mov		eax,ay[((ecx-1)+(VORKOMMADIGITS))*4]
			mov		[esi].ea[((ecx-1)*4)],eax
			loop	mode0e3
			mov		al,byte ptr [ays]
			mov		byte ptr [esi].vzpm, al
			mov		byte ptr [esi].error, biERROR_ok

mode0e4:	mov		ecx,ANZDIGITS
			mov		esi,[ergP]
            lea 	esi,[esi].ey                            // endkoordinaten y
mode0e5:	mov		eax,ax[((ecx-1)+(VORKOMMADIGITS))*4]
			mov		[esi].ea[((ecx-1)*4)],eax
			loop	mode0e5
			mov		al,byte ptr [axs]
			mov		byte ptr [esi].vzpm, al
			mov		byte ptr [esi].error, biERROR_ok
	}
ergP->er = sqrt((long double)ErL);
ergP->ei = ic;
return ContEnable;

}
