#include <vcl.h>
#pragma hdrstop

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
//#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"

#include "ThreadErzeugen.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------

__fastcall TTeilBildErzeugen::TTeilBildErzeugen(bool CreateSuspended): TThread(CreateSuspended)
{

}
//---------------------------------------------------------------------------
void __fastcall TTeilBildErzeugen::Execute()
{

Anzeige->Erstellen( Params, ergtab, TaskAnz ,TaskNr );
*FM = true;
}
//---------------------------------------------------------------------------
