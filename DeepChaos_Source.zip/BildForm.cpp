//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#include <math.h>
#pragma hdrstop

#include <time.h>

#include "Tastencodes.h"
#include "Bigint.h"
#include "Global.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "HelpForm.h"
#include "ZeitReihe.h"
#include "OrbitAnalyse.h"
#include "PhasenAnalyse.h"
#include "BildForm.h"
#include "jpeg.hpp"
#include "DCMAIN.h"
#include "ThreadErzeugen.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "LMDBaseEdit"
#pragma link "LMDControl"
#pragma link "LMDCustomBevelPanel"
#pragma link "LMDCustomControl"
#pragma link "LMDCustomEdit"
#pragma link "LMDCustomExtSpinEdit"
#pragma link "LMDCustomMaskEdit"
#pragma link "LMDCustomPanel"
#pragma link "LMDSpinEdit"
#pragma resource "*.dfm"

int		bh[] = { 270, 540, 1080, 100, 200, 300, 400, 500, 600,  800, 1000, 1200, 1400, 1600, 1800, 2000, 300 };
int		bw[] = { 480, 960, 1920, 150, 300, 450, 600, 750, 900, 1200, 1500, 1800, 2100, 2400, 2700, 3000, 300 };

String	FormatStr = "0.00000000000000000000";

//---------------------------------------------------------------------------
TZoom::TZoom()
{
win = 3;
h2 = 20;
w3 = 30;
cx = 30;
cy = 20;
Cycle = false;
}
TZoom::TZoom(int x, int y, int width)
{
if ( width < 3 ) { w3=3; h2=2; }
else {
	w3 = width / 3;
	h2 = w3 * 2;
	w3 *= 3;
	}
Breite = w3;
cx = x;
cy = y;
}
void TZoom::NewPos(int x, int y)
{
cx = x;
cy = y;
}
void TZoom::NewWidth(int width)
{
if ( width < 3 ) { w3=3; h2=2; }
else {
	w3 = width / 3;
	h2 = w3 * 2;
	w3 *= 3;
	}
Breite = w3;
}
void TZoom::WidthChange(int widthadd)
{
w3 += widthadd;
if ( w3 < 3 ) { w3=3; h2=2; }
else {
	w3 = w3 / 3;
	h2 = w3 * 2;
	w3 *= 3;
	}
Breite = w3;
}
TZoom::operator TRect()
{
TRect	r;

if ( Cycle )
	{
	r.Top = cy - ( Breite / 3 );
	r.Bottom = r.Top + Breite;
	r.Left = cx - ( Breite / 3 );
	r.Right = r.Left + Breite;
	}
else
	{
	r.Top = cy - 1 - ( h2 / 2 );
	r.Bottom = r.Top + 2 + h2;
	r.Left = cx - 1 - ( w3 / 2 );
	r.Right = r.Left + 2 + w3;
	}
return r;
}
//---------------------------------------------------------------------------
TBildKoo::TBildKoo(){}
void	TBildKoo::Set(TMainParams *pi)
{

pl = pi;
delta = pl->BildSize;
delta /= pl->BildSizeX;
deltad = delta;
cxr = delta;
cxr *= (pl->BildSizeX / 2);
cxl = pl->cx;
cxl -= cxr;
cxr += pl->cx;
cyt = delta;
cyt *= (pl->BildSizeY / 2);
cyb = pl->cy;
cyb -= cyt;
cyt += pl->cy;
}
bool  TBildKoo::IsInside(TMainParams *pi)
{
if ( pi->cx > cxl )
	if ( pi->cx < cxr )
		if ( pi->cy > cyb )
			if ( pi->cy < cyt )
				return true;
return false;
}
bool  TBildKoo::IsInside(bigint *x, bigint *y)
{
if ( *x > cxl )
	if ( *x < cxr )
		if ( *y > cyb )
			if ( *y < cyt )
				return true;
return false;
}
bool  TBildKoo::XInside(bigint *x)
{
if ( *x > cxl )
	if ( *x < cxr )
		return true;
return false;
}
bool  TBildKoo::YInside(bigint *y)
{
if ( *y > cyb )
	if ( *y < cyt )
		return true;
return false;
}
int	  TBildKoo::X(bigint &x)
{
long double d;

d = (x - cxl);
d /= deltad;
return d;
}
int	  TBildKoo::Y(bigint &y)
{
long double d;

d = (cyt - y);
d /= deltad;
return d;
}
long double	  TBildKoo::Xd(bigint &x)
{
long double d;

d = x;
d -= (long double)(cxl);
d /= deltad;
return d;
}
long double	  TBildKoo::Yd(bigint &y)
{
long double d;

d = (long double)(cyt);
d -= (long double)(y);
d /= deltad;
return d;
}
long double	  TBildKoo::Xd(int x)
{
long double d;

d = x;
d -= (long double)(cxl);
d /= deltad;
return d;
}
long double	  TBildKoo::Yd(int y)
{
long double d;

d = (long double)(cyt);
d -= y;
d /= deltad;
return d;
}
long double	  TBildKoo::Xd(long double x)
{
long double d;

d = x;
d -= (long double)(cxl);
d /= deltad;
return d;
}
long double	  TBildKoo::Yd(long double y)
{
long double d;

d = (long double)(cyt);
d -= y;
d /= deltad;
return d;
}
bigint	TBildKoo::X(int x)
{
bigint bi;

bi = delta;
bi *= x;
bi += cxl;
return bi;
}
bigint	TBildKoo::Y(int y)
{
bigint bi;

bi = delta;
bi *= y;
bi.neg();
bi += cyt;
return bi;
}
int	  TBildKoo::X(long double x)
{
long double d;

d = cxl;
d *= -1;
d += x;
d /= deltad;
return d;
}
int	  TBildKoo::Y(long double y)
{
long double d;

d = cyt;
d -= y;
d /= deltad;
return d;
}
long double  TBildKoo::PixelAbstand( int x )
{
return ( deltad * x );
}
int  TBildKoo::PixelAbstand( long double dx )
{
return ( dx / deltad );
}

//---------------------------------------------------------------------------
//***************************************************************************
//---------------------------------------------------------------------------

__fastcall TBildWd::TBildWd(TComponent* Owner)
	: TForm(Owner)
{
int		i;
bigint	z;

z = 0.0;
ZusatzAnzeigeTab[0] = &ShowKoordinaten;	  	// Achtung: Tabelle mit Zusatz-opXXXX synchron halten !!!!
ZusatzAnzeigeTab[1] = &ShowAnsicht;
ZusatzAnzeigeTab[2] = &ShowSternenhimmel;
ZusatzAnzeigeTab[3] = &ShowJuliapunkt;
ZusatzAnzeigeTab[4] = &ShowTestpunkt;
ZusatzAnzeigeTab[5] = &ShowHinterlegteMBM;
ZusatzAnzeigeTab[6] = &ShowZoomrahmen;
ZusatzAnzeigeTab[7] = &ShowIterNrOrt;
ZusatzAnzeigeTab[8] = &ShowCenterOfOrbit;
ZusatzAnzeigeTab[9] = &ShowImaginaerpunkt;
ZusatzAnzeigeTab[10] = &ShowMinZ;
ZusatzAnzeigeTab[11] = &ShowOrbitLinien;
ZusatzAnzeigeTab[12] = &ShowBildCenter;
ZusatzAnzeigeTab[13] = &ShowLinie;
ZusatzAnzeigeTab[14] = &ShowReferenzpunkt;
ZusatzAnzeigeTab[15] = &ShowLinienStart;
ZusatzAnzeigeTab[16] = &ShowLinienEnd;
ZusatzAnzeigeTab[17] = &ShowFirstIter;
ZusatzAnzeigeTab[18] = &ShowBezierVector;

Statusp0 = StatusBar->Panels->Items[0];
Statusp1 = StatusBar->Panels->Items[1];
Statusp2 = StatusBar->Panels->Items[2];

GoIsDone = false;
BerechnenLaeuft = false;
CommandKD = &NoKeyDown;

Sf = DCWd->Sftemp;
BildSizeLb->ItemIndex = DCWd->SettingsFile->ReadInteger(Sf, "Size", 2 );
BildxEd->Value = DCWd->SettingsFile->ReadInteger(Sf, "SizeX", 300 );
BildyEd->Value = DCWd->SettingsFile->ReadInteger(Sf, "SizeY", 300 );
BildSizeLbClick(NULL);													// Ist freies Format sichtbar?
Params.Emode = D_Apfelmaennchen;
Anzeige = new MbmAnzMI();
Anzeige->SetBase( &Params );
Anzeige->SetFullSize( &Params );

Application->CreateForm(__classid(TColorBarWd), &ColorBarWd);
ColorBarWd->MasterWd = this;
zrdSL = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormActivate(TObject *Sender)
{

DCWd->MenueFenster = this;
if ( GoIsDone )
	{
	if ( this != DCWd->AktivesFenster )
		{
		DCWd->BildShow(WdNr);
		DCWd->DisplMbmEdit();
		if ( ColorBarWd->Visible )
			ColorBarWd->BringToFront();
		}
	}
BWdTbar->GradientStartColor = clGradientActiveCaption;
}
//---------------------------------------------------------------------------


void __fastcall TBildWd::FormDeactivate(TObject *Sender)
{

BWdTbar->GradientStartColor = clSilver;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormShow(TObject *Sender)
{

if ( ColorBarWd->Visible )
	ColorBarWd->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormCloseQuery(TObject *Sender, bool &CanClose)
{

if ( this == DCWd->BildWdTab[AnimationsEditWd] ) CanClose = false;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormClose(TObject *Sender, TCloseAction &Action)
{
TMemoryStream 	*pStream = new TMemoryStream;

	DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
	DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
	DCWd->SettingsFile->WriteInteger(Sf, "Size", BildSizeLb->ItemIndex );
	DCWd->SettingsFile->WriteInteger(Sf, "SizeX", BildxEd->Value  );
	DCWd->SettingsFile->WriteInteger(Sf, "SizeY", BildyEd->Value );
	pStream->Write( &Params, sizeof(Params) );
	pStream->Seek( (long)0, soBeginning );
	DCWd->SettingsFile->WriteBinaryStream(Sf, "Params", pStream );
	delete pStream;

	ColorBarWd->CloseNow = true;
	ColorBarWd->Close();

	delete[] Ergebnis;
	delete ImageBitmap;
	delete Anzeige;
	DCWd->BildClose(WdNr);
	Action = caFree;
	return;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::GoBtnClick(TObject *Sender)
{

GoBtnNow();
}



void __fastcall TBildWd::GoBtnNow()
{
int			bsi;                             // Index der Bildgr��entab

bsi = BildSizeLb->ItemIndex;
if ( bsi == 16 )
	{
	if ( (bh[bsi] = BildyEd->Value ) > 4000 ) return;
	if ( (bw[bsi] = BildxEd->Value ) > 4000 ) return;
	}
Params.BildSizeX = bildsizex = bw[bsi];
Params.BildSizeY = bildsizey = bh[bsi];
Bildgerechnet = false;
ReadLastSession();
GoBtnNow2();
}



void __fastcall TBildWd::GoBtnNow2()
{
int		   	i;
long double *e;

BildSizeP->Visible = false;
BildIm->Constraints->MaxHeight = Params.BildSizeY;
BildIm->Constraints->MinHeight = Params.BildSizeY;
BildIm->Constraints->MaxWidth = Params.BildSizeX;
BildIm->Constraints->MinWidth = Params.BildSizeX;

ClientWidth  = Params.BildSizeX + AnzP->Padding->Left + AnzP->Padding->Right; // + 75;
ClientHeight = Params.BildSizeY + AnzP->Padding->Top + AnzP->Padding->Bottom + StatusBar->Height + BWdTbar->Height;

BWdTbar->Visible =  true;
D_Tb->Caption = "D";
B_Tb->Caption = "B";
P_Tb->Caption = "P";
Pkt_Tb->Caption = ".";
W_Tb->Caption = "W";
O_Tb->Caption = "O";
F_Tb->Caption = "F";

ErgebnisSize = Params.BildSizeX * Params.BildSizeY;
Ergebnis = new long double [ ErgebnisSize ];
e = Ergebnis;
for ( i=0; i<ErgebnisSize; i++ )
	*e++ = 0;
ImageBitmap = new Graphics::TBitmap();
ImageBitmap->PixelFormat = pf32bit;
ImageBitmap->Height = Params.BildSizeY; 	//BildIm->Height;
ImageBitmap->Width = Params.BildSizeX;		//BildIm->Width;
KeyPreview = true;

Bezierpx = Params.BildSizeX / 2;
Bezierpy = Params.BildSizeY / 2;

StatusBar->Repaint();
BildKoo.Set(&Params);
ColorBarWd->StatusBar->Panels->Items[0]->Text = "Bild " + IntToStr(WdNr);
ColorBarWd->ParamPaint( &Params );
if ( this != DCWd->OrbitWd )    				// nicht f�r Orbit, oder andere - Windows  ????
	{
	DCWd->DisplMbmEdit();
	}
GoIsDone = true;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::ReadLastSession()
{
int		 	i;
TStream 	*pStream = new TMemoryStream(); 			 // sind Daten aus letzter session vorhANDEN?

i = DCWd->SettingsFile->ReadBinaryStream(Sf, "Params", pStream );
if ( i > 0 )
	{
	i = pStream->Read( &Params, sizeof(Params) );
	Params.BildSizeX = bildsizex;			// falls andere Gr��e, geladene Params-Size �berschreiben
	Params.BildSizeY = bildsizey;
	Bildgerechnet = false;
	}
delete pStream;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::BildImMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y)
{
TRect		zr;
int			x,y;
long double v,xd,yd;
bigint		bi;
WORD	   	MouseKey;							// Mouse l�st OnKey aus

if ( !GoIsDone ) return;
BildImCursorMove( X, Y , MouseKey = isMouseMove );

if ( Button == mbLeft )
	{
	v = Ergebnis[(( Params.BildSizeX * Y ) + X )];
	switch ( DCWd->BlendenModeCb->ItemIndex )
		{
		case bePipetteMin:	Params.Zlevel = v;
							DCWd->BlendeMinEd->Text = FloatToStr( v );
							ColorBarWd->SetScala();
							BildIm->Cursor = crCross;
							break;
		case bePipetteMax:  Params.Zscala = v;
							DCWd->BlendeMaxEd->Text = FloatToStr( v );
							ColorBarWd->SetScala();
							BildIm->Cursor = crCross;
							break;
		}
	switch ( FktKey )
		{
		case comCycleZoom:
		case comZoom:		cx = X;
							cy = Y;
							ZoomKeyDown( MouseKey = isMouseMove );
							break;
		case menPunkt:		cx = X;
							cy = Y;
							CursorKeyDown( MouseKey = isMouseMove );
							break;
		}
		if ( DCWd->OrbitWd != NULL ) if ( DCWd->OrbitWd->Visible == true )
			{
			DCWd->OrbitWd->CursorXbi = BildKoo.X( X );
			DCWd->OrbitWd->CursorYbi = BildKoo.Y( Y );
			DCWd->OrbitWd->TpMouseMove( MouseKey = isMouseMove );
			//DCWd->OrbitWd->ActiveControl = NULL;                 /* TODO : ????? */
			}
		if ( ZeitRWd != NULL ) if ( ZeitRWd->Visible == true )
			{
			ZeitRWd->CursorXbi = BildKoo.X( X );
			ZeitRWd->CursorYbi = BildKoo.Y( Y );
			ZeitRWd->TpMouseMove( MouseKey = isMouseMove );
			}
	}
if ( Button == mbRight )
	{
	switch ( FktKey )
		{
		case comCycleZoom:
		case comZoom:       xd = cx - X;
							xd *= xd;
							yd = cy - Y;
							yd *= yd;
							cs = sqrt( xd + yd );
							ZoomKeyDown( MouseKey = isMouseMove );
							break;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::BildImMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
int     	x,y;
long double xd,yd;
WORD	   	MouseKey;							// Mouse l�st OnKey aus

BildImCursorMove( X, Y ,isMouseMove );
if ( Shift.Contains(ssLeft) )
	{
	switch ( FktKey )
		{
		case comCycleZoom:
		case comZoom:		cx = X;
							cy = Y;
							ZoomKeyDown( MouseKey = isMouseMove );
							break;
		case menPunkt:		cx = X;
							cy = Y;
							CursorKeyDown( MouseKey = isMouseMove );
							break;
		}
	if ( DCWd->OrbitWd != NULL )
		{
		DCWd->OrbitWd->CursorXbi = BildKoo.X( X );
		DCWd->OrbitWd->CursorYbi = BildKoo.Y( Y );
		DCWd->OrbitWd->TpMouseMove( MouseKey = isMouseMove );
		//DCWd->OrbitWd->ActiveControl = NULL;                 /* TODO : ????? */
		}
	}
if ( Shift.Contains(ssRight) )
	{
	switch ( FktKey )
		{
		case comCycleZoom:
		case comZoom:       xd = cx - X;
							xd *= xd;
							yd = cy - Y;
							yd *= yd;
							cs = sqrt( xd + yd );
							ZoomKeyDown( MouseKey = isMouseMove );
							break;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::BildImCursorMove(int X, int Y, WORD Key)
{
long double	v,*e,*ee,dx,dy,di,ds;
int     	x,y;
bigint		bx,by;

bx = BildKoo.X(X);
by = BildKoo.Y(Y);
if ( !GoIsDone || !Bildgerechnet ) return;
if ( X >= 0 && Y >=0 && X < Params.BildSizeX && Y < Params.BildSizeY )
	{
	v = Ergebnis[(( Params.BildSizeX * Y ) + X )];
	DCWd->ColorNrEd->Text = IntToStr(ColorBarWd->GetTabNr(v));
	DCWd->ColorNrP->Color = ColorBarWd->GetColor32(v);
	DCWd->ErgebnisEd->Text = FormatFloat(FormatStr, v);
	DCWd->FensterEd->Text = StatusBar->Panels->Items[0]->Text;
	e = Ergebnis;
	ee = e + ErgebnisSize;
	x = 0;
	while ( e < ee )
		if ( *e++ == v )
			x++;
	DCWd->HistEd->Text = IntToStr( x );
	}
DCWd->CPosXEd->Text = IntToStr(X);
DCWd->CPosYEd->Text = IntToStr(Y);
DCWd->CursXEd->Text = "";
DCWd->CursYEd->Text = "";
bx.setKommastellenAnzeige(Params.MinKommaStellen);
bx.bigint2str( DCWd->CursXEd, true );
by.bigint2str( DCWd->CursYEd, true );
dx = bx;
dy = by;
v = sqrt( dx*dx + dy*dy );
DCWd->REd->Text = FormatFloat(FormatStr, v);
if ( v == 0 )
	ds = 0.0;
else
	ds = dy / v;
di = asin( ds );
if ( dx < 0 )
	di = M_PI - di;
else
	if ( dy < 0 )
		di = M_PI + M_PI + di;
if ( di > ( M_PI + M_PI ) )
	di = 0;
v = di * 57.295779513082320876798154814105;				// 2 PI == 360�
DCWd->ArgEd->Text = FormatFloat(FormatStr, v);
/*
CursorXbi = BildKoo.X(X);
CursorXbi.bigint2str( DCWd->CursXEd, true );
CursorYbi = BildKoo.Y(Y);
CursorYbi.bigint2str( DCWd->CursYEd, true );
*/
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormKeyPress(TObject *Sender, wchar_t &Key)
{
WORD	w;

if ( Key < L'0' | Key > L'9' )
	{
	w = Key;
	FormKeyNow( w );
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{

//if ( ActiveControl != NULL )
//BildIm->Canvas->TextOut( 10,10, " Focus " + ActiveControl->Name);

if ( Shift.Contains(ssCtrl) )
	switch ( Key )
		{
		case VK_UP:			Key = VK_UP_Ctrl;		break;
		case VK_DOWN:		Key = VK_DOWN_Ctrl;		break;
		case VK_LEFT:		Key = VK_LEFT_Ctrl;		break;
		case VK_RIGHT:		Key = VK_RIGHT_Ctrl;	break;
		}

	switch ( Key )
		{
		case VK_F1:         DCWd->showHelpTbtClick(NULL);
							break;
		case VK_UP_Ctrl:
		case VK_DOWN_Ctrl:
		case VK_LEFT_Ctrl:
		case VK_RIGHT_Ctrl:
		case VK_ESCAPE:
		case VK_RETURN:
		case VK_UP:
		case VK_DOWN:
		case VK_LEFT:
		case VK_RIGHT:
		case VK_PRIOR:
		case VK_NEXT:		FormKeyNow( Key );
							break;
		case VK_NUMPAD0:    FormKeyNow( Key = L'0' );
							break;
		case VK_NUMPAD1:    FormKeyNow( Key = L'1' );
							break;
		case VK_NUMPAD2:    FormKeyNow( Key = L'2' );
							break;
		case VK_NUMPAD3:    FormKeyNow( Key = L'3' );
							break;
		case VK_NUMPAD4:    FormKeyNow( Key = L'4' );
							break;
		case VK_F4:			TJPEGImage *jp = new TJPEGImage();
							try
								{
								jp->Assign(BildIm->Picture->Bitmap);
								jp->SaveToFile(DCWd->PfadEd->Text + FormatFloat("_0000",DCWd->PfadNummerEd->Value) + ".jpg");
								DCWd->PfadNummerEd->Value += 1;
								}
							__finally
								{
								delete jp;
								}
							break;
		}
		String a;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::FormKeyNow( WORD &Key )
{

if ( BerechnenLaeuft )
	{
	if ( Key == VK_ESCAPE )
		Anzeige->StopSignal = true;
	return;
	}
if ( Key == NeuesKommando )
	{
	Statusp1->Text = "";
	OptKey = FktKey = CommandKey = 0;
	CommandKD = &NoKeyDown;
	}

CommandKD( Key );

int	  	bn = 0;
bool	tempCycle = false;

//switch ( (Char)Key )
switch ( Key )
	{
	case comMain:       DCWd->BringToFront();
						break;
	case comHelp:		HelpWd->Visible = true;
						HelpWd->BringToFront();
						break;
	case comOrbit:      DCWd->OaTbClick(NULL);
						break;
	case comZReihe:     DCWd->ZrTbClick(NULL);
						break;
	case comphanlYse: 	DCWd->PhasenraumBtClick(NULL);
						break;
	case comOption:     Statusp1->Text = "Option";
						CommandKey = Key;
						CommandKD = &OptionKeyDown;
						break;
	case comBild4:		bn++;
	case comBild3:		bn++;
	case comBild2:		bn++;
	case comBild1:		bn++;
						DCWd->BildShow(bn);
						break;
	case comColor:		ColorBarWd->Visible = true;
                    	ColorBarWd->BringToFront();
						break;
	case menDatei:      Statusp1->Text = "Datei";
						CommandKD = &DateiKeyDown;
						break;
	case menParam:      Statusp1->Text = "Parameter";
						CommandKD = &ParamKeyDown;
						break;
	case menBildGet:    Statusp1->Text = "Bild holen";
						CommandKD = &DateiKeyDown;
						break;
	case menPunkt:		Statusp1->Text = "Punkt";
						CommandKey = Key;
						FktKey = Key;
						CommandKD = &PunktKeyDown;
						break;
	case comWhereIs:	Statusp1->Text = "Wo ist:";
						CommandKD = &WhereIsKeyDown;
						break;
	case comCycleZoom:  tempCycle = true;
	case comZoom:		Statusp1->Text = "Zoom";
						CommandKD = &ZoomKeyDown;
						CommandKey = Key;
						FktKey = Key;
						SaveXbi = Params.zcx;
						SaveYbi = Params.zcy;
						SaveZoomSize = Params.ZoomSize;
						SaveZoomCycle = Params.isCycleZoom;
						Params.isCycleZoom = tempCycle;
						cx = BildKoo.X( Params.zcx );
						cy = BildKoo.Y( Params.zcy );
						cs = Params.BildSizeX / 8;							//BildKoo.PixelAbstand( Params.ZoomSize ) / 2.0;
						ZoomKeyDown( Key = comTodo );
						break;
	case comNeuZoomIn:	ZoomKeyDown( Key = Key );
						break;
	case comFertigRechnen: NeuRechnen( true );
						NeuZeichnen();
						Key = VK_ESCAPE;
						break;
	case comNeuRechnen: NeuRechnen( false );
	case comNeuZeichnen:NeuZeichnen();
						Key = VK_ESCAPE;
						break;
	case comStop:		Anzeige->StopSignal = true;
						Statusp1->Text = "gestoppt";
						break;
	case comQuit:		Close();
						break;
	}
switch ( Key )
	{
	case VK_ESCAPE:     RefreshAnzeige(0);
	case VK_RETURN:		Statusp1->Text = "";
						OptKey = FktKey = CommandKey = 0;
						CommandKD = &NoKeyDown;
						break;
	}

if ( CommandKey != FktKey )
	{
	FktKey = 0;
	OptKey = 0;
	}
}
//---------------------------------------------------------------------------
void TBildWd::NoKeyDown( WORD &Key)
{
// do nothing
}

//---------------------------------------------------------------------------
void TBildWd::OptionKeyDown( WORD &Key)
{

switch ( Key )
	{
	case comAnzeige:    Statusp1->Text = "Anzeige mit:";
						Key = 0;
						CommandKD = &AnzMitKeyDown;
						break;
	}
}
//---------------------------------------------------------------------------
void TBildWd::AnzMitKeyDown( WORD &Key)
{

switch ( Key )
	{
	case comKoordinaten:Params.ZusatzMode ^= opKoordinaten;
						DCWd->DisplMbmEdit();
						NeuZeichnen();
						Key = VK_ESCAPE;
						break;
	}
}
//---------------------------------------------------------------------------
void TBildWd::ZoomKeyDown( WORD &Key)
{
bool		todo = false;
int 		bn = -1;

switch ( Key )
	{
	case VK_UP:			cy -= 1;	todo = true;		break;
	case VK_DOWN:		cy += 1;	todo = true;		break;
	case VK_LEFT:		cx -= 1;	todo = true;		break;
	case VK_RIGHT:		cx += 1;	todo = true;		break;
	case VK_UP_Ctrl:
	case VK_PRIOR:
	case VK_RIGHT_Ctrl: cs += 1;   todo = true;
						break;
	case VK_LEFT_Ctrl:
	case VK_NEXT:
	case VK_DOWN_Ctrl:  cs -= 1;   todo = true;
						if ( cs < 3 )
							cs = 3;
						break;
	case comFullSize:   cs = Params.BildSizeX / 2;
						todo = true;
						break;
	case SetFromPunkt:  CommandKD = &SetFromPunktKey;
						Key = 0;
						break;
	case VK_RETURN:     break;								// Daten OK, nicht rechnen
	case comNeuZoomIn:  NeuZoom();
						NeuRechnen( false );
						NeuZeichnen();
						Key = VK_ESCAPE;
						break;
	case VK_ESCAPE:		Params.zcx = SaveXbi;				// alles zur�ck
						Params.zcy = SaveYbi;
						Params.ZoomSize = SaveZoomSize;
						Params.isCycleZoom = SaveZoomCycle;
						break;
	case comTodo:		todo = true;
						break;
	case srcBild4:		bn++; 								// Zoom aus anderem bild
	case srcBild3:		bn++;
	case srcBild2:		bn++;
	case srcBild1:		bn++;
	case srcOrbit:		bn++;
						if ( bn < 0 ) return;
						if ( DCWd->BildWdTab[bn] == NULL ) return;
						Params.zcx = DCWd->BildWdTab[bn]->Params.zcx;
						Params.zcy = DCWd->BildWdTab[bn]->Params.zcy;
						Params.ZoomSize = DCWd->BildWdTab[bn]->Params.ZoomSize;
						Params.isCycleZoom = DCWd->BildWdTab[bn]->Params.isCycleZoom;
						Key = VK_RETURN;
						RefreshAnzeige( opZoomrahmen );
						Statusp2->Text = "Zoom aus Bild " + IntToStr(bn);
						return;
						break;
	}
if ( Key == isMouseMove )
	todo = true;
else
	BildImCursorMove( cx, cy ,OptKey );
if ( todo )
	{
	Params.zcx = BildKoo.X(cx);
	Params.zcy = BildKoo.Y(cy);
	Params.ZoomSize = BildKoo.PixelAbstand( cs ) * 2.0;
	RefreshAnzeige( opZoomrahmen );
	Key = 0;
	}
}
//---------------------------------------------------------------------------
void TBildWd::SetFromPunktKey( WORD &Key)
{
bool	done = true;

switch ( Key )
	{
	case comImagpoint:	Params.zcx = Params.imagx;
						Params.zcy = Params.imagy;
						break;
	case comTestpoint:  Params.zcx = Params.tpx;
						Params.zcy = Params.tpy;
						break;
	case comRefpoint:	Params.zcx = Params.refpx;
						Params.zcy = Params.refpy;
						break;
	case comJuliapoint: Params.zcx = Params.jpx;
						Params.zcy = Params.jpy;
						break;
	case comStartLine:	Params.zcx = Params.lsx;
						Params.zcy = Params.lsy;
						break;
	case comEndLine:    Params.zcx = Params.lex;
						Params.zcy = Params.ley;
						break;
	default:			done = false;
						break;
	}
if ( done )
	{
	cx = BildKoo.X( Params.zcx );
	cy = BildKoo.Y( Params.zcy );
	CommandKD = &ZoomKeyDown;
	RefreshAnzeige( opZoomrahmen );
	Key = 0;
	}
}
//---------------------------------------------------------------------------

void TBildWd::DateiKeyDown(WORD &Key)
{

switch ( Key )
	{
	case comOeffnen:	DateiOeffnen( NULL );
						break;
	case comSaveAs:		SpeichernAs( NULL );
						break;
	case comSave:
						break;
	}

Key = VK_ESCAPE;
CommandKD = &NoKeyDown;
}
//---------------------------------------------------------------------------

void TBildWd::ParamKeyDown(WORD &Key)
{
int		i = 0;

switch ( Key )
	{
	case srcAllView:	Anzeige->SetFullSize( &Params );
						break;
	case srcLastView:	ReadLastSession();
						break;
	case srcBild4:      i++;
	case srcBild3:      i++;
	case srcBild2:      i++;
	case srcBild1:      i++;
						if ( DCWd->BildWdTab[i] != NULL )
							{
							Params = DCWd->BildWdTab[i]->Params;
							Params.BildSizeX = ImageBitmap->Width;			// falls andere Gr��e, geladene Params-Size �berschreiben
							Params.BildSizeY = ImageBitmap->Height;
							ColorBarWd->ParamPaint( &Params );
							}
						break;
	case srcDB:			break;
	case srcOrbit:      if ( DCWd->OrbitWd != NULL )
							{
							Params.cx = DCWd->OrbitWd->Params.cx;
							Params.cy = DCWd->OrbitWd->Params.cy;
							Params.BildSize = DCWd->OrbitWd->Params.BildSize;
							}
						break;
	}
DCWd->DisplMbmEdit();
Key = VK_ESCAPE;
CommandKD = &NoKeyDown;
}
//---------------------------------------------------------------------------
void TBildWd::PunktKeyDown(WORD &Key)
{
int		i;

ZusatzModeTemp = 0;
switch ( Key )
	{
	case comImagpoint:	Statusp1->Text = "Imag.Pkt";
						pktx = &(Params.imagx);
						pkty = &(Params.imagy);
						pktxEd = DCWd->ImagpXEd;
						pktyEd = DCWd->ImagpYEd;
						ZusatzModeTemp |= opImaginaerpunkt;
						break;
	case comTestpoint:	Statusp1->Text = "Test.Pkt";
						pktx = &(Params.tpx);
						pkty = &(Params.tpy);
						pktxEd = DCWd->TpXEd;
						pktyEd = DCWd->TpYEd;
						ZusatzModeTemp |= opTestpunkt;
						break;
	case comRefpoint:	Statusp1->Text = "Referenz.Pkt";
						pktx = &(Params.refpx);
						pkty = &(Params.refpy);
						pktxEd = DCWd->RefPxEd;
						pktyEd = DCWd->RefPyEd;
						ZusatzModeTemp |= opReferenzpunkt;
						break;
	case comJuliapoint:	Statusp1->Text = "Julia.Pkt";
						pktx = &(Params.jpx);
						pkty = &(Params.jpy);
						pktxEd = DCWd->JpXEd;
						pktyEd = DCWd->JpYEd;
						ZusatzModeTemp |= opJuliapunkt;
						break;
	case comStartLine:	Statusp1->Text = "StartLinie";
						pktx = &(Params.lsx);
						pkty = &(Params.lsy);
						pktxEd = DCWd->StartXEd;
						pktyEd = DCWd->StartYEd;
						ZusatzModeTemp |= opLinienStart;
						break;
	case comEndLine:	Statusp1->Text = "EndLinie";
						pktx = &(Params.lex);
						pkty = &(Params.ley);
						pktxEd = DCWd->EndXEd;
						pktyEd = DCWd->EndYEd;
						ZusatzModeTemp |= opLinie;
						ZusatzModeTemp |= opLinienEnd;
						break;
	}
if ( ZusatzModeTemp > 0 )						// Erledigt wenn ZusatzModeTemp gesetzt
	{
	Statusp2->Text = "�bernehmen = Return";
	cx = BildKoo.X( *pktx );
	cy = BildKoo.Y( *pkty );
	SaveXbi = *pktx;
	SaveYbi = *pkty;
	OptKey = Key;
	CommandKD = &CursorKeyDown;
	Key = 0;
	RefreshAnzeige( ZusatzModeTemp ); 			// Auch alten Zustand schon mal Anzeigen
	}
}
//---------------------------------------------------------------------------

void TBildWd::CursorKeyDown(WORD &Key)
{
static bigint sx,sy;

bigint		bi;
bool		todo = false;
long double seekmax,*erg;

switch ( Key )
	{
	case VK_UP:			cy -= 1;	todo = true;		break;
	case VK_DOWN:		cy += 1;	todo = true;		break;
	case VK_LEFT:		cx -= 1;	todo = true;		break;
	case VK_RIGHT:		cx += 1;	todo = true;		break;
	case comGetFrom:	Statusp1->Text = "Get von";
						CommandKD = &GetKeyDown;
						Key = 0;
						break;
	case fktSetAbs:     pktx->str2bigint( pktxEd );
						pkty->str2bigint( pktyEd );
						Key = 0;
						break;
	case fktSetNull:	pktx->zero();					// bigint 0.0 berechnen
						pkty->zero();
						pkty->bigint2str( pktyEd, true );
						pktx->bigint2str( pktxEd, true );
						Key = 0;
						break;
	case fktSeekMaxErg: seekmax = (Params.InnerMax > Params.OuterMax)?Params.InnerMax:Params.OuterMax;
						erg = Ergebnis;
						cy = 0;
						while ( cy < Params.BildSizeY & todo == false )
							{
							cx = 0;
							while ( cx < Params.BildSizeX & todo == false )
								{
								if ( *erg++ >= seekmax )
									todo = true;
								cx++;
								}
							cy++;
							}
						cx--;
						cy--;
						break;
	case VK_ESCAPE:		*pktx = SaveXbi;				// alles zur�ck
						*pkty = SaveYbi;
						Statusp2->Text = "";
						if ( pktxEd != NULL )
							{
							pkty->bigint2str( pktyEd, true );
							pktx->bigint2str( pktxEd, true );
							}
						break;
	case fktCenterLoad:
	case VK_RETURN:		*pktx = BildKoo.X(cx);
						*pkty = BildKoo.Y(cy);
								sx -= *pktx;
								sy -= *pkty;
						Statusp2->Text = "";
						if ( pktxEd != NULL )
							{
							pkty->bigint2str( pktyEd, true );
							pktx->bigint2str( pktxEd, true );
							}
						if ( Key == fktCenterLoad )
							{
							pkty->bigint2str( DCWd->ImagYEd, true );
							pktx->bigint2str( DCWd->RealXEd, true );
							DCWd->ImagYEd->Modified = true;
							DCWd->RealXEd->Modified = true;
							Key = VK_RETURN;
							}
						break;
	}
if ( Key == isMouseMove )
	todo = true;
else
	BildImCursorMove( cx, cy ,OptKey );

if ( todo )
	{
	switch ( OptKey )
		{
		case comRefpoint:
		case comTestpoint: 	if ( DCWd->OrbitWd != NULL )
								{
								DCWd->OrbitWd->CursorXbi = BildKoo.X( cx );
								DCWd->OrbitWd->CursorYbi = BildKoo.Y( cy );
								DCWd->OrbitWd->TpMouseMove( OptKey );
								//DCWd->OrbitWd->ActiveControl = NULL;                 /* TODO : ????? */
								}      // hier kein break!
							if ( ZeitRWd != NULL )
								{
								ZeitRWd->CursorXbi = BildKoo.X( cx );
								ZeitRWd->CursorYbi = BildKoo.Y( cy );
								ZeitRWd->TpMouseMove( OptKey );
								//DCWd->ZeitRWd->ActiveControl = NULL;                 /* TODO : ????? */
								}      // hier kein break!
		case comStartLine:
		case comEndLine:
		case comImagpoint:
		case comJuliapoint:
		default:			*pktx = BildKoo.X(cx);
							*pkty = BildKoo.Y(cy);
							sx = *pktx;
							sy = *pkty;
							if ( pktxEd != NULL )
								{
								pkty->bigint2str( pktyEd, true );
								pktx->bigint2str( pktxEd, true );
								}
							break;
		}
	Key = 0;
	}
if ( Key == 0 ) RefreshAnzeige( ZusatzModeTemp );
}
//---------------------------------------------------------------------------

void TBildWd::GetKeyDown(WORD &Key)
{
int bn = -1;

switch ( Key )
	{
	case srcBild4:		bn++;   							// Selben Punkt aus anderm Bild holen
	case srcBild3:		bn++;
	case srcBild2:		bn++;
	case srcBild1:		bn++;
	case srcOrbit:		bn++;	Key = 0;		break;
	case comImagpoint:	*pktx = Params.imagx;          	// Von anderen Punkten im selben Bild holen
						*pkty = Params.imagy;	break;
	case comRefpoint:	*pktx = Params.refpx;
						*pkty = Params.refpy;	break;
	case comTestpoint:	*pktx = Params.tpx;
						*pkty = Params.tpy;		break;
	case comJuliapoint:	*pktx = Params.jpx;
						*pkty = Params.jpy;		break;
	case comStartLine:	*pktx = Params.lsx;
						*pkty = Params.lsy;		break;
	case comEndLine:	*pktx = Params.lex;
						*pkty = Params.ley;		break;
	}
if ( bn < 0 ) return;
if ( DCWd->BildWdTab[bn] == NULL ) return;
if ( Key == 0 )
	{
	// hier verarbeiten     - Bigints holen - Pixelpos berechnen - anzeigen
	switch ( OptKey )
		{
		case comImagpoint:	*pktx = DCWd->BildWdTab[bn]->Params.imagx;
							*pkty = DCWd->BildWdTab[bn]->Params.imagy;
							break;
		case comRefpoint:	*pktx = DCWd->BildWdTab[bn]->Params.refpx;
							*pkty = DCWd->BildWdTab[bn]->Params.refpy;
							break;
		case comTestpoint:	*pktx = DCWd->BildWdTab[bn]->Params.tpx;
							*pkty = DCWd->BildWdTab[bn]->Params.tpy;
							break;
		case comJuliapoint:	*pktx = DCWd->BildWdTab[bn]->Params.jpx;
							*pkty = DCWd->BildWdTab[bn]->Params.jpy;
							break;
		case comStartLine:	*pktx = DCWd->BildWdTab[bn]->Params.lsx;
							*pkty = DCWd->BildWdTab[bn]->Params.lsy;
							break;
		case comEndLine:	*pktx = DCWd->BildWdTab[bn]->Params.lex;
							*pkty = DCWd->BildWdTab[bn]->Params.ley;
							break;
		}
	}
if ( pktxEd != NULL )
	{
	pktx->setKommastellenAnzeige(DCWd->BildWdTab[bn]->Params.MinKommaStellen);
	pktx->bigint2str( pktxEd, true );
	pkty->bigint2str( pktyEd, true );
	}
cx = BildKoo.X(*pktx);
cy = BildKoo.Y(*pkty);
Key = 0;
CursorKeyDown ( Key );              // anzeigen
Key = VK_ESCAPE;
CommandKD = &NoKeyDown;         	// Point NICHT weiterbearbeiten, da Pr�zision verloren geht
}
//------------------------------------------------------------------------------

void TBildWd::WhereIsKeyDown(WORD &Key)
{
TMainParams	*px;
bigint		bx,by;
int bn = 0;

px = &Params;
switch ( Key )
	{
	case srcBild4:		bn++;
	case srcBild3:		bn++;
	case srcBild2:		bn++;
	case srcBild1:		bn++;
						Key = 0;
						if ( DCWd->BildWdTab[bn] == NULL ) return;
						px = &(DCWd->BildWdTab[bn]->Params);
						if ( px == NULL ) return;
						ZeichneBildKoo( &(DCWd->BildWdTab[bn]->BildKoo) , clBlue );
						Key = VK_RETURN;
						return;
						break;
	case srcDB:
	case comImagpoint:  bx = px->cx;
						by = px->cy;
						break;
	case comJuliapoint: bx = px->jpx;
						by = px->jpy;
						break;
	case comLinie:
	case comTestpoint:  bx = px->tpx;
						by = px->tpy;
						break;
	case comZoom:		break;
	}

ZeichneKoordinaten( &bx, &by, clBlue);
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::PaintLine(bigint *xs, bigint *ys, bigint *xe, bigint *ye)
{
int		x1,y1,x2,y2;
TCanvas *z;

x1 = BildKoo.X( *xs );
y1 = BildKoo.Y( *ys );
x2 = BildKoo.X( *xe );
y2 = BildKoo.Y( *ye );
z = BildIm->Canvas;
z->Pen->Color = clRed;
z->MoveTo(x1,y1);
z->LineTo(x2,y2);
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::PaintFk(int x, int y, TColor pc )
{
TCanvas *z;

RefreshAnzeige(0);
z = BildIm->Canvas;
z->Pen->Color = pc;
z->MoveTo(x,0);
z->LineTo(x,BildIm->Height);
z->MoveTo(0,y);
z->LineTo(BildIm->Width,y);
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::PaintKoordinaten()
{
bigint			center = 0;
long double		ldx,a;
long			x,y,fontsize,fs;
double			xd,yd,xd2,yd2;
TCanvas			*vwc;
bool			zrd;

fontsize = (BildKoo.Y(0.0)-BildKoo.Y(2.0))/20;
fs = Params.BildSizeY / 50;
fontsize = fontsize > fs ? fs : fontsize;
vwc = BildIm->Canvas;
vwc->Pen->Color = 0x0000ff00;
vwc->Brush->Style = bsClear;
vwc->Font->Name = "Arial";
vwc->Font->Size = fontsize;                    			// Schriftgr��e in Pixel
vwc->Font->Pitch = fpFixed;
vwc->Font->Color = clGreen;
vwc->Brush->Style = bsClear;
a = 1.0;
zrd = ( zrdSL != NULL ); 								// Wenn "*.zsa" oder wenn im Orbitwin die Datei "*.oad" geschrieben werden soll
if ( DCWd->AktivesFenster == DCWd->BildWdTab[0] )
	{
	a = DCWd->OrbitWd->Params.ViewAngle;    			// ViewAngel f�r Orbitwin abfragen
	}

if ( Params.BildSize > 0.01 )
				{
				x = BildKoo.X(center);
				y = BildKoo.Y(center);
				if ( BildKoo.XInside(&center) )
					{
					vwc->MoveTo(x * a,0);
					vwc->LineTo(x * a,Params.BildSizeY);
					if (zrd)
						{
						xd = BildKoo.Xd(center) * a;
						yd = Params.BildSizeY;
						zrdSL->Add("X  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",0)+";  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  &H"+IntToHex(vwc->Pen->Color,6)+";  " + "0,0r;");
						}
					}
				if ( BildKoo.YInside(&center) )
					{
					vwc->MoveTo(0,y);
					vwc->LineTo(Params.BildSizeX * a,y);
					if (zrd)
						{
						xd = Params.BildSizeX * a;
						yd = BildKoo.Yd(center);
						zrdSL->Add("Y  "+FormatFloat("000000.000",0)+";  "+FormatFloat("000000.000",yd)+";  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  &H"+IntToHex(vwc->Pen->Color,6)+";  " + "0,0i;");
						}
					}
				for ( ldx = 2.0; ldx > 0.4; ldx = ldx / 2.0 )
					{
					vwc->Ellipse((BildKoo.X(ldx*-1)*a),BildKoo.Y(ldx),(BildKoo.X(ldx)*a),BildKoo.Y(ldx*-1));
					vwc->TextOut((x*a)+1,BildKoo.Y(ldx)-fontsize/2-fontsize, FormatFloat("+0.0i", ldx));
					vwc->TextOut((x*a)+1,BildKoo.Y(ldx*-1),              FormatFloat("0.0i", ldx*-1));
					vwc->TextOut((BildKoo.X(ldx*-1)*a)+1,y,          FormatFloat("0.0r", ldx*-1));
					vwc->TextOut((BildKoo.X(ldx)*a)+1,y,             FormatFloat("+0.0r", ldx));
					if (zrd)
						{
						xd = BildKoo.Xd(ldx*-1.0) * a;
						yd = BildKoo.Yd(ldx);
						xd2 = BildKoo.Xd(ldx) * a;
						yd2 = BildKoo.Yd(ldx*-1.0);
						zrdSL->Add("C  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  "+FormatFloat("000000.000",xd2)+";  "+FormatFloat("000000.000",yd2)+";  &H"+IntToHex(vwc->Pen->Color,6)+";  " + FormatFloat("0.0",ldx)+";");
						}
					}
				}
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::NeuZoom()
{

Params.cx = Params.zcx;
Params.cy = Params.zcy;
Params.BildSize = Params.ZoomSize;
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::NeuRechnen( bool RestRechnen )
{
#define		Tanz    10                   // Anzahl der zu benutzenden Tasks
TTeilBildErzeugen	  	*tt[Tanz];
bool					ttfinished[Tanz];
int					  	tn, rv, fertig,cc;
int      				anfang,beendet;
int						tanzakt;

if ( !RestRechnen )
	if ( !DCWd->GetEditParameter() ) return;
StopTb->Visible = true;
rTb->Visible = false;
iTb->Visible = false;
BildKoo.Set(&Params);
DCWd->DisplMbmEdit();
Statusp2->Style = psOwnerDraw;
Timer1->Enabled = true;
BerechnenLaeuft = true;

anfang = GetTickCount();
										//Anzeige->Erstellen( &Params, Ergebnis );
tanzakt = Anzeige->PosibleTasks;
if ( Tanz < tanzakt ) tanzakt = Tanz;
cc = StrToInt(DCWd->CoresCountEd->Text);
if ( cc < tanzakt ) tanzakt = cc;
if ( !RestRechnen )
	Anzeige->NeueAuswertung( &Params, Ergebnis, tanzakt );

for ( tn=0; tn<tanzakt; tn++ )
	{
	tt[tn] = new TTeilBildErzeugen(true);
	tt[tn]->Priority = tpLower;
	tt[tn]->FreeOnTerminate = True;
	tt[tn]->Anzeige = Anzeige;
	tt[tn]->Params = &Params;
	tt[tn]->ergtab = Ergebnis;
	tt[tn]->TaskAnz = tanzakt;
	tt[tn]->TaskNr = tn;
	tt[tn]->FM = &ttfinished[tn];
	ttfinished[tn] = false;
	tt[tn]->Resume();
	}
										// Warten bis alle Tasks fertig und terminiert
tn=0;
while ( tn<tanzakt )
	{
	while ( ttfinished[tn] == false )
		{
		Sleep(500);
		Application->ProcessMessages();
		}
	tn++;
	}

/*
fertig = 0;
while ( fertig < tanzakt )
	{
	fertig = 0;
	for ( tn=0; tn<tanzakt; tn++ )
		{
		if ( tt[tn]->Finished ) fertig++;
		}
	Application->ProcessMessages();
	}
										//Ende Anzeige->Erstellen( &Params, Ergebnis );
*/
beendet = GetTickCount();
beendet -= anfang;
Params.Erstellungsdauer = beendet;

Bildgerechnet = true;
Timer1->Enabled = false;
Statusp2->Style = psText;
Statusp2->Text = "fertig";
BerechnenLaeuft = false;
StopTb->Visible = false;
StopTb->Marked = false;
rTb->Visible = true;
iTb->Visible = true;
DCWd->StatusAnzeige();
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::NeuZeichnen()
{
long double		*erg, ergld;
int				i,o,f,fh,x,y,h,w,*scl,*hscl;

if ( !Bildgerechnet ) return;

GetBlende();
DCWd->GetZeichnenParameter( );
ColorBarWd->SetScala( );
ColorBarWd->PaintCb();
erg = Ergebnis;
h = ImageBitmap->Height;
w = ImageBitmap->Width;
for ( y=0; y<h; y++ )
	{
	scl = (int *)ImageBitmap->ScanLine[y];
/*
	if ( Params.ZusatzMode & 0x0020 ) 				// hinterlegte MBM aktiv ?
		{
		hscl = (int *)HmbmBitmap->ScanLine[y];
		for ( x=0; x<w; x++ )
			{
			i = ColorBarWd->GetColor( *erg++ );
			f = i & 0x0ff;
			fh = hscl[x] & 0x0ff;
			if ( fh > f )
				o = fh;
			else
				o = f;
			f = i & 0x0ff00;
			fh = hscl[x] & 0x0ff00;
			if ( fh > f )
				o |= fh;
			else
				o |= f;
			f = i & 0x0ff0000;
			fh = hscl[x] & 0x0ff0000;
			if ( fh > f )
				o |= fh;
			else
				o |= f;

			scl[x] = o;
			}
		}
	else												// ohne Hinterlegte MBM zeichnen
*/
		for ( x=0; x<w; x++ )
			scl[x] = ColorBarWd->GetColor( *erg++ );
	}
RefreshAnzeige(0);
}
//------------------------------------------------------------------------------

void TBildWd::RefreshAnzeige( Zusaetzlich )
{
int		i,f;

if ( !GoIsDone ) return;
BildIm->Picture->Assign(ImageBitmap);					// anzeige ohne Zusatz
f = Params.ZusatzMode;
f |= Zusaetzlich;
for ( i=0; i<18; i++ )									// Alle gew�nschten Zusatzanzeigen abfragen und ausf�hren
	{
	if ( (f & 0x00001) == 1 )
		ZusatzAnzeigeTab[i]();
	f >>= 1;
	}
}
//------------------------------------------------------------------------------

void TBildWd::ShowKoordinaten()			//--------------------------------------
										{ PaintKoordinaten();}
void TBildWd::ShowAnsicht(){}           //--------------------------------------
void TBildWd::ShowSternenhimmel(){}     //--------------------------------------
void TBildWd::ShowJuliapunkt()          //--------------------------------------
										{
										ZeichneKoordinaten( &Params.jpx, &Params.jpy, clPurple );
										DCWd->EDPj->Visible = true;
										}
void TBildWd::ShowTestpunkt()	        //--------------------------------------
										{ ZeichneKoordinaten( &Params.tpx, &Params.tpy, clYellow100 );}
void TBildWd::ShowHinterlegteMBM(){}    //--------------------------------------
void TBildWd::ShowZoomrahmen()	        //--------------------------------------
										{
										TCanvas		*cvs;
										TRect		zr;
										long double v = 1.0;
										bigint		d,zs,vbi;

										cvs = BildIm->Canvas;
										cvs->Brush->Style = bsClear;
										cvs->Pen->Style = psSolid;
										cvs->Pen->Color = clBlau100;
										if ( !Params.isCycleZoom )
											{
											v = Params.BildSizeY;
											v /= Params.BildSizeX;
											}
										vbi = v;
										zs = (Params.ZoomSize / 2.0);
										d = Params.zcx;
										d -= zs;
										zr.left = BildKoo.X( d );
										d += zs;
										d += zs;
										zr.right = BildKoo.X( d );
										zs *= vbi;
										d = Params.zcy;
										d -= zs;
										zr.bottom = BildKoo.Y( d );
										d += zs;
										d += zs;
										zr.top = BildKoo.Y( d );
										if ( Params.isCycleZoom )
											cvs->Ellipse( zr );
										else
											cvs->Rectangle( zr );
										}
void TBildWd::ShowIterNrOrt()	        //--------------------------------------
										{

										}
void TBildWd::ShowCenterOfOrbit(){}     //--------------------------------------
void TBildWd::ShowReferenzpunkt()       //--------------------------------------
										{ ZeichneKoordinaten( &Params.refpx, &Params.refpy, clSilver );}
void TBildWd::ShowImaginaerpunkt()	    //--------------------------------------
										{
										ZeichneKoordinaten( &Params.imagx, &Params.imagy, clOlive );
										DCWd->EDPi->Visible = true;
										}
void TBildWd::ShowFirstIter()           //--------------------------------------
										{

										}
void TBildWd::ShowMinZ(){}              //--------------------------------------
void TBildWd::ShowOrbitLinien(){}       //--------------------------------------
void TBildWd::ShowBildCenter()	        //--------------------------------------
										{
										int			x,y;
										TCanvas		*z;

										x = BildKoo.X(Params.cx);
										y = BildKoo.Y(Params.cy);

										z = BildIm->Canvas;
										z->Pen->Color = clSilver;
										z->MoveTo(x-5,y);
										z->LineTo(x+5,y);
										z->MoveTo(x,y-5);
										z->LineTo(x,y+5);
										}
void TBildWd::ShowLinie()	            //--------------------------------------
										{
										PaintLine( &Params.lsx, &Params.lsy, &Params.lex, &Params.ley );
										}
void TBildWd::ShowLinienStart()	        //--------------------------------------
										{
										ZeichneKoordinaten( &Params.lsx, &Params.lsy, clRed );
										DCWd->EDPl->Visible = true;
										}
void TBildWd::ShowLinienEnd()	    	//--------------------------------------
										{
										ZeichneKoordinaten( &Params.lex, &Params.ley, clRed );
										DCWd->EDPl->Visible = true;
										}
void TBildWd::ShowBezierVector()    	//--------------------------------------
										{
										//PaintLine( Params.BildSizeX / 2, Params.BildSizeY / 2, Params.Bezierpx, Params.Bezierpy );
										}
//------------------------------------------------------------------------------

bool TBildWd::ZeichneKoordinaten( bigint *xbi, bigint *ybi, TColor c )
{
if ( !BildKoo.IsInside( xbi, ybi) ) return false;

int			x,y,l;
long double	v;
TCanvas		*z;

x = BildKoo.X( *xbi );
y = BildKoo.Y( *ybi );

z = BildIm->Canvas;
z->Pen->Color = c;
z->Brush->Color = clBlack;
z->Pen->Style = psDot;
l = Params.BildSizeX / 10;
z->MoveTo(x-l,y);
z->LineTo(x+l,y);
z->MoveTo(x,y-l);
z->LineTo(x,y+l);

z->Pen->Color = 0x0000ff00;
z->Brush->Style = bsClear;
z->Font->Name = "Arial";
z->Font->Size = 10;                    			// Schriftgr��e in Pixel
z->Font->Pitch = fpFixed;
z->Brush->Style = bsClear;
v = Ergebnis[(( Params.BildSizeX * y ) + x )];
z->Font->Color = clWhite;
z->TextOut( x+10, y-20, FloatToStrF(v, ffExponent, 6, 6));
z->Font->Color = clBlack;
z->TextOut( x+10, y+3, FloatToStrF(v, ffExponent, 6, 6));

if ( zrdSL != NULL )   			// Daten f�r *.zsa File
	{
	double 	xd,yd;

	xd = BildKoo.X( *xbi );
	yd = BildKoo.Y( *ybi );
	zrdSL->Add("K  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  " +  c + ";  ");
	}
return true;
}
//------------------------------------------------------------------------------

bool TBildWd::ZeichneBildKoo( TBildKoo *bk, TColor c )
{
int		x,y;
TCanvas		*z;

z = BildIm->Canvas;
z->Pen->Color = c;
z->Brush->Color = clGray;
z->Pen->Style = psDot;

if ( BildKoo.IsInside( &bk->cxl, &bk->cyt ) | BildKoo.IsInside( &bk->cxl, &bk->cyb ) )
	{
	x = BildKoo.X(bk->cxl);
	z->MoveTo(x,0);
	z->LineTo(x,Params.BildSizeY);
	}
if ( BildKoo.IsInside( &bk->cxr, &bk->cyt ) | BildKoo.IsInside( &bk->cxr, &bk->cyb ) )
	{
	x = BildKoo.X(bk->cxr);
	z->MoveTo(x,0);
	z->LineTo(x,Params.BildSizeY);
	}
if ( BildKoo.IsInside( &bk->cxl, &bk->cyt ) | BildKoo.IsInside( &bk->cxr, &bk->cyt ) )
	{
	y = BildKoo.Y(bk->cyt);
	z->MoveTo(0,y);
	z->LineTo(Params.BildSizeX,y);
	}
if ( BildKoo.IsInside( &bk->cxl, &bk->cyb ) | BildKoo.IsInside( &bk->cxr, &bk->cyb ) )
	{
	y = BildKoo.Y(bk->cyb);
	z->MoveTo(0,y);
	z->LineTo(Params.BildSizeX,y);
	}
return true;
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::GetBlende()
{
long double		*erg, mini, maxi;
int				i,h;

if ( Params.BlendenMode > 0 ) return;
mini = +1.0e200;
maxi = -1.0e200;
erg = Ergebnis;
h  = ImageBitmap->Height;
h *= ImageBitmap->Width;
for ( i=0; i<h; i++ )
	{
	if ( IsNan( *erg ) == false ) {						// NaN steht f�r unendlich ( schwarz )
		if ( *erg < mini )
			mini = *erg;
		else if ( *erg > maxi )
			maxi = *erg;
		}
	erg++;
	}
Params.Zlevel = mini;
Params.Zscala = maxi;
DCWd->BlendeMaxEd->Text = FloatToStr( maxi );
DCWd->BlendeMinEd->Text = FloatToStr( mini );
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::StatusBarDrawPanel(TStatusBar *StatusBar, TStatusPanel *Panel, const TRect &Rect)
{
TRect	pb;
float	lf;
int		p;

pb = Rect;
TCanvas *canvas = StatusBar->Canvas;
canvas->Brush->Color = clBtnFace;
canvas->FillRect(Rect);
p = Anzeige->PbPos;
if ( Anzeige == NULL ) p = 1;
if ( Anzeige->PbPos == 0 ) p = 1;
lf = pb.right - pb.left;
lf /= Anzeige->PbMax;
lf *= p;
pb.right = pb.left + lf;
canvas->Brush->Color = clRed;
canvas->FillRect(pb);
//  canvas->Font->Color = clYellow;
//  ImageList1->Draw(canvas,Rect.Left,Rect.Top, Panel->Index, true);
//  canvas->TextOut(Rect.left + 30, Rect.top + 2, "Panel");

}
//------------------------------------------------------------------------------

void __fastcall TBildWd::Timer1Timer(TObject *Sender)
{

StatusBar->Repaint();
}
//------------------------------------------------------------------------------

void __fastcall TBildWd::BildSizeLbClick(TObject *Sender)
{

if ( BildSizeLb->ItemIndex == 16 )
	{
	BildxEd->Visible = true;
	BildyEd->Visible = true;
	}
else
	{
	BildxEd->Visible = false;
	BildyEd->Visible = false;
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::SpeichernAs(TObject *Sender)
{
int				iFileHandle,sel,ok,pos,h,w,x,y;
long double		*erg;
String			fn,txt;

Params.Speed = DCWd->SpeedEd->Value;
Params.Beschleunigung = DCWd->BeschleunigungEd->Value;

ok = false;
SaveDlg->Title = "DeepChaosV2 - " + Statusp0->Text;
SaveDlg->InitialDir = DCWd->BilderPfEd->Text;
if ( SaveDlg->Execute() )
	{
	ok = 0;
	pos = SaveDlg->FileName.Pos( "." );
	fn = SaveDlg->FileName.Delete( pos, 4 );
	if ( SaveDlg->FileName.Pos( ".bmp" ) > 2 ) sel = 0x01;
	if ( SaveDlg->FileName.Pos( ".jpg" ) > 2 ) sel = 0x02;
	if ( SaveDlg->FileName.Pos( ".prm" ) > 2 ) sel = 0x04;
	if ( SaveDlg->FileName.Pos( ".dcp" ) > 2 ) sel = 0x08;
	if ( SaveDlg->FileName.Pos( ".txt" ) > 2 ) sel = 0x10;
	if ( SaveDlg->FileName.Pos( ".oad" ) > 2 ) sel = 0x20;          	// nur f�r Orbit Window
	if ( SaveDlg->FileName.Pos( ".zsa" ) > 2 ) sel = 0x40;
	if ( SaveDlg->FileName.Pos( ".pyt" ) > 2 ) sel = 0x80;
	if ( SaveDlg->FileName.Pos( ".all" ) > 2 )
		{
		sel = 0x05f;
		if (!DirectoryExists(fn))
			{
			if (!CreateDir(fn))
				throw Exception("Verzeichnis " + fn + "kann nicht erstellt werden");
			}
		fn += fn.SubString( fn.LastDelimiter("\\"),99 );
		}
	if ( sel & 1 )													//-----------------  bmp
		{
		BildIm->Picture->Bitmap->SaveToFile( fn + ".bmp" );
		ok |= 0x01;
		}
	if ( sel & 2 )                       							//-------------   jpg
		{
		TJPEGImage *jp = new TJPEGImage();
		try
			{
			jp->Assign(BildIm->Picture->Bitmap);
			jp->SaveToFile(fn + ".jpg");
			//StrLCopy( Params.BMFile, SaveDlg->FileName.t_str(), 79 );
			ok |= 0x02;
			}
		__finally
			{
			delete jp;
			}
		}
	if ( sel & 4 )                     									 //-------------  prm
		{
		try
			{
			iFileHandle = FileCreate(fn + ".prm");
			FileWrite(iFileHandle, "DeepChaosV2Parameter.Vers1          ", 32);
			FileWrite(iFileHandle, &Params, sizeof(Params));
			FileClose(iFileHandle);
			ok |= 0x04;
			}
		__finally
			{
			}
		}
	if ( sel & 8 )                        							   //------------------- dcp
		{
		iFileHandle = FileCreate( fn + ".dcp" );
		FileWrite(iFileHandle, "DeepChaosV2Parameter.Vers1", 32);
		FileWrite(iFileHandle, &Params, sizeof(Params));
		FileWrite(iFileHandle, Ergebnis, (sizeof(long double) * ImageBitmap->Height * ImageBitmap->Width) );
		FileClose(iFileHandle);
		ok |= 0x08;
		}
	if ( sel & 0x10 )                      							   //--------------------   txt
		{
		if ( TextDateiWrite( fn + ".txt" ))
			ok |= 0x10;
		}
	if ( sel & 0x20 )                      							   //--------------------   oad
		{
		if ( DCWd->AktivesFenster = DCWd->OrbitWd )
			{
			DCWd->OrbitWd->SpeichernOad( fn + ".oad" );
			ok |= 0x20;
			}
		}
	if ( sel & 0x40 )                      							   //--------------------   zsa
		{
		SpeichernZsa( fn );
		ok |= 0x40;
		}
	if ( sel & 0x80 )                      							   //--------------------   pyt
		{
		zrdSL = new TStringList();
		erg = Ergebnis;
		h = ImageBitmap->Height;
		w = ImageBitmap->Width;
		txt = FormatFloat("000000.0",h);
		txt[7] = '.';
		zrdSL->Add(txt);
		txt = FormatFloat("000000.0",w);
		txt[7] = '.';
		zrdSL->Add(txt);
		txt = DCWd->MinErgAnzEd->Text;
		x = txt.Pos(",");
		if ( x>0 ) txt[x] = '.';
		zrdSL->Add(txt);
		txt = DCWd->MaxErgAnzEd->Text;
		x = txt.Pos(",");
		if ( x>0 ) txt[x] = '.';
		zrdSL->Add(txt);
		for ( y=h-1; y>=0; y-- )
			{
			for ( x=0; x<w; x++ )
				{
				txt = FormatFloat("000000.000000",*erg++);
				txt[7] = '.';
				zrdSL->Add(txt);
				}
			}
		zrdSL->SaveToFile(fn + ".pyt");
		delete zrdSL;
		ok |= 0x80;
		}
	if ( ok == sel )
		{
		Statusp2->Text = SaveDlg->FileName + " gespeichert";
		WorkingFile = SaveDlg->FileName;
		}
	else Statusp2->Text = "Fehler !";
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::SpeichernZsa( String Filebez )
{
zrdSL = new TStringList();
double	xd,yd;

zrdSL->Add("   BildDaten");
zrdSL->Add("F  "+Filebez + ".???;");
zrdSL->Add("B  "+FormatFloat("000000.000",BildIm->Width)+";  "+FormatFloat("000000.000",BildIm->Height)+";  " + clGray + ";  ");
RefreshAnzeige(0);
zrdSL->SaveToFile(Filebez + ".zsa");
delete zrdSL;
zrdSL = NULL;
		TJPEGImage *jp = new TJPEGImage();   			// Bild ohne Zusatzanzeige speichern
		try
			{
			jp->Assign(ImageBitmap);
			jp->SaveToFile(Filebez + "OZA.jpg");
			}
		__finally
			{
			delete jp;
			}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::DateiOeffnen(TObject *Sender)
{
int			iFileHandle;
bool		ok;
char	 	vers[33];

ok = false;
Bildgerechnet = false;
OpenDlg->Title = "DeepChaosV2 - " + Statusp0->Text;
OpenDlg->InitialDir = DCWd->BilderPfEd->Text;
if ( OpenDlg->Execute() )
	{
	if ( OpenDlg->FileName.Pos( ".bmp" ) > 2 )              	//-----------------
		{
		ImageBitmap->LoadFromFile( OpenDlg->FileName );
		BildIm->Picture->Assign(ImageBitmap);
		ok = true;
		}
	if ( OpenDlg->FileName.Pos( ".jpg" ) > 2 )                  //------------------
		{
		TJPEGImage *jp = new TJPEGImage();
		try
			{
			jp->LoadFromFile(OpenDlg->FileName);
			BildIm->Picture->Bitmap->Assign(jp);
			}
		__finally
			{
			delete jp;
			}
		ok = true;
		}
	if ( OpenDlg->FileName.Pos( ".dcp" ) > 2 )                   //------------------
		{
		TMainParams pt;

		iFileHandle = FileOpen( OpenDlg->FileName, fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &pt, sizeof(Params)); 		// erst tempor�r laden f�r Kontrolle
			if (( pt.BildSizeX == ImageBitmap->Width ) && ( pt.BildSizeY == ImageBitmap->Height ))
				{
				Params = pt;
				DCWd->DisplMbmEdit();
				FileRead(iFileHandle, Ergebnis, (sizeof(long double) * ImageBitmap->Height * ImageBitmap->Width) );
				BildKoo.Set(&Params);
				ColorBarWd->ParamPaint( &Params );
				Bildgerechnet = true;
				NeuZeichnen();
				ok = true;
				}
			else
				{
				if ( IDOK == Application->MessageBox(L"Falsche Bilddimension, \nNur Parametersatz verwenden, dann neu Rechnen?", L"Bilddaten �ffnen", MB_OKCANCEL  ))
					{
					pt.BildSizeX = ImageBitmap->Width;
					pt.BildSizeY = ImageBitmap->Height;
					Params = pt;
					BildKoo.Set(&Params);
					ColorBarWd->ParamPaint( &Params );
					DCWd->DisplMbmEdit();
					ok = true;
					}
				}
			}
		else
			Application->MessageBox(L"Falsche Version", MB_OK  );
		FileClose(iFileHandle);
		}
	if ( OpenDlg->FileName.Pos( ".prm" ) > 2 )                      //-------------
		{
		TMainParams pt;

		iFileHandle = FileOpen( OpenDlg->FileName, fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1      ",vers) == 0 )
//					 12345678901234567890123456789012
			{
			FileRead(iFileHandle, &pt, sizeof(Params)); 		// erst tempor�r laden f�r �nderung
			pt.BildSizeX = ImageBitmap->Width;
			pt.BildSizeY = ImageBitmap->Height;
			Params = pt;
			DCWd->DisplMbmEdit();
			ok = true;
			}
		else
			Application->MessageBox(L"Falsche Version", MB_OK  );
		}

	if ( ok )
		{
		Statusp2->Text = OpenDlg->FileName;
		WorkingFile = OpenDlg->FileName;
		//StrLCopy( Params.BMFile, OpenDlg->FileName.t_str(), 79 );
		}
	}
}
//---------------------------------------------------------------------------

bool __fastcall TBildWd::TextDateiWrite( UnicodeString fn )
{
TStringList *sl = new TStringList();
int		  	op;

op = Params.ZusatzMode;
sl->Add("DeepChaosV2");
sl->Add("Menge:");
sl->Add(DCWd->MmodeEd->Text);
sl->Add("Anzeige:");
sl->Add(DCWd->AmodeCb->Text);
sl->Add("Auswertung:");
sl->Add(DCWd->EmodeCb->Text);
sl->Add("Rechenart:");
sl->Add(DCWd->ErstArtCB->Text + "(" + IntToStr(DCWd->RmodeCB->Value) +")");
sl->Add("Vorlauf(Iter):");
sl->Add(DCWd->VorlaufIterEd->Text);
sl->Add("Maximal(Iter):");
sl->Add(DCWd->MaxIterEd->Text);
sl->Add("Maximal(Z):");
sl->Add(DCWd->MaxRadiusEd->Text);
if ( DCWd->ReferenzMengeCb->Visible )
	{
	sl->Add("Referenzmenge:");
	sl->Add(DCWd->ReferenzMengeCb->Text);
	}
if ( DCWd->BubblebrotBerCB->Visible )
	{
	sl->Add("Bereich:");
	sl->Add(DCWd->BubblebrotBerCB->Text);
	}
if ( DCWd->BubblebrotPraezEd->Visible )
	{
	sl->Add("Aufl�sung:");
	sl->Add(IntToStr(DCWd->BubblebrotPraezEd->Value));
	}
if ( DCWd->ZAuswertungCB->Visible )
	{
	sl->Add("Z-Auswertung:");
	sl->Add(DCWd->ZAuswertungCB->Text);
	}
if ( DCWd->OptionenCb->Visible )
	{
	sl->Add("Option:");
	sl->Add(DCWd->OptionenCb->Text);
	}
if ( DCWd->ErstellungsmodeZusatzEd->Visible )
	{
	sl->Add("Grenzwert:");
	sl->Add(DCWd->ErstellungsmodeZusatzEd->Text);
	}
if ( DCWd->ToleranzEd->Visible )
	{
	sl->Add("Toleranz ( B u. W):");
	sl->Add(DCWd->ToleranzEd->Text + " Breite / " + DCWd->ToleranzWinkelEd->Text + " Winkel");
	}
if ( DCWd->ErstellungsmodeNummerEd->Visible )
	{
	sl->Add(DCWd->NrLabel->Caption);
	sl->Add(IntToStr(DCWd->ErstellungsmodeNummerEd->Value));
	}
sl->Add("BildCenter(real):");
sl->Add(DCWd->RealXEd->Text.TrimLeft());
sl->Add("BildCenter(imag):");
sl->Add(DCWd->ImagYEd->Text.TrimLeft());
sl->Add("BildSize(x):");
sl->Add(DCWd->BildSizeEd->Text);
if ( DCWd->EDPj->Visible )
	{
	sl->Add("Julia-Punkt(real):");
	sl->Add(DCWd->JpXEd->Text.TrimLeft() );
	sl->Add("Julia-Punkt(imag):");
	sl->Add(DCWd->JpYEd->Text.TrimLeft() );
	}
if ( DCWd->EDPi->Visible )
	{
	sl->Add("Imag-Punkt(real):");
	sl->Add(DCWd->ImagpXEd->Text.TrimLeft() );
	sl->Add("Imag-Punkt(imag):");
	sl->Add(DCWd->ImagpYEd->Text.TrimLeft() );
	}
if ( DCWd->EDPl->Visible )
	{
	sl->Add("LinienStartP.(real):");
	sl->Add(DCWd->StartXEd->Text.TrimLeft() );
	sl->Add("LinienStartP.(imag):");
	sl->Add(DCWd->StartYEd->Text.TrimLeft() );
	sl->Add("LinienEndP.(real):");
	sl->Add(DCWd->EndXEd->Text.TrimLeft() );
	sl->Add("LinienEndP.(imag):");
	sl->Add(DCWd->EndYEd->Text.TrimLeft() );
	}
if ( DCWd->EDPr->Visible )
	{
	sl->Add("Ref.BildCenter(real):");
	sl->Add(DCWd->RefBildXEd->Text.TrimLeft() );
	sl->Add("Ref.BildCenter(imag):");
	sl->Add(DCWd->RefBildYEd->Text.TrimLeft() );
	sl->Add("Ref.BildSize(x):");
	sl->Add(DCWd->RefBildSizeEd->Text.TrimLeft() );
	sl->Add("BildFile");
	sl->Add(DCWd->ReferenzDateiED->Text.TrimLeft() );
	}
if ( op & opTestpunkt )
	{
	sl->Add("TestPunkt(real):");
	sl->Add(DCWd->TpXEd->Text.TrimLeft() );
	sl->Add("TestPunkt(imag):");
	sl->Add(DCWd->TpYEd->Text.TrimLeft() );
	}
if (( op & opTestpunkt ) && ( op & opReferenzpunkt ))
	{
	sl->Add("Distanz Tp.-Rp.(Z):");
	sl->Add(DCWd->DistFpEd->Text );
	sl->Add("Argument:");
	sl->Add(DCWd->ArgumentRpTpEd->Text );
	}
if ( op & opReferenzpunkt )
	{
	sl->Add("ReferenzPunkt(real):");
	sl->Add(DCWd->RefPxEd->Text.TrimLeft() );
	sl->Add("ReferenzPunkt(imag):");
	sl->Add(DCWd->RefPyEd->Text.TrimLeft() );
	}
sl->Add("Gesamtgr��e:");
sl->Add(DCWd->AmSizeEd->Text);
sl->Add("Rechendauer:");
sl->Add(DCWd->ErstellDauerEd->Text);
sl->Add("Ergebnisbereich:");
sl->Add("von: " + DCWd->MinErgAnzEd->Text + "  bis: " + DCWd->MaxErgAnzEd->Text );

sl->SaveToFile(fn);
delete sl;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::BildImMouseEnter(TObject *Sender)
{

ActiveControl = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::KommandoTbClick(TObject *Sender)
{
TToolButton	*mi = (TToolButton *)(Sender);
String		s;

s = mi->Hint;
KommandoSend( s );
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::KommandoSend( String s )
{
WORD		c;
int			i,l;

c = L'@';
FormKeyNow( c );
l = s.Length();
i = 1;
while ( i <= l )
	{
	c = s[i];
	if ( c == L'|' ) break;
	FormKeyNow( c );
	i++;
	}
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::StopTbClick(TObject *Sender)
{

Anzeige->StopSignal = true;
StopTb->Marked = true;
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::rTbClick(TObject *Sender)
{
KommandoSend( "r" );
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::zTbClick(TObject *Sender)
{
KommandoSend( "n" );
}
//---------------------------------------------------------------------------

void __fastcall TBildWd::iTbClick(TObject *Sender)
{
KommandoSend( "i" );
}
//---------------------------------------------------------------------------

