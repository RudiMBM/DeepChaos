//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "OrbitAnalyse.h"
//#include "PhasenAnalyse.h"
#include "HelpForm.h"
//#include "DatenBankForm.h"
#include "ZeitReihe.h"
#include "BildForm.h"
#include "DCMAIN.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THelpWd *HelpWd;

//---------------------------------------------------------------------------
__fastcall THelpWd::THelpWd(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------

void __fastcall THelpWd::FormCreate(TObject *Sender)
{
TStringList		*l;
String		 	s;
int				i;

Sf = "HelpView";
Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", Constraints->MinWidth );
Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", Constraints->MinHeight );

s = ChangeFileExt(Application->ExeName, ".txt");
if ( ! FileExists(s))
	return;
CommandChars = new TStringList;
l = new TStringList;
l->LoadFromFile(s);
for ( i=0; i<l->Count; i++ )
	{
	s = l->Strings[i];
	HelpText->Items->Add(s.SubString(4,s.Length()-3));
	CommandChars->Add(s.SubString(1,3));
	}
delete l;
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::FormCloseQuery(TObject *Sender, bool &CanClose)
{

CanClose = true;

}
//---------------------------------------------------------------------------

void __fastcall THelpWd::FormDestroy(TObject *Sender)
{

delete CommandChars;
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::FormClose(TObject *Sender, TCloseAction &Action)
{

DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
DCWd->SettingsFile->WriteInteger(Sf, "Width", Width );
DCWd->SettingsFile->WriteInteger(Sf, "Heigth", Height );
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::HelpTextMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,int X, int Y)
{

cnr = HelpText->ItemAtPos(Point(X,Y),true);
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::Commando( int c )
{
int		i;
Char	ccc[5];

StatusBar->Panels->Items[1]->Text = CommandChars->Strings[c];
wcscpy(ccc, StringToOleStr( CommandChars->Strings[c]));
if ( DCWd->AktivesBild == NULL ) return;
for ( i=0; i<3; i++)
	{
	DCWd->AktivesBild->FormKeyNow( (unsigned short &)(ccc[i]) );
	}
DCWd->AktivesBild->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::HelpTextKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)

{
int		c;

if ( Key == VK_RETURN )
	{
	c = HelpText->ItemIndex;
	if ( c>=0 )
		Commando( c );
	}
}
//---------------------------------------------------------------------------

void __fastcall THelpWd::HelpTextDblClick(TObject *Sender)
{

Commando( cnr );
}
//---------------------------------------------------------------------------

