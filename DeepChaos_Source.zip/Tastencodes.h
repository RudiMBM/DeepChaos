#ifndef TastencodesH
#define TastencodesH
//---------------------------------------------------------------------------------
#define comLog0			L'0' //VK_NUMPAD0
#define comLog1			L'1' //VK_NUMPAD1
#define comLog2			L'2' //VK_NUMPAD2
#define comLog3			L'3' //VK_NUMPAD3

#define comShift		VK_SHIFT
#define comTab			VK_TAB
#define comEsc			VK_ESCAPE		// alles beenden
//---------------------------------------------------------------------------------
#define comZReihe		L'a'			// show sequenzielle Analyse ( Zeitreihe )
#define comBearbeiten	L'b'
#define comColor		L'c'			// show Colorbar
#define menDatei		L'd'
#define 				comSaveAs		L'a'
#define 				comOeffnen		L'�'
#define 				comSave			L's'
#define 				comDbNeu		L'n'
#define 				comDbUpdate		L'u'
#define comErase		L'e'						  	// Fartab l�schen
#define 				fktjpg			L'j'			// *.jpg File
#define comFarbtab		L'f'
#define comFertigRechnen L'f'
#define menBildGet		L'g'
#define comHelp			L'h'		  	// Help
// 			L'I'
//			L'J'
//							K
#define comLog			L'l'            // loganzeige-Punkt
#define comMain			L'm'			// show Main - Form
#define comNeuZeichnen	L'n'
#define comOption		L'o'
#define					comAnzeige		L'a'
#define									comKoordinaten	L'k'
#define menParam		L'p'
#define													srcAllView		L'v'	// volle Gr��e
#define													srcLastView		L'l'
#define													srcBild1		L'1'
#define													srcBild2		L'2'
#define													srcBild3		L'3'
#define													srcBild4		L'4'
#define													srcDB	   		L'd'	// from aktuellen Datenbanksatz
#define													srcOrbit		L'o'
#define comLoad			L'�'			// Colorbar File �ffnen
#define menPunkt		L'.'
#define					comEndLine		L'e'
#define 				comImagpoint 	L'i'
#define 				comJuliapoint	L'j'
#define					comStartLine	L's'
#define 				comTestpoint	L't'
#define 				comRefpoint		L'r'
#define 				comLinie		L'l'
#define					isMouseMove		0x1234
#define									comGetFrom		L'g'					// obige Punkte Get from Bild...
#define													srcOrbit		L'o'	// OrbitWd
//#define													srcBild0		L'0'	// OrbitWd
#define													srcBild1		L'1'
#define													srcBild2		L'2'
#define													srcBild3		L'3'
#define													srcBild4		L'4'
#define													srcDB	   		L'd'	// from aktuellen Datenbanksatz
#define									fktSetNull		L'n'            		// obiger Punkt = 0
#define									fktSetAbs		L'a'                    //????
#define									fktSeekMaxErg	L's'
#define									fktCenterLoad	L'c'
#define	comQuit			L'q'
#define comNeuRechnen	L'r'			// beRechnen selbe bildgr��e
#define comStop			L's'
//#define comSizeNew		L's'
//			L'T'
#define comUmherschieben L'u'
#define comNeuZoomIn	L'i'			// Berechnen Zoom
#define comWhereIs		L'w'			// wo ist Bild 1,2,3,oder 4, d = Datenbank dann: T=Testp J=Julia
/*
#define					comEndLine		L'e'
#define 				comImagpoint 	L'i'
#define 				comJuliapoint	L'j'
#define					comLinie		L'l'
#define 				comTestpoint	L't'
#define 				comZoom			L'z'
*/
#define 								comBild			L'b'
#define													srcBild1		L'1'
#define													srcBild2		L'2'
#define													srcBild3		L'3'
#define													srcBild4		L'4'
#define													srcDB	   		L'd'	// from aktuellen Datenbanksatz
#define comOrbit		L'x'
#define comphanlYse		L'y'			// Phasenanlayse Fenster
#define comZoom			L'z'
#define 				comFullSize		L'v'
#define 				SetFromPunkt	L'.'
/*
#define									comEndLine		L'e'
#define 								comImagpoint 	L'i'
#define 								comJuliapoint	L'j'
#define									comStartLine	L's'
#define 								comTestpoint	L't'
#define 								comRefpoint		L'r'
*/
#define comCycleZoom	L'Z'
#define					comAbsBz		L'a'			// absolute Breite des Zooms eingeben ( Sub-Fenster )
#define 				comBildShift	L'b'
/*
#define					comEndLine		L'e'			// Zoomcenter von diesen Punkten setzten
#define 				comImagpoint 	L'i'
#define 				comJuliapoint	L'j'
#define 				comTestpoint	L't'
#define													srcBild1		L'0'	// eigene Punkte
#define													srcBild1		L'1'
#define													srcBild2		L'2'
#define													srcBild3		L'3'
#define													srcBild4		L'4'
#define													srcDB	   		L'd'	// from aktuellen Datenbanksatz
*/



#define comBild1		L'1'			// show anderes Bild
#define comBild2		L'2'
#define comBild3		L'3'
#define comBild4		L'4'
#define comDB			L'd'

//---------------------------------------------------------------------------------


#define VK_UP_Ctrl			0x07000 + VK_UP
#define VK_DOWN_Ctrl        0x07000 + VK_DOWN
#define VK_LEFT_Ctrl        0x07000 + VK_LEFT
#define VK_RIGHT_Ctrl       0x07000 + VK_RIGHT

#define NeuesKommando		L'@'
#define comTodo				L'�'
#define workNow				L'#'

//---------------------------------------------------------------------------------
#endif

/*
VK_LBUTTON	Linke Maustaste
VK_RBUTTON	Rechte Maustaste
VK_CANCEL	Strg+Untbr
VK_MBUTTON	Mittlere Maustaste
VK_BACK		Taste R�ck
VK_TAB		Taste Tab
VK_CLEAR	Taste L�schen
VK_RETURN	Taste Enter
VK_SHIFT	Taste Umschalt
VK_CONTROL	Taste Strg
VK_MENU		Taste Alt
VK_PAUSE	Taste Pause
VK_CAPITAL	Feststelltaste
VK_KANA		Mit IME verwendet
VK_HANGUL	Mit IME verwendet
VK_JUNJA	Mit IME verwendet
VK_FINAL	Mit IME verwendet
VK_HANJA	Mit IME verwendet
VK_KANJI	Mit IME verwendet

VK_CONVERT		Mit IME verwendet
VK_NONCONVERT	Mit IME verwendet
VK_ACCEPT		Mit IME verwendet
VK_MODECHANGE	Mit IME verwendet
VK_ESCAPE		Taste Esc
VK_SPACE		Taste Leer
VK_PRIOR		Taste Bild auf
VK_NEXT			Taste Bild ab
VK_END			Taste Ende
VK_HOME			Taste Pos1
VK_LEFT			Taste Links
VK_UP			Taste Auf
VK_RIGHT		Taste Rechts
VK_DOWN			Taste Ab
VK_SELECT		Taste Select
VK_PRINT		Taste Druck (tastaturspezifisch)
VK_EXECUTE		Taste Ausf�hren
VK_SNAPSHOT		Taste Print Screen

VK_INSERT		Taste Einfg
VK_DELETE		Taste Entf
VK_HELP			Hilfe-Taste
VK_LWIN			Linke Windows-Taste (Microsoft-Tastatur)
VK_RWIN			Rechte Windows-Taste (Microsoft-Tastatur)
VK_APPS			Anwendungstaste (Microsoft-Tastatur)
VK_NUMPAD0		Taste 0 (numerischer Tastaturblock)
VK_NUMPAD1		Taste 1 (numerischer Tastaturblock)
VK_NUMPAD2		Taste 2 (numerischer Tastaturblock)
VK_NUMPAD3		Taste 3 (numerischer Tastaturblock)
VK_NUMPAD4		Taste 4 (numerischer Tastaturblock)
VK_NUMPAD5		Taste 5 (numerischer Tastaturblock)
VK_NUMPAD6		Taste 6 (numerischer Tastaturblock)
VK_NUMPAD7		Taste 7 (numerischer Tastaturblock)
VK_NUMPAD8		Taste 8 (numerischer Tastaturblock)
VK_NUMPAD9		Taste 9 (numerischer Tastaturblock)
VK_MULTIPLY		Taste * (numerischer Tastaturblock)
VK_ADD			Taste +  (numerischer Tastaturblock)
VK_SEPARATOR	Taste . (numerischer Tastaturblock)
VK_SUBTRACT		Taste  (numerischer Tastaturblock)
VK_DECIMAL		Taste , (numerischer Tastaturblock)
VK_DIVIDE		Taste ./. (numerischer Tastaturblock)

VK_F1	Taste F1
VK_F2	Taste F2
VK_F3	Taste F3
VK_F4	Taste F4
VK_F5	Taste F5
VK_F6	Taste F6
VK_F7	Taste F7
VK_F8	Taste F8
VK_F9	Taste F9
VK_F10	Taste F10
VK_F11	Taste F11
VK_F12	Taste F12
VK_F13	Taste F13
VK_F14	Taste F14
VK_F15	Taste F15
VK_F16	Taste F16
VK_F17	Taste F17
VK_F18	Taste F18
VK_F19	Taste F19
VK_F20	Taste F20
VK_F21	Taste F21
VK_F22	Taste F22
VK_F23	Taste F23
VK_F24	Taste F24
VK_NUMLOCK	Taste Num
VK_SCROLL	Taste Rollen

VK_LSHIFT	Linke Umschalt-Taste (nur mit GetAsyncKeyState und GetKeyState verwendet)
VK_RSHIFT	Rechte Umschalt-Taste (nur mit GetAsyncKeyState und GetKeyState verwendet)
VK_LCONTROL	Linke Strg-Taste (nur mit GetAsyncKeyState und GetKeyState verwendet)
VK_RCONTROL	Rechte Strg-Taste  (nur mit GetAsyncKeyState und GetKeyState verwendet)
VK_LMENU	Linke Alt-Taste (nur mit GetAsyncKeyState und GetKeyState verwendet)

VK_RMENU	Rechte Alt-Taste (nur mit GetAsyncKeyState und GetKeyState verwendet)
VK_PROCESSKEY	Taste Process
VK_ATTN	Taste Attn
VK_CRSEL	Taste CrSel
VK_EXSEL	Taste ExSel
VK_EREOF	Taste Erase EOF
VK_PLAY	Taste Play
VK_ZOOM	Taste Zoom
VK_NONAME	Reserviert f�r zuk�nftigen Gebrauch
VK_PA1	Taste PA1
VK_OEM_CLEAR	Taste Clear
*/