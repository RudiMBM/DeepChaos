//---------------------------------------------------------------------------
#ifndef ParamsH
#define ParamsH

//---------------------------------------------------------------------------
class TMainParams
{
public:
							int				MaxIter;					// Anzahl - Erstellungsgrenzen
							int				VorlaufIter;            	// Vorlauf
							int				ZusatzMode;             	// "Anzeige mit:" On-Off Flags
							int 			Erstellungsdauer;       	// in Sekunden
							int				ItercountMax,ItercountMin; 	// Tats�chlich erreichte Iterationen
							int				RepeatJede;                 // Nur jede xte Iteration Zeigen
							int				Optionen;                   // Variationen spezieller Messungen
							int				frei32b;
							int				frei32c;
							int				frei32d;
							__int16        	FertigBisX;				// Unfertig gerechnet, nur bis Koord.X  ( Y)
							__int16         FertigBisY;
							__int16			BildSizeX;				// Bildbreite in Pixel
							__int16			BildSizeY;				// Bildh�he in Pixel
							__int16			Amode;		  			// Anzeigemode
							__int16			Mmode;  				// Menge-Art
							__int16			Emode;					// Erstellungsmode
							__int16			EmodeNr;				// ErstellungsNummer f�r Auswertungart
							__int16			ErstArt;				// Erstellungsrechenart
							__int16			Rmode;					// Rechengenauigkeit in Anz Bit ( 32 Bit Steps )
							__int16			BmodeR;					// bei Ergebnisort: Referenz-Fl�che
							__int16			RelativM;				// bei Z-Absolut: 	Relativmode
							__int16			RefSizeX;               // bei Referenzmenge: Aufl�sungsfaktor  1 ... n in Pixel
							__int16			BmodeB;                 // bei Referenzmenge: Bereich ( Inside-Outside-Beide )
							__int16			BezierpX;				// Bezierpunkt f�r Film in Pixel relativ zum Mittelpunkt
							__int16			BezierpY;
							__int16			AFBilder;				// Anzahl Film Bilder
							__int16			freii16a;
							__int16			freii16b;
							__int16			freii16c;
							__int16			freii16d;
							__int16			freii16e;
							__int16			freii16f;
							__int8			BlendenMode;            // Mode f�r Zscala-Zlevel
							__int8			Speed;                  // f�r Film
							__int8			Beschleunigung;         // f�r Film
							__int8			freii08a;
							__int8			freii08b;
							__int8			freii08c;
							__int8			freii08d;
							__int8			MinKommaStellen;		// Nachkommastellen-Anzahl minmal anzeigen
							//---------------------------------------- Achtung: Tabelle "BigIntEd" in Main.cpp synchron mit folgenden halten!!!!!!
							bigint		 	cx,cy;			        // Bild Zentrum Koordinaten
							bigint		 	rx,ry;					// Referenz Zentrum f�r Ergebnisort
							bigint			jpx,jpy;                // Julia Punkt
							bigint			tpx,tpy;                // Test Punkt
							bigint		 	lsx,lsy;			    // Linienstartpunkt
							bigint		 	lex,ley;				// Linienendpunkt
							bigint			zcx,zcy;				// letztes Zoomcenter
							bigint			imagx,imagy;			// Imagin�rpunkt f�r grafic-Berechnung
							bigint			refpx,refpy;			// Referenzpunkt f�r Entfernungsmessung
							bigint			bezierx,beziery;        // Bezierpunkt f�r Film
							bigint			freibi3,freibi4;
							bigint			freibi5,freibi6;
							long double		BildSize;				// Bildbreite
							long double		ZoomSize;				// Zoombreite
							long double		RefSize;				// Referenzbildbreite
							long double 	MaxRadius;
							long double 	InnerMin,InnerMax,OuterMin,OuterMax;
							long double		freild1;
							long double		Zscala;					// Farbenparameter
							long double		Zlevel;
							long double		EmodeZusatz;			// Zusatzparameter f�r Auswertungart ( Grenzwert )
							long double		RefBildSV;              // ReferenzBild Seitenverh�ltnis ( x / y = RefBildSV )
							long double		Toleranz;				// Erlaubte Abweichung zB Cyclebrot
							long double		ViewAngle;				// Sichtwinkel 0 = von der Seite (Zeitreihe)...... 1 = Draufsicht (Orbit)
							long double		Wtoleranz;				// Erlaubte Winkel-Abweichung zB Cyclebrot
							long double		freild5;
							long double		freild6;
							long double		freild7;
							bool			isCycleZoom;			// true wenn zoom is Cycle
							bool			isRefCycle;				// true wenn Referenzmenge is Cycle
							bool			isOversamle;			// true wenn Durchschnittsmessung pro Pixel
							bool			freib2;
							bool			freib3;
							bool			freib4;
							bool			freib5;
							bool			freib6;
							TDColorBarData	ColorBarData;
							char			CTFile[80];             // Filename ColorTab
							char			BMFile[80];             // Filename Bitmap/Jpg/dcp
							char			RBFile[80];				// Filename Referenzbild


					TMainParams();
					~TMainParams();
		bigint*		ParGetBigIntAdr( int nr );

};
//---------------------------------------------------------------------------
#endif
