//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Tastencodes.h"
#include "Bigint.h"
#include "Global.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "ZeitReihe.h"
#include "PhasenAnalyse.h"
#include "OrbitAnalyse.h"
#include "BildForm.h"
#include "DCMAIN.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "BildForm"
#pragma link "LMDBaseEdit"
#pragma link "LMDControl"
#pragma link "LMDCustomBevelPanel"
#pragma link "LMDCustomControl"
#pragma link "LMDCustomEdit"
#pragma link "LMDCustomExtSpinEdit"
#pragma link "LMDCustomMaskEdit"
#pragma link "LMDCustomPanel"
#pragma link "LMDSpinEdit"
#pragma link "LMDCheckListBox"
#pragma link "LMDCustomCheckListBox"
#pragma link "LMDCustomImageListBox"
#pragma link "LMDCustomListBox"
#pragma link "LMDEdit"
#pragma link "BildForm"
#pragma resource "*.dfm"
//TOrbitWd *OrbitWd;
//---------------------------------------------------------------------------
__fastcall TOrbitWd::TOrbitWd(TComponent* Owner) : TBildWd(Owner)
{

Keytodo = false;
SpeichernOadFile = false;
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::FormClose(TObject *Sender, TCloseAction &Action)
{

delete PreImageBitmap;
TBildWd::FormClose( Sender,  Action);
DCWd->OrbitWd = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::GoBtnNow()
{
TBildWd::GoBtnNow();
ClientWidth += OaPr->Width;
OaPr->Visible = true;

Params.Amode = A_MbmAnzOa;
Params.Emode = D_Apfelmaennchen;
Params.MaxIter = 800;
Anzeige->SetFullSize( &Params );
BildKoo.Set(&Params);
DCWd->DisplMbmEdit();

PreImageBitmap = new Graphics::TBitmap();
PreImageBitmap->PixelFormat = pf32bit;
PreImageBitmap->Height = ImageBitmap->Height;
PreImageBitmap->Width = ImageBitmap->Width;
Bildgerechnet = false;
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::FormActivate(TObject *Sender)
{

if ( GoIsDone )
	{
	if ( this == DCWd->AktivesFenster ) return;
	DCWd->BildShow(0);
	DCWd->DisplMbmEdit();
	if ( ColorBarWd->Visible )
		ColorBarWd->BringToFront();
	}
}
//---------------------------------------------------------------------------

void  TOrbitWd::FirstAuswertung(double x, double y)
{
int			cx,cy;
long double	cxd;

cxd = BildKoo.X(Params.cx);
cxd *= Params.ViewAngle;
cx = cxd;
cy = BildKoo.Y(Params.cy);

Anzeige->posCallBack = NULL;
if ( MinzFirstIterCB->Checked )
	{
	ImageBitmap->Canvas->Pen->Color = 0x0005000;
	ImageBitmap->Canvas->MoveTo(x,y);
	ImageBitmap->Canvas->LineTo(x+((x-cx)/3),y+((y-cy)/3));
	}
if ( MitOrbitLinienCB->Checked )
	{
	ImageBitmap->Canvas->MoveTo(x,y);
	ImageBitmap->Canvas->Pen->Color = 0x0404040;
	Anzeige->posCallBack = &SingleAuswertung;
	}
if ( IterNrEd->Value > 0 )
	{
	ImageBitmap->Canvas->MoveTo(x,y);
	Anzeige->posCallBack = &SingleAuswertung;
	}
}
//---------------------------------------------------------------------------

void  TOrbitWd::SingleAuswertung(double x, double y)
{
int	i = IterNrEd->Value - Anzeige->iNummer;

if ( MitOrbitLinienCB->Checked )
	{
	if ( x == PointisOutside )
		ImageBitmap->Canvas->Pen->Color = 0x0202060;
	else
		{
		ImageBitmap->Canvas->LineTo(x,y);
		ImageBitmap->Canvas->Pen->Color = 0x0404040;
		if ( IterNrEd->Value > 0 )
			if (( i == 1 ) | ( i == 0 ))
				ImageBitmap->Canvas->Pen->Color = 0x0802020;
		}
	}
else
	if ( IterNrEd->Value > 0 )
		{
		if ( i == 1 )
			ImageBitmap->Canvas->MoveTo( x,y);
		if (( i == 0 ) | ( i == -1 ))
			{
			ImageBitmap->Canvas->Pen->Color = 0x0802020;
			ImageBitmap->Canvas->LineTo(x,y);
			}
		}
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::NeuRechnen( bool RestRechnen )
{
long double	a,cc;

if ( BerechnenLaeuft ) return;

DCWd->GetEditParameter();
StopTb->Visible = true;
rTb->Visible = false;
iTb->Visible = false;
BildKoo.Set(&Params);
DCWd->DisplMbmEdit();
BerechnenLaeuft = true;

delete Anzeige;
Anzeige = new MbmAnzOa();
Params.Emode = D_Apfelmaennchen;
a = ViewAngelTB->Position;
a /= ViewAngelTB->Max;
Params.ViewAngle = 1.0 - a;

/*
PreImageBitmap->Canvas->Brush->Color = clBlack;
PreImageBitmap->Canvas->FillRect(BildIm->ClientRect);
if ( MitOrbitLinienCB->Checked )
	{
	Anzeige->posCallBack = &FirstAuswertung;
	}
*/
//Statusp2->Style = psOwnerDraw;
//Timer1->Enabled = true;

Params.VorlaufIter = StartJedeEd->Value;
if (( MitOrbitLinienCB->Checked ) | ( MinzFirstIterCB->Checked ))
	{
	Anzeige->posCallBack = &FirstAuswertung;
	}
else
	if ( IterNrEd->Value > 0 )
		Anzeige->posCallBack = &FirstAuswertung;
ImageBitmap->Canvas->Brush->Color = clBlack;
ImageBitmap->Canvas->FillRect(BildIm->ClientRect);

if ( TpQuelleCb->ItemIndex == 1 )
	Anzeige->SetOrbitKoo( &CursorXbi, &CursorYbi );
else
	Anzeige->SetOrbitKoo( &(Params.tpx), &(Params.tpy) );

Anzeige->Erstellen( &Params, Ergebnis, 1, 0 );
Bildgerechnet = true;

//Timer1->Enabled = false;
//Statusp2->Style = psText;
Anzeige->posCallBack = NULL;
if ( MinzFirstIterCB->Checked )
	{
	ImageBitmap->Canvas->Pen->Color = 0x0005000;
	a = BildKoo.X( Anzeige->minx );
	a *= Params.ViewAngle;
	cc = Params.BildSizeX;
	cc /= Params.MaxIter;
	cc *= Anzeige->mini;
	cc *= 1.0 - Params.ViewAngle;
	a += cc;
	ImageBitmap->Canvas->MoveTo( a , BildKoo.Y( Anzeige->miny ));
	a = BildKoo.X( 0.0 );
	a *= Params.ViewAngle;
	ImageBitmap->Canvas->LineTo( a , BildKoo.Y( 0.0 ));
	}
MinIterEd->Text = IntToStr( Anzeige->mini );
BerechnenLaeuft = false;
StopTb->Visible = false;
StopTb->Marked = false;
rTb->Visible = true;
iTb->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::NeuZeichnen()
{
long double		*erg, ergld;
int				i,o,f,fh,x,y,h,w,*scl,*hscl;

if ( !Bildgerechnet ) return;

GetBlende();
DCWd->GetZeichnenParameter( );
ColorBarWd->SetScala( );
ColorBarWd->PaintCb();
erg = Ergebnis;
h = ImageBitmap->Height;
w = ImageBitmap->Width;
for ( y=0; y<h; y++ )
	{
	scl = (int *)ImageBitmap->ScanLine[y];
/*
	if ( Params.ZusatzMode & 0x0020 ) 				// hinterlegte MBM aktiv ?
		{
		hscl = (int *)HmbmBitmap->ScanLine[y];
		for ( x=0; x<w; x++ )
			{
			i = ColorBarWd->GetColor( *erg++ );
			f = i & 0x0ff;
			fh = hscl[x] & 0x0ff;
			if ( fh > f )
				o = fh;
			else
				o = f;
			f = i & 0x0ff00;
			fh = hscl[x] & 0x0ff00;
			if ( fh > f )
				o |= fh;
			else
				o |= f;
			f = i & 0x0ff0000;
			fh = hscl[x] & 0x0ff0000;
			if ( fh > f )
				o |= fh;
			else
				o |= f;

			scl[x] = o;
			}
		}
	else												// ohne Hinterlegte MBM zeichnen
*/
		for ( x=0; x<w; x++ )
			{
			if ( *erg != 0 ) 							// ist schon schwarz und soll unver�ndert bleiben, falls Linie!!!
				{
				scl[x] = ColorBarWd->GetColor( *erg );
				}
			erg++;
			}
	}
RefreshAnzeige(0);
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::SpeichernOad( String Filebez )
{
zrdSL = new TStringList();

SpeichernOadFile = true;
zrdSL->Add("   OrbitAnalyseDaten");
zrdSL->Add("B  "+FormatFloat("000000.000",Params.BildSizeX)+";  "+FormatFloat("000000.000",Params.BildSizeY)+";  &H008080;  ");
Anzeige->oadCallBack = &oadAuswertung;
RefreshAnzeige(0);
NeuRechnen(false);
zrdSL->SaveToFile(Filebez);
delete zrdSL;
zrdSL = NULL;
SpeichernOadFile = false;
Anzeige->oadCallBack = NULL;
}
//---------------------------------------------------------------------------

void  TOrbitWd::oadAuswertung(double x, double y, long treffer)
{
zrdSL->Add("B  "+FormatFloat("000000.000",x)+";  "+FormatFloat("000000.000",y)+";  &H"+IntToHex(ColorBarWd->GetColor( treffer ),6)+";  ");
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::FormKeyPress(TObject *Sender, wchar_t &Key)
{

	switch ( Key )
		{
		case L',':
		case L'0':
		case L'1':
		case L'2':
		case L'3':
		case L'4':
		case L'5':
		case L'6':
		case L'7':
		case L'8':
		case L'9':
		case L'+':
		case L'-':
		case L'E':
		case L'e':	return;		break;
		default:    TBildWd::FormKeyPress( Sender, Key );
					Key = 0;
		}
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{

TBildWd::FormKeyDown( Sender, Key, Shift );
Key = 0;
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::FormKeyNow( WORD &Key )
{

TBildWd::FormKeyNow( Key );
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::TpMouseMove( Word Key )
{
if ( SofortRechnenCb->Checked )
	{
	if (( Key == comTestpoint ) & ( TpQuelleCb->ItemIndex < 1 ))
		{
		Params.tpx = CursorXbi;
		Params.tpy = CursorYbi;
		NeuRechnen( false );
		NeuZeichnen();
		}
	if (( Key == isMouseMove ) & ( TpQuelleCb->ItemIndex == 1 ))
		{
		Params.tpx = CursorXbi;
		Params.tpy = CursorYbi;
		NeuRechnen( false );
		NeuZeichnen();
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::OaPrMouseMove(TObject *Sender, TShiftState Shift, int X,
		  int Y)
{
OaPr->SetFocus();
}
//---------------------------------------------------------------------------


void __fastcall TOrbitWd::IterNrEdSpinBtnDownClick(TObject *Sender)
{

NeuRechnen( false );
NeuZeichnen();
}
//---------------------------------------------------------------------------

void __fastcall TOrbitWd::ChangeViewLBtnClick(TObject *Sender)
{
static	bool 	isruning;
static	int		stepi;
int				p;

if ( stepi == 0 )
	stepi = ((TSpeedButton*)Sender)->Tag;
else
	if ( stepi == ((TSpeedButton*)Sender)->Tag )
		stepi = 0;
	else
		stepi = ((TSpeedButton*)Sender)->Tag;
if ( isruning ) return;
p = ViewAngelTB->Position;
isruning = true;
do
	{
	this->NeuRechnen(false);
	this->NeuZeichnen();
	p += stepi;
	ViewAngelTB->Position = p;
	ViewAngelTB->SelEnd = p;
	Application->ProcessMessages();
	Sleep(20);
	}
while (( p >= 0 )&( p <= ViewAngelTB->Max )&(stepi != 0));
isruning = false;
stepi = 0;

}
//---------------------------------------------------------------------------

