#ifndef MbmAnzH
#define MbmAnzH
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnz
{

public:
						MbmAnz();
						~MbmAnz();

		    int			getDarstellung( int index );
			BigIntIter*	openAuswertung( int aa );

virtual		void		SetBase( TMainParams* );
virtual		void		SetFullSize( TMainParams* );
virtual		char*		getAuswertungsHelp(TLMDComboBox* );
static		void		writeAuswertungsListe(TLMDComboBox*, int idx, int i );

virtual     void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz ) = 0;
virtual     void	    Erstellen( TMainParams *Params, long double *ergtab, int TaskAnz, int TaskNr ) = 0;
virtual     void	    TestIter( TMainParams *Params, TDIterErgebnis* ie ) = 0;
virtual	 	void		SetOrbitKoo( bigint*, bigint* );


			int			PbMax,PbPos; 				// F�r Progressbaranzeige
			int			PosibleTasks;				// F�r abfrage m�glicher tasks
			bool		StopSignal;
			int			Height,Width;
			bigint		delta;
			void  		( __closure *biiCallBack)(BigIntIter *biicb);
			void  		( __closure *posCallBack)( double x, double y );
			void  		( __closure *oadCallBack)( double x, double y, long treffer );

			bigint		bmin,minx,miny,iNx,iNy;
			int			iNummer,mini;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzMI : public MbmAnz 			// Menge Iterationennummer
{

public:
						MbmAnzMI();
						~MbmAnzMI();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );

private:
			BigIntIter		*BiiTab;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzMZ : public MbmAnz 			// Menge Z - Absolutwert
{

public:
						MbmAnzMZ();
						~MbmAnzMZ();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );

private:
			BigIntIter		*BiiTab;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzBB : public MbmAnz			// Buddabrot  -  Aufsummierung der Orte
{

public:
						MbmAnzBB();
						~MbmAnzBB();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );


private:
			bigint		cxl,cxr,cyt,cyb;
public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzBBr : public MbmAnz			// Buddabrot  -  Aufsummierung der Orte   - Reversfunktion
{

public:
						MbmAnzBBr();
						~MbmAnzBBr();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );


private:
			bigint		cxl,cxr,cyt,cyb;
public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzEO : public MbmAnz			// Ergebnisort
{

public:
						MbmAnzEO();
						~MbmAnzEO();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );


private:
            bigint		cxl,cxr,cyt,cyb;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzEU : public MbmAnz			// Ergebnisort Ursprung
{

public:
						MbmAnzEU();
						~MbmAnzEU();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams *Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams *Params, TDIterErgebnis* ie );


private:
			TMainParams		*ErgOrt;
			int				*ScanTab;
			bigint			cxl,cxr,cyt,cyb,deltaF;
			int				HeightF,WidthF;
			long double		refsizeradius;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzEL : public MbmAnz			// Ergebnisort entlang einer Linie
{

public:
						MbmAnzEL();
						~MbmAnzEL();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );


private:
			TMainParams	*Param;
			bigint			cxl,cxr,cyt,cyb;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzEW : public MbmAnz			// ErgebnisWinkel
{

public:
						MbmAnzEW();
						~MbmAnzEW();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* , long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* , TDIterErgebnis* ie );


private:
			long double 	*ErgTab;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzRB : public MbmAnz			// Reverse Buddabrot
{

public:
						MbmAnzRB();
						~MbmAnzRB();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* , long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* , TDIterErgebnis* ie );


private:
			TMainParams	*Param;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzOa : public MbmAnz			// Orbitanalyse
{

public:
						MbmAnzOa();
						~MbmAnzOa();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* , long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* , TDIterErgebnis* ie );
			void		SetOrbitKoo( bigint*, bigint* );

private:
			bigint		cxl,cxr,cyt,cyb,*ox,*oy;
public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MbmAnzCa : public MbmAnz			// Chaosanalyse
{

public:
						MbmAnzCa();
						~MbmAnzCa();

static		void		getAuswertungsListe(TLMDComboBox*, int idx );
			char*		getAuswertungsHelp(TLMDComboBox* );

			void	    NeueAuswertung( TMainParams*, long double *ergtab, int TaskAnz );
			void		Erstellen( TMainParams* Params, long double *ergtab, int TaskAnz, int TaskNr );
			void	    TestIter( TMainParams* Params, TDIterErgebnis* ie );

private:
			bigint			cxl,cxr,cyt,cyb;

public:
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
#endif

