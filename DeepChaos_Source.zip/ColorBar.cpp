//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "Tastencodes.h"
#include "String.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "ColorBar.h"
#include "OrbitAnalyse.h"
#include "PhasenAnalyse.h"
#include "HelpForm.h"
#include "DatenBankForm.h"
#include "ZeitReihe.h"
#include "ColorSelect.h"
#include "BildForm.h"
#include "DCMAIN.h"
#include "jpeg.hpp"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TColorBarWd *ColorBarWd;
//---------------------------------------------------------------------------
__fastcall TColorBarWd::TColorBarWd(TComponent* Owner): TForm(Owner)
{

Sf = "ColorbarWindow";
//Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
//Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
//Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", 250 );
//Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", 400 );

IterGrenze = 1000;
Params = &Pinit;
PCbd = &(Params->ColorBarData);
SetLog();
TabGefasst = TabShift = false;

csb->Max = COLORSMAX;
csb->Position = 0;
SetBar(0,cbFullSize);

rotatepos = 0;

FileN = L"ColorsNeu.pal";

ErzeugeCb();
SetScala( );
PaintCb();
warschon = false;
CloseNow = false;
Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormActivate(TObject *Sender)
{

if ( !warschon )
	{
	Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
	Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
	Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", Constraints->MinWidth );
	Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", Constraints->MinHeight );
	}
warschon = true;
Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::CloseMiClick(TObject *Sender)
{

this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormCloseQuery(TObject *Sender, bool &CanClose)
{

this->Visible = false;
CanClose = CloseNow;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormClose(TObject *Sender, TCloseAction &Action)
{

DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
DCWd->SettingsFile->WriteInteger(Sf, "Width", Width );
DCWd->SettingsFile->WriteInteger(Sf, "Heigth", Height );

Action = caFree;
}
//---------------------------------------------------------------------------

int TColorBarWd::GetTabNr( long double akt )
{
long double d;

if ( PCbd->Level > akt ) return 0;
if ( PCbd->Scala <= akt ) return COLORSMAX - 1;

d = powl(plusminus<0?PCbd->Scala-akt:akt-PCbd->Level,1.0/ScalaExpo) / gettabnrdivisor;
return  (plusminus<0?COLORSMAX-d:d);
}

//---------------------------------------------------------------------------
int TColorBarWd::GetTabNrScroll( long double akt )
{
long double     t;

t = GetTabNr(akt);
t -= csb->Position;
t /= cbistep;
return t;
}
//---------------------------------------------------------------------------

long double TColorBarWd::GetTabValue( int tabnr )
{
long double d,p;

d = powl(COLORSMAX,ScalaExpo)/COLORSMAX;
d = powl(plusminus<0?COLORSMAX-tabnr:tabnr,ScalaExpo) / d;
p = (plusminus<0?COLORSMAX-d:d);
d = (( PCbd->Scala - PCbd->Level) / COLORSMAX);
return ( p * d ) + PCbd->Level;
}
//---------------------------------------------------------------------------

int     TColorBarWd::GetLineX( int tabnr )
{
long double d;

d = powl(COLORSMAX,ScalaExpo)/(cbi->Width - 12);
d = powl(plusminus<0?COLORSMAX-tabnr:tabnr,ScalaExpo) / d;
return  (plusminus<0?(cbi->Width - 12)-d:d);
}
//---------------------------------------------------------------------------

void	TColorBarWd::SetScala( const long double l, const long double  s, const int lf)
{

if ( l < s )
	PCbd->Level = l;
else
	PCbd->Level = 0;
PCbd->Scala = s;
PCbd->LogFaktor = lf;
SetLog();
gettabnrdivisor = powl((PCbd->Scala-PCbd->Level),1.0/ScalaExpo)/COLORSMAX;

rotatepos = 0;
}
//---------------------------------------------------------------------------

void	TColorBarWd::SetScala( )
{

IterGrenze = Params->MaxIter;
if ( Params->Zlevel < Params->Zscala )
	PCbd->Level = Params->Zlevel;
else
	PCbd->Level = 0;
PCbd->BlendenMode = Params->BlendenMode;
PCbd->Scala = Params->Zscala;
SetLog();
gettabnrdivisor = powl((PCbd->Scala-PCbd->Level),1.0/ScalaExpo)/COLORSMAX;

rotatepos = 0;
}
//---------------------------------------------------------------------------
/*
void	TColorBarWd::Load( TDColorBarData *cbd)
{

ColorBarData = cbd;
csb->Position = 0;
SetLog();
SetBar(0,cbFullSize);

ErzeugeCb();
PaintCb();
}

//---------------------------------------------------------------------------
void	TColorBarWd::Save( TDColorBarData *cbd)
{

cbd = ColorBarData;
}
*/
//---------------------------------------------------------------------------
bool  	TColorBarWd::ReadPal(int FHandle )
{
char		typ[512];
int			ct,ctl;
union	 {	int	cdi; 	char cdc[4];	} cd;

PCbd->ScalaLogPoint = 0;
PCbd->Level = 0;
PCbd->Scala = 100;
FileRead(FHandle, typ, 32);
typ[32] = 0x00;
if ( strcmp("DeepChaosColorTabellePal.Vers4  ",typ) == 0 )
	{
	FileRead(FHandle, &(Params->ColorBarData), sizeof(Params->ColorBarData)); 		// Version 4 File
	}
else
	{
	FileSeek(FHandle,0,0);
	FileRead(FHandle, typ, 32);
	typ[32] = 0x00;
	if ( strcmp("DeepChaosColorTabellePal.Vers3  ",typ) == 0 )
		{
		FileRead(FHandle, PCbd->ColorTabelle, sizeof(PCbd->ColorTabelle)); 		// Version 3 File
		}
	else
    	{
		FileSeek(FHandle,0,0);
		FileRead(FHandle, typ, 24);
		typ[24] = 0x00;
		if ( strcmp("DeepChaosColorTabellePal",typ) == 0 )
			{
		    FileRead(FHandle, typ, 512);
		    for ( ct=0; ct<32; ct++ )	// Werte einzeln auslesen, ohne isobaren-Merker
        		{
				ctl = ct * 16;
	            cd.cdc[0] = typ[(ctl+0)];
    	        cd.cdc[1] = typ[(ctl+1)];
        	    cd.cdc[2] = typ[(ctl+2)];
            	cd.cdc[3] = typ[(ctl+3)];
				PCbd->ColorTabelle[ct].pos = cd.cdi;
    	        cd.cdc[0] = typ[(ctl+4)];
        	    cd.cdc[1] = typ[(ctl+5)];
            	cd.cdc[2] = typ[(ctl+6)];
	            cd.cdc[3] = typ[(ctl+7)];
				PCbd->ColorTabelle[ct].color = cd.cdi;
        	    cd.cdi = 0;
            	if ( typ[ctl+8] > 0 )		// Merker = true ?
	            	{
		            cd.cdc[0] = typ[(ctl+12)];
					cd.cdc[1] = typ[(ctl+13)];
        		    cd.cdc[2] = typ[(ctl+14)];
            		cd.cdc[3] = typ[(ctl+15)];
	                }
				PCbd->ColorTabelle[ct].isobreite = cd.cdi;
				}
            }
        else
        	{
			return false;        		// Kein g�ltiges File
			}
        }
	}
if ( PCbd->BlendenMode == bePaletteFix )
	{
	DCWd->BlendeMaxEd->Text = FloatToStr(PCbd->Scala);
	DCWd->BlendeMinEd->Text = FloatToStr(PCbd->Level);
	DCWd->BlendenModeCb->ItemIndex = PCbd->BlendenMode;
	}

csb->Position = 0;
SetLog();
SetBar(0,cbFullSize);

ErzeugeCb();
PaintCb();
return true;
}
//---------------------------------------------------------------------------
void  	TColorBarWd::ReadBlobPal(TStream *ps )
{
char		typ[10];

ps->Read(typ,8);
typ[8] = 0;
if ( strcmp("DeepChaosColorTabellePal.Vers4  " ,typ) == 0 )
	{
	ps->Read(&(Params->ColorBarData), sizeof(Params->ColorBarData));
	}
csb->Position = 0;
SetLog();
SetBar(0,cbFullSize);

ErzeugeCb();
PaintCb();
}
//---------------------------------------------------------------------------
void  	TColorBarWd::SaveBlobPal(TStream *ps )
{

ps->Write("DeepChaosColorTabellePal.Vers4  " , 32);
ps->Write(&(Params->ColorBarData), sizeof(Params->ColorBarData));
}
//---------------------------------------------------------------------------
void  	TColorBarWd::SavePal(int FHandle )
{

PCbd->Scala = StrToFloat(DCWd->BlendeMaxEd->Text);
PCbd->Level = StrToFloat(DCWd->BlendeMinEd->Text);
PCbd->BlendenMode = DCWd->BlendenModeCb->ItemIndex;
FileWrite(FHandle, "DeepChaosColorTabellePal.Vers4  ", 32);
FileWrite(FHandle, &(Params->ColorBarData), sizeof(Params->ColorBarData));
}
//---------------------------------------------------------------------------

int		TColorBarWd::GetColor(const long double akt)
{
/*
int	 s = GetTabNr( akt );  				// diese Version dauert l�nger

if ( s >= COLORSMAX )
	s = COLORSMAX - 1;
else
	if ( s < 0 )
		s = 0;
*/
long int	s;
long double a;

a = akt;
//if ( IterGrenze == a ) {						// Unendlich ( Iter-Grenze )
if ( IsNan( akt ) ) {								// Unendlich ( Iter-Grenze )
	return 0;                                   // Bitmapfarbe Schwarz
	}
if ( PCbd->BlendenMode == 7 ) {					// Wrap-Mode
	s = akt / PCbd->Scala;
	a -= s * PCbd->Scala;
	}
if ( PCbd->Level > a )
	s = 0;
else
	if ( PCbd->Scala <= a )
		s = COLORSMAX - 1;
	else
		{
		s = powl(plusminus<0?PCbd->Scala-a:a-PCbd->Level,1.0/ScalaExpo) / gettabnrdivisor;
		s = (plusminus<0?COLORSMAX-s:s);
		}
return Colors[s].ColorBitmap;
}
//---------------------------------------------------------------------------

int		TColorBarWd::GetColor32(const long double f)
{
int				s;

s = GetTabNr( f );
if ( s >= COLORSMAX )
	s = COLORSMAX - 1;
else
	if ( s < 0 )
		s = 0;

return Colors[s].Color32;
}
//---------------------------------------------------------------------------
int		TColorBarWd::GetColor32Scroll(const int nr)
{
int		i;
float	f;

f = nr;
f *= cbistep;
i = f;
i += csb->Position;

return Colors[i].Color32;
}
//---------------------------------------------------------------------------

void  	TColorBarWd::PaintCb()
{
int				y;
long double		sm;

cbi->Canvas->Pen->Color = 0x00FEEBF9;
cbi->Canvas->Brush->Color = 0x00FEEBF9;
cbi->Canvas->Rectangle(0,0,cbi->Width,cbi->Height);

for ( y=0; y<cbi->Height; y++ )                          // Colorscala erzeugen
	{
	sm = y;
	sm *= cbistep;
	sm += csb->Position;
	cbi->Canvas->Pen->Color = Colors[int(sm)].Color32;
	cbi->Canvas->MoveTo(0,y);
	cbi->Canvas->LineTo(12,y);
	}
PaintFt();
HistPaint();
}
//---------------------------------------------------------------------------
void  	TColorBarWd::PaintFt()
{
int				i,isi,x,y,p;
long double		step,sm;
AnsiString		v;

isi = PCbd->ScalaLogPoint + COLORSMAX/2;
isi = (isi - csb->Position) / cbistep;
cbi->Canvas->Pen->Color = clSilver;
if ( PCbd->ScalaLogPoint == 0 ) cbi->Canvas->Brush->Color = clSilver;
sm = PCbd->Scala - PCbd->Level;  		 // Logarithmuslinie zeichnen
sm /= cbi->Width - 12;
for ( i=0; i<cbi->Height; i++)
	{
	x = GetLineX( (( (i) * cbistep  ) + csb->Position  ) );
	cbi->Canvas->Pixels[x+16][i] = clSilver;
	if ( i == isi)
		{
		cbi->Canvas->Ellipse(16,i-10,16+20,i+10);
		}
	}
cbi->Canvas->Brush->Color = clWhite;

step = cbi->Height;
step /= csb->PageSize;						  		// FarbTabs anzeigen
cbi->Canvas->Font->Height = 4;
cbi->Canvas->Font->Color = clGreen;
cbi->Canvas->Brush->Style = bsClear;

i = -1;
do
	{
	i++;
	p = PCbd->ColorTabelle[i].pos;
	if (( p >= csb->Position ) && ( p <= ( csb->Position + csb->PageSize )))
		{
		sm = step * ( p - csb->Position );
		y = int(sm);
		if ( PCbd->ColorTabelle[i].isobreite )
        	{
			cbi->Canvas->Pen->Color = clRed;
            }
		else
			{
			cbi->Canvas->Pen->Color = clBlack;
        	}
		v = FormatFloat("+0.000 000 000 000 E+",GetTabValue(p));
		cbi->Canvas->Font->Name = "Arial";
		cbi->Canvas->Font->Height = 13;
		cbi->Canvas->Font->Pitch = fpFixed;
		cbi->Canvas->TextOut(16,y-((y>11)?(+11):(+0)),v);
		cbi->Canvas->MoveTo(0,y);
		cbi->Canvas->LineTo(cbi->Width ,y);
		}
	} while ( PCbd->ColorTabelle[i].pos < COLORSMAX );
cbi->Canvas->Brush->Style = bsSolid;
}
//---------------------------------------------------------------------------

void  	TColorBarWd::ErzeugeCb()
{
int				x,y,i,j,pos0,pos1,colmax;
long			h;
long double		dr,dg,db,sr,sg,sb,hr,hg,hb;

rotatepos = 0;

i = j = colmax = 0;
while ( i < COLORTABS )   				// Tabelle checken
	{
	if ( colmax <= PCbd->ColorTabelle[i].pos )
		{
		colmax = PCbd->ColorTabelle[i].pos;
		j = i;
		}
	i++;
	}
if ( colmax > COLORSMAX )
	colmax = COLORSMAX;
PCbd->ColorTabelle[j].pos = COLORSMAX;
i = 0;
x = 0;
while ( PCbd->ColorTabelle[i].pos < colmax )   // Farben berechen
	{
	if ( PCbd->ColorTabelle[i].isobreite == 0 )
		{
		j = i+1;
		while( PCbd->ColorTabelle[j].isobreite > 0 ) j++;
		pos0 = PCbd->ColorTabelle[i].pos;
		pos1 = PCbd->ColorTabelle[j].pos;
		dr = PCbd->ColorTabelle[j].color & 0x000000FF;
		dr -= sr = PCbd->ColorTabelle[i].color & 0x000000FF;
		dr = dr / ( pos1 - pos0 );
		dg = PCbd->ColorTabelle[j].color & 0x0000FF00;
		dg -= sg = PCbd->ColorTabelle[i].color & 0x0000FF00;
		dg = dg / ( pos1 - pos0 );
		db = PCbd->ColorTabelle[j].color & 0x00FF0000;
		db -= sb = PCbd->ColorTabelle[i].color & 0x00FF0000;
		db = db / ( pos1 - pos0 );
		while ( x < pos1 )
			{
			hr = ( dr * ( x - pos0 ) + sr );
			hg = ( dg * ( x - pos0 ) + sg );
			hb = ( db * ( x - pos0 ) + sb );
			Colors[x].ColorR =  (long(hr)) & 0x00FF ;
			Colors[x].ColorG =  (long(hg) >> 8)  & 0x00FF ;
			Colors[x].ColorB =  (long(hb) >> 16) & 0x00FF ;
			h  = long( hr ) & 0x000000FF;
			h |= long( hg ) & 0x0000FF00;
			h |= long( hb ) & 0x00FF0000;
			Colors[x].Color32 =  h;
			Colors[x].ColorBitmap = ( Colors[x].ColorB | (Colors[x].ColorG<<8) | (Colors[x].ColorR<<16) );
			x++;
			}
		}
	i++;
	}
i = 0;
while ( PCbd->ColorTabelle[i].pos < colmax )   // IsobarenFarben berechen
	{
	if ( PCbd->ColorTabelle[i].isobreite > 0 )
		{
		for ( y=0; y<PCbd->ColorTabelle[i].isobreite+1; y++ )
			{
			j = PCbd->ColorTabelle[i].pos-(PCbd->ColorTabelle[i].isobreite/2)+y;
			if (( j >= 0 ) && ( j < COLORSMAX ))
				{
				h = PCbd->ColorTabelle[i].color;
				Colors[j].Color32 = h;
				Colors[j].ColorR =  (h) & 0x00FF ;
				Colors[j].ColorG =  (h >> 8)  & 0x00FF ;
				Colors[j].ColorB =  (h >> 16) & 0x00FF ;
                Colors[j].ColorBitmap = ( Colors[j].ColorB | (Colors[j].ColorG<<8) | (Colors[j].ColorR<<16) );
				}
			}
		}
	i++;
	}
}
//---------------------------------------------------------------------------
bool	TColorBarWd::NewColor(int y)
{
int				i,imax,j,nd,ni,n,ap;
long double		vf;
AnsiString		v;

TabGefasst = false;
vf = y;
vf *= cbistep;
ap = csb->Position + vf;
i = -1;
nd = COLORSMAX + 2;
do
	{
	i++;
	if ( i >= COLORTABS )
		break;
	n = abs( ap - PCbd->ColorTabelle[i].pos  );
	if ( n < nd )
		{
		nd = n;				// n�hesten Tab merken
		ni = i;
		}
	imax = i;
	} while ( PCbd->ColorTabelle[i].pos < COLORSMAX );
ColorsSelect->MaxTabs = imax;
vf = nd;
vf /= cbistep;
if ( vf <= 3 )          					// Tab nur 3 Pixel weg ?
	{
	ColorsSelect->IsoBreite->Text = IntToStr(PCbd->ColorTabelle[ni].isobreite);
	ColorsSelect->FarbTabNrEd->Text = IntToStr(ni);
	ColorsSelect->FarbTabNrEd->Tag = ni;
	vf = ( PCbd->ColorTabelle[ni].pos * ScalaStep ) + PCbd->Level;
	v = FloatToStr(vf);
	ColorsSelect->AktPos->Text = v;

	ColorsSelect->OldColor->Color = PCbd->ColorTabelle[ni].color;
	if ( ColorsSelect->ShowModal() == 1 )
		{
		PCbd->ColorTabelle[ni].color = ColorsSelect->NewColor->Color;
		PCbd->ColorTabelle[ni].isobreite = StrToInt(ColorsSelect->IsoBreite->Text);
		ErzeugeCb();
		PaintCb();
		return true;
		}
	}
else					// Tab nicht da.........Neuer Tab
	{
	ColorsSelect->IsoBreite->Text = "0";
	ColorsSelect->FarbTabNrEd->Text = "New";
	ColorsSelect->FarbTabNrEd->Tag = -1;
	vf = ( ap * ScalaStep ) + PCbd->Level;
	v = FloatToStr(vf);
    ColorsSelect->AktPos->Text = v;
	if ( ColorsSelect->ShowModal() == 1 )
		{
        vf = StrToFloat(ColorsSelect->AktPos->Text);
        vf -= PCbd->Level;
        vf /= ScalaStep;
		ap = vf;
		i = 0;
		while ( PCbd->ColorTabelle[i].pos < COLORSMAX )
			{
			if (( ap > PCbd->ColorTabelle[i].pos ) && ( ap < PCbd->ColorTabelle[i+1].pos ))
				{
				j = imax;
				while ( j > i )			// oberen Tabellenteil rechtsschieben f�r Einf�gen
					{
					PCbd->ColorTabelle[j+1] = PCbd->ColorTabelle[j];
					j--;
					}
				PCbd->ColorTabelle[i+1].pos = ap;
				PCbd->ColorTabelle[i+1].color = ColorsSelect->NewColor->Color;
				PCbd->ColorTabelle[i+1].isobreite = StrToInt(ColorsSelect->IsoBreite->Text);

				ErzeugeCb();
				PaintCb();
				return true;
				}
			i++;
			}
		}
	}
return false;
}
//---------------------------------------------------------------------------
bool	TColorBarWd::DeleteColor(int y)
{
int				i,nd,ni,n,ap;
long double		vf;

TabGefasst = false;
vf = y;
vf *= cbistep;
ap = csb->Position + vf;
i = 0;
nd = COLORSMAX + 2;
while ( PCbd->ColorTabelle[i].pos < COLORSMAX )
	{
	n = abs( ap - PCbd->ColorTabelle[i].pos  );
	if ( n < nd )
		{
		nd = n;
		ni = i;
		}
	i++;
	}
vf = nd;
vf /= cbistep;
if ( vf <= 3 )          					// Tab nur 3 Pixel weg ?
	{
	TabSelect = ni;
	i = ni;
	while ( PCbd->ColorTabelle[i].pos < COLORSMAX ) 	// oberen Tabellenteil linksschieben f�r L�schen
		{
		PCbd->ColorTabelle[i] = PCbd->ColorTabelle[i+1];
		i++;
		}
	ErzeugeCb();
	PaintCb();
	return true;
	}
return false;
}
//---------------------------------------------------------------------------
void	TColorBarWd::SelectColor(int y)
{
int			i,nd,ni,n,ap;
long double	vf;

TabGefasst = TabShift = false;
vf = y;
vf *= cbistep;
ap = csb->Position + vf;
i = 1;
nd = COLORSMAX + 2;
while ( PCbd->ColorTabelle[i].pos < COLORSMAX )				// Tab suchen
	{
	n = abs( ap - PCbd->ColorTabelle[i].pos  );
	if ( n < nd )
		{
		nd = n;
		ni = i;
		}
	//- ColorTabelleNcp[i] = ColorTabelle[i].pos;
	i++;
	}
TabEnd = i;
vf = nd;
vf /= cbistep;
if ( vf <= 8 )          					// Tab nur 3 Pixel weg ?
	{
	TabSelect = ni;
	TabGefasst = true;
	TabPos = y;
	TabUp = ap;
	}
else
	{
	i = 1;
	while ( i < TabEnd )
		{
		ColorTabelleNcp[i] = PCbd->ColorTabelle[i].pos;	// Ncp f�r default laden falls Mouse nicht bewegt wird!
		i++;
		}

	i = 0;
	while ( ap > PCbd->ColorTabelle[i].pos )  			// alle Tabs schieben einleiten
		{
		TabSelect = i;
		i++;
		}
	TabShift = true;
	TabPos = TabUp = ap;
	Save_Cursor = Screen->Cursor;
	if ( CommandKey == comShift )
		Screen->Cursor = crVSplit;
	}
}
//---------------------------------------------------------------------------
void	TColorBarWd::MoveColor(int x, int y)
{
int		p,i,ap,r,v;
float	fo,fu,ni;

ap = y;
if ( ap > cbi->Height ) return;
ap = csb->Position + ( y * cbistep );
if ( TabGefasst )
	{
	if ( y>cbi->Height ) return;
	if ( PCbd->ColorTabelle[TabSelect].isobreite == 0 )
		{
		r = TabSelect - 1;
		v = TabSelect + 1;
		while ( (r > 1) && ( PCbd->ColorTabelle[r].isobreite > 0 ) )	// unteren Tabtab suchen
			{
			r--;
			}
		while ( (v < COLORTABS) && ( PCbd->ColorTabelle[v].isobreite > 0 ) )	// oberen Farbtab suchen
			{
			v++;
			}
		if (( PCbd->ColorTabelle[r].pos >= ap ) || ( PCbd->ColorTabelle[v].pos <= ap ))
			return;
		}
	cbi->Canvas->Pen->Color = clWhite;
	cbi->Canvas->MoveTo(18,TabPos);
	cbi->Canvas->LineTo(45,TabPos);
	cbi->Canvas->Pen->Color = clBlue;
	cbi->Canvas->MoveTo(18,y);
	cbi->Canvas->LineTo(45,y);
	TabPos = y;
	TabUp = ap;
	}
if ( TabShift )													// alle Tabs schieben
	{
	if ( y>cbi->Height ) return;
	cbi->Canvas->Pen->Color = clWhite;
	cbi->Canvas->Rectangle(18,0,cbi->Width,cbi->Height);
	fo = ap;                              // f�r obere Tabs
	fo /= TabPos;
	fu = COLORSMAX - ap;
	fu /= COLORSMAX - TabPos;            // f�r untere Tabs
	i = 1;
	while ( i < TabEnd )
		{
		ni = PCbd->ColorTabelle[i].pos;
		if ( i <= TabSelect )
			{
			if ( x < ( cbi->Width ))		// nur untere verschieben
				ni *= fo;
			}
		else
			{
			if ( x > 0 )			// nur obere verschieben
				{
				ni *= -1;
				ni += COLORSMAX;
				ni *= fu;
				ni *= -1;
				ni += COLORSMAX;
				}
			}
		ColorTabelleNcp[i] = ni;
		p = (ni / cbistep);
		cbi->Canvas->Pen->Color = clBlue;
		cbi->Canvas->MoveTo(18,p);
		cbi->Canvas->LineTo(45,p);
		i++;
		}
	}
}
//---------------------------------------------------------------------------
bool	TColorBarWd::MoveEndColor(int x, int y)
{
int		i;
bool	r;

r = false;
if (( x >= 0 )&&( x <= cbi->Width ))
	{
	if ( TabGefasst )
		{
		PCbd->ColorTabelle[TabSelect].pos = TabUp;
		r = true;
		}
	}
if ( TabShift )
	{
	i = 1;
	while ( i < TabEnd )
		{
		PCbd->ColorTabelle[i].pos = ColorTabelleNcp[i];
		i++;
		}
	r = true;
	}

if ( TabShift )
	{
	Screen->Cursor = Save_Cursor;	// Auf jeden Fall Cursor zur�ckladen
	}
TabGefasst = TabShift = false;
ErzeugeCb();
PaintCb();
return r;
}
//---------------------------------------------------------------------------
void __fastcall  TColorBarWd::SetBar( int y, int v )                                           //ok
{
int				old;
long double		yd;

yd = y;
yd *= cbistep;
old = yd + csb->Position;									//old Position

switch ( v )
	{
	case cbZoomOut:
		if ( csb->PageSize < csb->Max )						// und vergr��ern
			{
			if ( csb->PageSize*2 < csb->Max )
				csb->PageSize *= 2;
			else
				csb->PageSize = csb->Max;
			}
		break;
	case cbZoomIn:
		if ( csb->PageSize > cbi->Height )					// und verkleinern
			{
			if ( csb->PageSize/2 > cbi->Height )
				csb->PageSize /= 2;
			else
				csb->PageSize = cbi->Height;
			}
		break;
	case cbScroll:
		break;
	case cbFullSize:
		csb->PageSize = csb->Max;
		break;
	default:
		break;
	}
cbistep = csb->PageSize;
cbistep /= cbi->Height;
csb->Position = old - ( csb->PageSize / 2 );
if (( csb->Position + csb->PageSize ) > COLORSMAX ) csb->Position = COLORSMAX - csb->PageSize;
if ( csb->Position < 0 ) csb->Position = 0;
csb->LargeChange = csb->PageSize;
PaintCb();
}
//---------------------------------------------------------------------------
void  TColorBarWd::SetLog( const int y, const int lf )                               //ok
{
long double	l;

l = y;
if ( l < 0 ) l = 0;
if ( l >= cbi->Height ) l = cbi->Height-1;
l *= cbistep;                                       // so wegen Genauigkeit
l = ( l + csb->Position ) - (COLORSMAX/2);
PCbd->ScalaLogPoint = l;

SetLog();
}
//---------------------------------------------------------------------------
void  TColorBarWd::SetLog()
{
long double		slm,lwm;             // ..m   ist ...max

slm = ( PCbd->Scala - PCbd->Level );

ScalaExpoV = PCbd->LogFaktor;
ScalaExpoV = (ScalaExpoV<1?1:(ScalaExpoV>3)?3:ScalaExpoV);
lwm = PCbd->ScalaLogPoint;
lwm = (lwm>COLORSMAX/2?COLORSMAX/2:lwm);
plusminus = (lwm<0)?-1:1;
ScalaExpo = abs(lwm);
ScalaExpo /= 1000;                                  // Exponentenbereich 1.0 bis 8.192
ScalaExpo += 1;
ScalaExpo = powl(ScalaExpo,ScalaExpoV);              // Verst�rkung 1 bis 3

ScalaStep = (PCbd->Scala - PCbd->Level) / COLORSMAX;
//PaintCb();
}
//---------------------------------------------------------------------------
int  TColorBarWd::Pos( int y )                                                     //ok
{
long double	d;

if ( y >= cbi->Height ) return COLORSMAX;
d = y;                                          // Achtung cbistep ist double wegen Genauigkeit
d *= cbistep;
return ( d + csb->Position );
}
//---------------------------------------------------------------------------
																					//ok
long double  TColorBarWd::PosZ( int y )        		// R�ckw�rtsauswertung expo-Kurve
{
long double	d;

if ( y >= cbi->Height ) return PCbd->Scala;
d = y;
d *= cbistep;
return ( GetTabValue( d + csb->Position ));
}
//---------------------------------------------------------------------------
void __fastcall TColorBarWd::cbiMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
bool	c = false;

if ( Button == mbLeft )
	{
	if ( Shift.Contains(ssCtrl) )
		c = NewColor(Y);
	else if ( Shift.Contains(ssShift) )
		SetBar(Y, cbZoomIn);
	else if ( Shift.Contains(ssAlt) )
		SetLog(Y,PCbd->LogFaktor);
	else if ( CommandKey == comErase )
		c = DeleteColor(Y);
	else if ( CommandKey == comZoom )
		SetBar(Y, cbZoomIn);
	else if ( CommandKey == comLog )
		SetLog(Y,PCbd->LogFaktor);
	else if ( CommandKey == comFarbtab )                             /* TODO : brauchts das */
		c = NewColor(Y);
	else
		SelectColor(Y);
	}
else if ( Button == mbRight )
	{
	if ( Shift.Contains(ssCtrl) )
		{
		c = DeleteColor(Y);
		}
	else if ( Shift.Contains(ssShift) )
		SetBar(Y, cbZoomOut);
	else if ( CommandKey == comZoom )
		SetBar(Y, cbZoomOut);
	else
		{
		TPoint	lt;

		lt = cbi->ClientOrigin;
		//PopupMenuColors->Popup(X+lt.x,Y+lt.y);                           //??????????????
		return;
		}
	}
else if ( Button == mbMiddle )
	{
	if ( Shift.Contains(ssShift) )
		SetBar(Y, 0);
	}
if ( c )
	StatusBar->Panels->Items[2]->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::cbiMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
long double		vf;

if ( Shift.Contains(ssLeft))
	{
	if ( Shift.Contains(ssAlt) )
		SetLog(Y,PCbd->LogFaktor);
	else
		MoveColor(X,Y);
	}
else
	{
	cbHistMouseMove( Sender, Shift, X, Y);
	}
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::cbiMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y)
{

if (( Shift.Contains(ssCtrl) ) && ( Button == mbLeft ))
	{

	}
else if ( Button == mbLeft )
	{
	if ( MoveEndColor(X,Y) )
		StatusBar->Panels->Items[2]->Text = "";
	}
Screen->Cursor = Save_Cursor;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::cbHistMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
long double		vf,*e,*ee,v1,v2;
int				x;

	vf = Y;
	vf *= cbistep;
	vf += csb->Position;
	DCWd->ColorNrEd->Text = IntToStr(int(vf));
	DCWd->ColorNrP->Color = GetColor32Scroll(Y);
	v1 = GetTabValue(int(vf));
	v2 = GetTabValue(int(vf+cbistep));
	DCWd->REd->Text = "";
	DCWd->ArgEd->Text = "";
	DCWd->ErgebnisEd->Text = FloatToStr(v1);;
	DCWd->CPosXEd->Text = "";
	DCWd->CPosYEd->Text = IntToStr(Y);
	DCWd->CursXEd->Text = "";
	DCWd->CursYEd->Text = "";
	DCWd->FensterEd->Text = "ColorBar";
	if ( DCWd->AktivesFenster == NULL )
		return;

e = DCWd->AktivesFenster->Ergebnis;
ee = e + DCWd->AktivesFenster->ErgebnisSize;
x = 0;
while ( e < ee )
	{
	if ( *e >= v1 && *e < v2 )
		x++;
	e++;
	}
DCWd->HistEd->Text = IntToStr( x );
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::Scroll(TObject *Sender, TScrollCode ScrollCode, int &ScrollPos)
{
int		p;

p = csb->Max - csb->PageSize;
if ( csb->Position > p )
	csb->Position = p;
else if ( csb->Position < 0 )
	csb->Position = 0;
PaintCb();
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormPaint(TObject *Sender)
{

SetBar(0,0);
PaintCb();
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::ParamPaint( TMainParams *p )
{
String   s;

Params = p;
PCbd = &(Params->ColorBarData);
SetLog();
ErzeugeCb();
PaintCb();
StatusBar->Panels->Items[2]->Text = Params->CTFile;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::HistPaint()
{
long double		*e,v,l;
int				esize;
int				*h,i,t,m,x;
bool			vw;
if ( DCWd->AktivesFenster == NULL )	return;
if ( !this->Visible ) return;

cbHist->Canvas->Pen->Color = clWhite;
cbHist->Canvas->Brush->Color = clWhite;
cbHist->Canvas->Rectangle(0,0,cbHist->Width,cbHist->Height);

h = new int[cbHist->Height];
for ( i=0; i < cbHist->Height; i++ )
	h[i] = 0;
e = DCWd->AktivesFenster->Ergebnis;
esize = DCWd->AktivesFenster->ErgebnisSize;
m = 1;
for ( i=0; i<esize; i++)
	{
	t = GetTabNrScroll( e[i] );
	if ( t > 0 )          						// untersten und obersten Tab nicht mitberechnen,
		if ( t < cbHist->Height-1 )				// da diese meist �berdimensional.
			{
			h[t]++;
			if ( h[t] > m )
				m = h[t];
			}
	}
v = cbHist->Width;
v /= m;
cbHist->Canvas->Pen->Color = clBlack;
for ( i=0; i < cbHist->Height; i++ )
	{
	l = h[i];
	l *= v;
	x = l;
	cbHist->Canvas->MoveTo( cbHist->Width, i );
	cbHist->Canvas->LineTo( cbHist->Width - x, i );
	}
delete[] h;
}
//---------------------------------------------------------------------------
void __fastcall TColorBarWd::FormKeyPress(TObject *Sender, wchar_t &Key)
{
WORD	w;

w = Key;
if ( !keysemaphor ) FormKeyNow( w );
else keyrepeatcount++;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{

if ( !keysemaphor ) FormKeyNow( Key );
else keyrepeatcount++;
}
//---------------------------------------------------------------------------

void  TColorBarWd::FormKeyNow( WORD &Key )
{
String	t = "Log hoch ";
int		bn = 0;

if ( CommandKey == Key )
	CommandKey = 0;			// Funktion aus, wenn schon eingeschaltet

PCbd->LogFaktor = 0;
if (CommandKey == comLog) switch ( Key )
	{
	case simLog3:
	case comLog3:   PCbd->LogFaktor += 1;
	case simLog2:
	case comLog2:   PCbd->LogFaktor += 1;
	case simLog1:
	case comLog1:	PCbd->LogFaktor += 1;
					t += IntToStr((int)(PCbd->LogFaktor));
					StatusBar->Panels->Items[2]->Text = t;
					SetLog();
					FormPaint(NULL);
					Key = 0;
					CommandKey = 0;
					break;
	case simLog0:
	case comLog0:   PCbd->LogFaktor = 1;
					PCbd->ScalaLogPoint = 0;
					StatusBar->Panels->Items[2]->Text = "Linear";
					SetLog();
					FormPaint(NULL);
					Key = 0;
					CommandKey = 0;
					break;
	}

switch ( Key )
	{
	case comLoad:	OpenClick(NULL);
					break;
	case comQuit:	Hide();
					break;
	case comNeuZeichnen:
					MasterWd->NeuZeichnen();
					break;
	default:        CommandKey = Key;
					break;
	}
switch ( CommandKey )
	{
	case comZoom:	StatusBar->Panels->Items[1]->Text = "Zoom";				break;
	case comLog:	StatusBar->Panels->Items[1]->Text = "Log-Punkt";		break;
	case comShift:	StatusBar->Panels->Items[1]->Text = "Verschieben";		break;
	case comFarbtab:StatusBar->Panels->Items[1]->Text = "Tabulatoren";		break;
	default:		StatusBar->Panels->Items[1]->Text = "";					break;
	}
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::FormResize(TObject *Sender)
{

cbi->Picture->Bitmap->Width = cbi->Width;
cbi->Picture->Bitmap->Height = cbi->Height;
cbHist->Picture->Bitmap->Width = cbHist->Width;
cbHist->Picture->Bitmap->Height = cbHist->Height;
SetBar(0,cbFullSize);

PaintCb();
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::OpenClick(TObject *Sender)
{
int			iFileHandle;

OpenDialogPal->Title = "DeepChaosV2 - Colorbar : Lade Palettenfarben";
OpenDialogPal->InitialDir = DCWd->FarbPalettenPfEd->Text;
if (OpenDialogPal->Execute())
	{
	if (( iFileHandle = FileOpen(OpenDialogPal->FileName, fmOpenRead)) > 0 )
		{
		if ( ReadPal(iFileHandle))
			{
			StatusBar->Panels->Items[2]->Text = OpenDialogPal->FileName;
			//StrLCopy( Params->CTFile, OpenDialogPal->FileName.t_str(), 79 );
			}
		FileClose(iFileHandle);
		}
	}
BringToFront();
FormPaint(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::SaveAsClick(TObject *Sender)
{
int			iFileHandle,sel,pos;
bool		ok;
String		fn;

ok = false;
SaveDialogPal->Title = "DeepChaosV2 - Colorbar : Save As Palette";
SaveDialogPal->InitialDir = DCWd->BilderPfEd->Text;
if ( SaveDialogPal->Execute() )
	{
	pos = SaveDialogPal->FileName.Pos( "." );
	fn = SaveDialogPal->FileName.Delete( pos, 4 );
	if ( SaveDialogPal->FileName.Pos( ".bmp" ) > 2 ) sel = 1;
	if ( SaveDialogPal->FileName.Pos( ".jpg" ) > 2 ) sel = 2;
	if ( SaveDialogPal->FileName.Pos( ".pal" ) > 2 ) sel = 4;
	if ( SaveDialogPal->FileName.Pos( ".his" ) > 2 ) sel = 8;
	if ( SaveDialogPal->FileName.Pos( ".all" ) > 2 )
		{
		sel = 0x0ff;
		if (!DirectoryExists(fn))
			{
			if (!CreateDir(fn))
				throw Exception("Verzeichnis " + fn + "kann nicht erstellt werden");
			}
		fn += fn.SubString( fn.LastDelimiter("\\"),99 );
		}
	if ( sel & 1 )													//-----------------  bmp
		{
		cbi->Picture->Bitmap->SaveToFile( fn + ".bmp" );
		ok = true;
		}
	if ( sel & 8 )													//-----------------  his
		{
		cbHist->Picture->Bitmap->SaveToFile( fn + "_hist.bmp" );
		ok = true;
		}
	if ( sel & 2 )                       							//-------------   jpg
		{
		TJPEGImage *jp = new TJPEGImage();
		try
			{
			jp->Assign(cbi->Picture->Bitmap);
			jp->SaveToFile(fn + ".jpg");
			ok = true;
			}
		__finally
			{
			delete jp;
			}
		}
	if ( sel & 4 )                     									 //-------------  pal
		{
		iFileHandle = FileCreate( fn + ".pal" );
		SavePal(iFileHandle);
		FileClose(iFileHandle);
		StrLCopy(Params->CTFile,SaveDialogPal->FileName.t_str(), 79);
		ok = true;
		}
	if ( ok ) StatusBar->Panels->Items[2]->Text = SaveDialogPal->FileName;
	}
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::SaveClick(TObject *Sender)
{
String		fn;
TFileStream	*fs;

fn = Params->CTFile;
fs = new TFileStream( fn, fmOpenWrite );
fs->Write("DeepChaosColorTabellePal.Vers4  " ,32);
fs->Write(&(Params->ColorBarData), sizeof(Params->ColorBarData));
fs->Free();
StatusBar->Panels->Items[2]->Text = Params->CTFile;
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::KommandoMenuClick(TObject *Sender)
{
TMenuItem	*mi = (TMenuItem *)(Sender);
String		s;
WORD		c;
int			i,l;

c = NeuesKommando;
FormKeyNow( c );
s = mi->Hint;
l = s.Length();
i = 1;
while ( i <= l )
	{
	c = s[i];
	if ( c == L'@' ) break;
	FormKeyNow( c );
	i++;
	}
}
//---------------------------------------------------------------------------

void __fastcall TColorBarWd::zTbClick(TObject *Sender)
{

MasterWd->NeuZeichnen();
}
//---------------------------------------------------------------------------

