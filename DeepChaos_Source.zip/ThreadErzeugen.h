//---------------------------------------------------------------------------

#ifndef ThreadErzeugenH
#define ThreadErzeugenH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TTeilBildErzeugen : public TThread
{
private:

protected:
	void __fastcall Execute();

public:
	__fastcall TTeilBildErzeugen(bool CreateSuspended);

	TMainParams		*Params;
	long double 	*ergtab;
	MbmAnz			*Anzeige;
	int				TaskAnz,TaskNr;
	bool			*FM;

};
//---------------------------------------------------------------------------
#endif
