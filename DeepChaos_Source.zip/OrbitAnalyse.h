//---------------------------------------------------------------------------

#ifndef OrbitAnalyseH
#define OrbitAnalyseH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "LMDBaseEdit.hpp"
#include "LMDControl.hpp"
#include "LMDCustomBevelPanel.hpp"
#include "LMDCustomControl.hpp"
#include "LMDCustomEdit.hpp"
#include "LMDCustomExtSpinEdit.hpp"
#include "LMDCustomMaskEdit.hpp"
#include "LMDCustomPanel.hpp"
#include "LMDSpinEdit.hpp"
#include <Buttons.hpp>
#include "LMDCheckListBox.hpp"
#include "LMDCustomCheckListBox.hpp"
#include "LMDCustomImageListBox.hpp"
#include "LMDCustomListBox.hpp"
#include <ToolWin.hpp>
#include "LMDEdit.hpp"
#include "BildForm.h"

//---------------------------------------------------------------------------
class TOrbitWd : public TBildWd
{
__published:	// IDE-verwaltete Komponenten
	TPanel *OaPr;
	TCheckBox *SofortRechnenCb;
	TLMDSpinEdit *IterNrEd;
	TLabel *ZINLb;
	TLMDSpinEdit *RepeatJedeEd;
	TLabel *ZNJLb;
	TLMDSpinEdit *StartJedeEd;
	TLabel *SFJLb;
	TComboBox *TpQuelleCb;
	TLabel *VomLabel;
	TCheckBox *MitOrbitLinienCB;
	TCheckBox *MitHinterlegterMbmCB;
	TCheckBox *MinzFirstIterCB;
	TCheckBox *CenterOfOrbitCB;
	TLMDEdit *MinIterEd;
	TLabel *Milabel;
	TGroupBox *GroupBox2;
	TSpeedButton *ChangeViewLBtn;
	TLabel *Label73;
	TSpeedButton *ChangeViewRBtn;
	TTrackBar *ViewAngelTB;
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall OaPrMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall IterNrEdSpinBtnDownClick(TObject *Sender);
	void __fastcall ChangeViewLBtnClick(TObject *Sender);


private:	// Benutzer Deklarationen
	void	__fastcall GoBtnNow();
	void  	FirstAuswertung(double x, double y);
	void  	SingleAuswertung(double x, double y);
	void  	oadAuswertung( double x, double y, long treffer );

	bool				Keytodo;
	bool				SpeichernOadFile;



protected:
			Graphics::TBitmap	*PreImageBitmap;


public:		// Benutzer Deklarationen
			__fastcall TOrbitWd(TComponent* Owner);
	void 	__fastcall TpMouseMove( Word Key );
	void  	__fastcall FormKeyNow( WORD &Key );
	void 	__fastcall NeuZeichnen();
	void 	__fastcall NeuRechnen( bool );
	void 	__fastcall SpeichernOad( String Filebez);

	long double			vax;						// ViewAngle f�r die X-Achse  0...1
};
//---------------------------------------------------------------------------
extern PACKAGE TOrbitWd *OrbitWd;
//---------------------------------------------------------------------------
#endif
