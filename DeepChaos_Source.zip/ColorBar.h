//---------------------------------------------------------------------------

#ifndef ColorBarH
#define ColorBarH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
//---------------------------------------------------------------------------

#define	cbZoomIn		1
#define cbZoomOut		2
#define cbScroll		3
#define cbFullSize		4

#define simLog0			L'='
#define simLog1			L'!'
#define simLog2			L'"'
#define simLog3			L'�'

//---------------------------------------------------------------------------
class TBildWd;

class TColorBarWd : public TForm
{
__published:	// IDE-verwaltete Komponenten
	TPanel *cbiP;
	TPanel *HistP;
	TImage *cbi;
	TImage *cbHist;
	TOpenDialog *OpenDialogPal;
	TSaveDialog *SaveDialogPal;
	TScrollBar *csb;
	TStatusBar *StatusBar;
	TToolBar *CbWdTbar;
	TToolButton *ToolButton9;
	TToolButton *D_Tb;
	TToolButton *F_Tb;
	TToolButton *ToolButton10;
	TToolButton *zTb;
	TToolButton *ToolButton1;
	TMainMenu *MainMenu;
	TMenuItem *DateiMenu;
	TMenuItem *LogpunktMenu;
	TMenuItem *OpenMi;
	TMenuItem *Log0Mi;
	TMenuItem *Log1Mi;
	TMenuItem *Log2Mi;
	TMenuItem *Log3Mi;
	TMenuItem *LogschiebenMi;
	TMenuItem *SpeichernAlsMi;
	TMenuItem *CloseMi;
	TToolButton *ToolButton2;
	TMenuItem *Speichern1;
	void __fastcall cbiMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall Scroll(TObject *Sender, TScrollCode ScrollCode, int &ScrollPos);
	void __fastcall cbiMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall cbiMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall FormPaint(TObject *Sender);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall cbHistMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall OpenClick(TObject *Sender);
	void __fastcall SaveAsClick(TObject *Sender);
	void __fastcall SaveClick(TObject *Sender);
	void __fastcall CloseMiClick(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall	KommandoMenuClick(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall zTbClick(TObject *Sender);

public:
			virtual 	__fastcall 	TColorBarWd(TComponent* Owner);
            bool 				CloseNow;

			TMainParams			Pinit,*Params;
			TDColorBarData		*PCbd;
			TBildWd				*MasterWd;

//								ColorBar();
//								ColorBar(TImage *cbi);
			int					GetColor(const long double);
			int					GetColor32(const long double);
			int					GetColor32Scroll(const int);
//			int					GetColorNr(const int);
//			int					GetColorNrScroll(const long double);
			void				PaintCb();
			void				PaintFt();
//			void				Load( TDColorBarData *);
//			void				Save( TDColorBarData *);
			bool				ReadPal(int);
			void				SavePal(int);
			void  				ReadBlobPal(TStream *ps );
			void  				SaveBlobPal(TStream *ps );
			void				SetScala(const long double, const long double, const int);
			void				SetScala();
			bool				NewColor(int );
			void __fastcall 	SetBar( int, int );
			void				SetLog( const int, const int );
			void				SetLog();
			bool				DeleteColor(int );
			void				SelectColor(int );
			void				MoveColor(int, int );
			bool				MoveEndColor(int, int );
			int					Pos(int);
			long double  		PosZ(int);
			int                 GetTabNrScroll( long double akt );
			int                 GetTabNr( long double akt );
			void				ErzeugeCb();
			void __fastcall 	ParamPaint( TMainParams *p );
			void __fastcall 	HistPaint();



private:
			void  				FormKeyNow( WORD &Key );
			int                 GetLineX( int p );
			long double         GetTabValue( int tabnr );

			int					ColorTabelleMp[COLORTABS];	// Speichert Mousepos f�r jeden Farbtab
			int					ColorTabelleNcp[COLORTABS];	// Speichert NeueColorpos f�r jeden Farbtab
			TDColors			Colors[COLORSMAX];

			TCursor 			Save_Cursor;

			long double			ScalaLog;				  	// Faktor zum Schnittpunkt Linear- mit Expotionelkurve
			long double			ScalaFaktor;				// Umberechnung Messbereich nach Expotenzielbereich
			long double			ScalaStep;
			long double			cbistep;
			int					rotatepos;

			bool				TabGefasst,TabShift;
			int					TabSelect,TabEnd,TabShiftMode;
			int					TabPos,TabUp;

			int					csbMaxL;
			int                 plusminus;                  // (+1=)oberen oder (-1=)unteren Messbereich dehnen
			long double         ScalaExpo;                  // Exponent der Kurve
			long double         ScalaExpoV;                 // Verst�rkungsfaktor-Exponent der Kurve
			long double			gettabnrdivisor;			// aus den scalendaten berechnet, f�r GetTabNr Funktion

			Char				CommandKey;
			Char				BildKey;

			bool				keysemaphor;					// bei true arbeitet Keyfunktion
			int					keyrepeatcount;

			String				Sf;
			String				FileN;						// FileName
			bool 				warschon;
			int					IterGrenze;
};
//---------------------------------------------------------------------------
//extern PACKAGE TColorBarWd *ColorBarWd;
//---------------------------------------------------------------------------
#endif
