//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "ColorBar.h"
#include "OrbitAnalyse.h"
#include "ZeitReihe.h"
#include "DatenBankForm.h"
#include "BildForm.h"
#include "DCMAIN.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDbWd *DbWd;
//---------------------------------------------------------------------------
__fastcall TDbWd::TDbWd(TComponent* Owner)
	: TForm(Owner)
{

Sf = "Datenbank";
Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", Constraints->MinWidth );
Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", Constraints->MinHeight );
}
//---------------------------------------------------------------------------
void __fastcall TDbWd::FormClose(TObject *Sender, TCloseAction &Action)
{

DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
DCWd->SettingsFile->WriteInteger(Sf, "Width", Width );
DCWd->SettingsFile->WriteInteger(Sf, "Heigth", Height );
}
//---------------------------------------------------------------------------

