#ifndef GlobalH
#define GlobalH

#include "LMDBaseEdit.hpp"
#include "LMDControl.hpp"
#include "LMDCustomBevelPanel.hpp"
#include "LMDCustomControl.hpp"
#include "LMDCustomEdit.hpp"
#include "LMDCustomMaskEdit.hpp"
#include "LMDCustomPanel.hpp"
#include "LMDMaskEdit.hpp"
#include "LMDEdit.hpp"
#include "LMDComboBox.hpp"
#include "LMDCustomComboBox.hpp"
#include "LMDThemedComboBox.hpp"
#include "LMDCustomExtSpinEdit.hpp"
#include "LMDSpinEdit.hpp"

//------------------------------------------------------------------------------

#define A_MbmAnzMI				 0			// Auswertungsarten
#define A_MbmAnzMZ				 1
#define A_MbmAnzEW				 2
#define A_MbmAnzEO				 3
#define A_MbmAnzRB				 4
#define A_MbmAnzEU				 5
#define A_MbmAnzBB				 6  				// Aufsummierung der Orte
#define A_MbmAnzBBr				 7
#define A_MbmAnzOa				 8
#define A_MbmAnzCa               9

//------------------------------------------------------------------------------

#define	D_Mandelbrot			 1			// D_Nummern  Achtung: Tabelle nicht �ndern, nur verl�ngern !!!!
#define D_Apfelmaennchen		 2
#define	D_Bubblebrot			 3
#define	D_Lotusbrot				 4
#define	D_Runout				 5
#define D_xyKoordinaten			 6
#define D_Steigung				 7
#define D_Cyclebrot				 8
#define D_CenterOfOrbit			 9
#define D_SizeOfOrbit           10
#define D_Mindiff               11
#define D_Pabw                  12
#define D_Zmindiff              13
#define D_ZyclusIter            14
#define D_Zyclus                15
#define D_Grenzzyclus           16
#define D_MinSwingIn            17
#define D_SeekTops              18
#define D_Actiondetect          19
#define D_StartPointDiffergent  20
#define D_AereaOfOrbit          21
#define D_SternSeek             22
#define D_FirstIter             23
#define D_EWeg                  24
#define D_Grundwelle            25
#define D_SteigungPeriode       26
#define D_LastPeak			    27
#define D_MinCount			    28

#define	D_Max_Anzahl			29          // Bei Verl�ngerung Namen In Main.ccp eintragen !!!      H�chste Zahl +1 f�r "Unbenutzt 00"

//------------------------------------------------------------------------------

#define	opKoordinaten			0x00000001 	// Optionen : Ansicht mit....
#define	opAnsicht				0x00000002
#define	opSternenhimmel			0x00000004
#define	opJuliapunkt			0x00000008
#define	opTestpunkt				0x00000010
#define	opHinterlegteMBM		0x00000020
#define	opZoomrahmen			0x00000040
#define	opIterNrOrt				0x00000080
#define	opCenterOfOrbit			0x00000100
#define	opImaginaerpunkt		0x00000200
#define	opMinZ					0x00000400
#define	opOrbitLinien			0x00000800
#define	opBildCenter			0x00001000
#define opLinie					0x00002000
#define opReferenzpunkt			0x00004000
#define opLinienStart			0x00008000
#define opLinienEnd				0x00010000
#define opFirstIter				0x00020000
#define opBezierVector			0x00040000

//------------------------------------------------------------------------------

#define BildWdMaxNr			6			// 0=OrbitBild    1...4=MBM Bild   5=AnimationsEdit
#define AnimationsEditWd    5
#define AnzBigInts			18

//------------------------------------------------------------------------------

#define	COLORSMAX		0x4000		//16384
#define	COLORLOGSCALA	0
#define	COLORTABS		100

//------------------------------------------------------------------------------

#define	beAutomatik		0					// Blendeneinstellungen
#define	beAutoInside    1
#define	beAutoOutside   2
#define	beManuell       3
#define	bePipetteMin    4
#define	bePipetteMax    5
#define bePaletteFix    6
#define	beManuellWrap   7

//------------------------------------------------------------------------------

#define PointisOutside	123456				// Bildpixelpos. �berschritten

//------------------------------------------------------------------------------

#define	clBlau100		0x00ff0000
#define clRot100		0x000000ff
#define clGr�n100		0x0000ff00
#define clPurble100		0x00ff00ff
#define clYellow100		0x0000ffff
#define clAqua100		0x00ffff00

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#endif
