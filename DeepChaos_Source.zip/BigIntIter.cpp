#include <vcl.h>
#include <math.h>

#include "Global.h"
#include "bigint.h"
#include "StructDefs.h"
#include "Params.h"
//#include "Colorbar.h"

#include "BigIntIter.h"
#include "IterArt.h"

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

Iter_Asm	*Test_Asm;

bigint		axy;
bigint      ml[16];
bigint		ax0,ay0;

//---------------------------------------------------------------------------
IStatus::IStatus()
{
status = ok;
}
void IStatus::operator=(EStatus e)
{
switch (e)
	{
	case start:			status = ok;
						status |= inside;
						break;
	case ok:			status &= 0xff ^ ( fehler | outofRange ); 	status |= ok;		break;
	case fehler:        status |= fehler;												break;
	case inside:		status &= 0xff ^ ( outside ); 				status |= inside;	break;
	case outside:       status &= 0xff ^ ( inside ); 				status |= outside;	break;
	case outofRange:    status |= outofRange;											break;
	}
}
bool IStatus::operator==(EStatus e)
{
return status & e;
}
IStatus::operator int()
{
int		i;

i = status;
i = status>>2;
i &= 0x03;
return i;
//return (status<<2)&0x03;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Mandelbrot  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
																				Basisklasse & Mandelbrot-Auswertung
*/
BigIntIter::BigIntIter()
{
Darstellung = D_Mandelbrot;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
BigIntIter::~BigIntIter()
{

delete ia;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
void BigIntIter::SetParam( TMainParams* sp )
{

Pm = sp;

switch ( Pm->ErstArt )
	{
	case 1:		ia = new Iter_Asm;			break;
	case 2:		ia = new Iter_Float;		break;
	case 3:		ia = new Iter_Grafic;		break;
	case 4:		ia = new Iter_Grafic;		break;				   /* TODO : Wenn fertig: Grafik mit Bigint */
	default: 	ia = new Iter_Bigint;		break;
	}
ia->BII = this;
Test_Asm = (Iter_Asm*)ia;

ia->BigIntPraez = Pm->Rmode / 32;

PixelSizeMask = Pm->BildSize / ( Pm->BildSizeX * 2 );
PixelSizeMask.sizemask();
}
//---------------------------------------------------------------------------
IStatus BigIntIter::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );
ia->Vorbereiten();
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus BigIntIter::iterate_PreRun(int isteps)
{

if (isteps>0) iterstatus = BigIntIter::iterate_run(isteps);
return ( iterstatus );
}
//---------------------------------------------------------------------------
IStatus BigIntIter::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
	is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
    ia->Rechnen();
    if ( r > zmaxbi )
    	{
		zi = 0;   					// Mandelbrot Auswertung Outside
        za = r;
		za.sqrt();
        iterstatus = outside;
	    ex = ax;
		ey = ay;
        return iterstatus;
        }
    }
zi = itercount;								// Mandelbrot Auswertung Inside
za = r;
za.sqrt();
ex = ax;
ey = ay;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Apfelm�nnchen  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Standart Apfelm�nnchen-Auswertung

Ausgaben:
I:			Die erreichte Iterationsanzahl bis MaxI.
Z:          Z der letzten Iteration
x,y:        Position der letzten Iteration

*/
Apfelmaennchen::Apfelmaennchen() : BigIntIter()
{
Darstellung = D_Apfelmaennchen;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Apfelmaennchen::~Apfelmaennchen()
{

}
//---------------------------------------------------------------------------
IStatus Apfelmaennchen::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );
bmin = 20000000;

ex = ay;
ey = ax;
zi = itercount;
za = ax * ax;
za += ay * ay;
za.sqrt();
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Apfelmaennchen::iterate_run(int isteps)
{
int			is,iterbmin;
bigint		aaa,lastr;
bigint		grenze;

grenze = Pm->Toleranz;
if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
	if ( is < 1 )
		return iterstatus;
	}
else
	is = isteps;

lastr = iterbmin = 100000;
iterstatus = inside;
zi = NaN;
while ( is > 0 )
	{
	is--;
	itercount++;
	ia->Rechnen();
	if ( (itercount % iterbmin) == 0 ) {		// Nur die Minseite der H�llkurve testen
		aaa = lastr - r;
		aaa.abs();
		if ( aaa < grenze ) {
			zi = NaN;
			break;
			}
		lastr = r;
		}
	if (bmin > r) 								// N�chstes bmin suchen
		{
		if  (r > 0)
			{
			bmin = r;
			iterbmin = itercount;
			}
		else {
			zi = NaN;
			break;
			}
		}
	if ( r > zmaxbi )
		{
		iterstatus = outside;
		zi = itercount;				// Apfelm�nnchen Auswertung
/*
		ex = ay;
		ey = ax;
		za = r;
		za.sqrt();
		return iterstatus;
*/
		break;
		}
/*                                                                             	// Periodicity checking
	if ( ex.isinMask(ay, PixelSizeMask) && ey.isinMask(ax, PixelSizeMask) )
		{
		ex = ay;
		ey = ax;
		zi = isteps;				// Iteration ist innerhalb der M
		za = r;
		za.sqrt();
		return iterstatus;
		}
*/
	}
ex = ay;								// Wegen alter Version, die gedrehte Koordinaten hatte !!!!
ey = ax;
zi = itercount;
za = r;
za.sqrt();
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Bubblebrot  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
																				Auswertung der Iterationsnummer bei Z-Min
Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).
*/


Bubblebrot::Bubblebrot() : BigIntIter()
{
Darstellung = D_Bubblebrot;

bmin = 20000000;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Bubblebrot::~Bubblebrot()
{

}
//---------------------------------------------------------------------------
IStatus Bubblebrot::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich

bmin = 20000000;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Bubblebrot::iterate_run(int isteps)
{
int			is,ic;

zi = 0;
za = 0x0000;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
ic = itercount;
while ( is > 0 )
	{
    is--;
    itercount++;

	ia->Rechnen();
    if (bmin > r)
    	{
        if  (r > 0)
        	{
	        bmin = r;
			ex = ay;
			ey = ax;
			zi = itercount;
	        za = r;
			za.sqrt();
            }
        }
    else
	    if ( r > zmaxbi )
    		{
        	iterstatus = outside;
	        return iterstatus;
    	    }
    }
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  MinCount  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
																				Auswertung wieviele male ein Min-Z bis zum Letzten auftritt
Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).
*/


MinCount::MinCount() : BigIntIter()
{
Darstellung = D_MinCount;

bmin = 20000000;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
MinCount::~MinCount()
{

}
//---------------------------------------------------------------------------
IStatus MinCount::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich

isum = 0;
bmin = 20000000;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus MinCount::iterate_run(int isteps)
{
int			is,ic;

zi = 0;
za = 0x0000;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
		return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
ic = itercount;
while ( is > 0 )
	{
    is--;
	itercount++;

	ia->Rechnen();
    if (bmin > r)
		{
        if  (r > 0)
			{
	        bmin = r;
			ex = ay;
			ey = ax;
			isum += itercount;
			zi += 1;
			}
		}
	else
		if ( r > zmaxbi )
			{
			iterstatus = outside;
			}
	}
za = (zi == 0)? 0 : isum / zi;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Cyclebrot  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es soll ermittelt werden ob ein Diagonalsprung vorliegt, und dann wieviele folgende Iter am Cycle stattfinden. Bei Wiederholung, die l�ngste Folge.

ex,ey		Ort des letzten Sprunges

*/


Cyclebrot::Cyclebrot() : BigIntIter()
{
Darstellung = D_Cyclebrot;

bmin = 20000000;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Cyclebrot::~Cyclebrot()
{

}
//---------------------------------------------------------------------------
IStatus Cyclebrot::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;

zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi und null5 zum Vergleich
messradius = ModeZs;    					// Grenzwert ( radius)
messradius *= messradius;

bmin = 20000000;
return iterstatus;
}
//---------------------------------------------------------------------------
long double Grad( long double xw, long double yw )
{
long double	hw,s,wi;

			hw = sqrtl( (xw*xw)+(yw*yw) );
			if ( hw == 0 )
				s = 0.0;
			else
				s = yw / hw;
			wi = asin( s );
			if ( xw < 0 )
				wi = M_PI - wi;
			else
				if ( yw < 0 )
					wi = M_PI + M_PI + wi;
			if ( wi > ( M_PI + M_PI ) )
				wi = 0;
			return wi * 57.295779513082320876798154814105;				// 2 PI == 360�
}
//---------------------------------------------------------------------------
IStatus Cyclebrot::iterate_run(int isteps)
{
int			is,rz,rw,opt;
bigint		rtoleranz,rc;
long double	xw,yw,rb1,rb2,rb,wtoleranz;

rtoleranz = Pm->Toleranz;
wtoleranz = Pm->Wtoleranz;
opt = Pm->Optionen;
#define L�ngste 0
#define WieOft 1
zi = 0;
za = 0x0000;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
	if ( is < 1 )
		return iterstatus;
	}
else
	is = isteps;

ex.zero();
ey.zero();
iterstatus = inside;
rz = 0; 									// Z�hlt die L�nge einer Folge
rw = 0;										// Z�hlt die Anzahl von Folgen
while ( is > 0 )
	{
    is--;
    itercount++;
	ia->Rechnen();
	rc = r;
	rc -= messradius;
	rc.abs();   									// Abstand zum Messradius
	if (rc < rtoleranz)
		{
		rz++;
		if ( rz == 1 )
			{
			rb1 = Grad( ay, ax );						// x,y ist verdreht wegen alter Version
			za = rc;
			}
		if ( rz == 2 )
			{
			rb2 = Grad( ay, ax );						// x,y ist verdreht wegen alter Version
			rb = rb1-rb2;
			rb = abs( rb);
			rb -= 180;
			rb = abs(rb);
			if ( rb > wtoleranz ) 							// wenn nicht fast ein Diagonalsprung
				{
				rz = 1;
				rb1 = rb2;
				}
			else
				{
				ex = ay;
				ey = ax;
				}
			}
		if ((opt == L�ngste) & (zi < rz))   				 // Ist neues Ergebnis gr��er?   L�ngster Verbleib im Toleranzbereich
			{
			zi = rz;
			}
		if ((opt == WieOft) & (rz == 2))
			{
			rw++;
			zi = rw;
			rz = 0;
			}
		}
	else
		{
		rz = 0;
		}
	if ( r > zmaxbi )
		{
		iterstatus = outside;
		return iterstatus;
		}
	}
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Runout  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Nachdem die Iterationsfolge Max-Radius �berschritten hat, wird das lezte Minimum von hinten her
gesucht.

Ausgaben:
I:			Die Anzahl von Iterationen zwischen letzten Min und Max-Radius
Z:			der Wert vom letzten Min.
x,y:		Der Ort vom letzten Min.

Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).
*/


Runout::Runout() : BigIntIter()
{
Darstellung = D_Runout;

bmin = 20000000;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Runout::~Runout()
{

}
//---------------------------------------------------------------------------
IStatus Runout::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich
zi = 0;
za = 0x0000;
bminz = 20000000;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Runout::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
	if ( is < 1 )
		return iterstatus;
	}
else
	is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
	is--;
	itercount++;

	ia->Rechnen();
//    r.sqrtl();     dauert zu lange
	if (bminz > r)   				// Test f�r "runout"
		{
		if  (r > 0)
			{
			ex = ay;
			ey = ax;
			zi = itercount;
			za = r;
			}
		}
	bminz = r;
	if ( r > zmaxbi )
			{
			iterstatus = outside;
			zi = itercount - zi;					// Ausgabe Iterationsanzahl
			za.sqrt();
			return iterstatus;
			}
	}
zi = 0;
za = 0x0000;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  LastPeak  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es wird der letzte Wert gesucht, der am gr��ten ist, aber den Grenzradius nicht �berschreitet.

Ausgaben:
I:			Die Anzahl von Iterationen zwischen letzten Max-Wert und letzter Iteration
Z:			der Wert vom letzten max.
x,y:		Der Ort vom letzten max.

Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).
*/


LastPeak::LastPeak() : BigIntIter()
{
Darstellung = D_LastPeak;

bmin = 20000000;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
LastPeak::~LastPeak()
{

}
//---------------------------------------------------------------------------
IStatus LastPeak::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich
zi = 0;
za = 0x0000;
bminz = 0x0000;
bmax = 0x0000;
bmaxi = 0;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus LastPeak::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
	if ( is < 1 )
		return iterstatus;
	}
else
	is = isteps;

iterstatus = inside;
iterstatus = outofRange;
while ( is > 0 )
	{
	is--;
	itercount++;
	ia->Rechnen();
//    r.sqrtl();     dauert zu lange
	if (bminz > r)   				// Test f�r "runout"
		{
		if  (r > 0)
			{
			zi = itercount;
			if ( bminz > bmax )
				{
				ex = ay;
				ey = ax;
				za = bminz;
				bmax = bminz;
				bmaxi = itercount;
				iterstatus = ok;
				}
			}
		}
	bminz = r;
	if ( r > zmaxbi )
			{
			iterstatus = outside;
			zi = itercount - bmaxi;					// Ausgabe Iterationsanzahl
			if ( zi < Pm->EmodeNr ) 					// ist Messgrenze erreicht?
				{
				iterstatus = outofRange;                //...nein
				zi = 0;
				za = 0x0000;
				ex = 0x0000;
				ey = 0x0000;
				}
			else
				za.sqrt();
			return iterstatus;
			}
	}
iterstatus = outofRange;
zi = 0;
za = 0x0000;
ex = 0x0000;
ey = 0x0000;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Lotusbrot  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Der Z-Bereich wird in verschiedene Stufen eingeteilt. F�r jede Stufe wird gez�hlt wie oft
ein Iterationsergebnis hineinf�llt.

Ausgaben:
I:			Wieviele Stufen mindestens einmal getroffen wurden.
Z:          Z desjenigen Levels, der am h�ufigsten getroffen wurde
x,y:        nix,nix

*/

Lotusbrot::Lotusbrot() : BigIntIter()
{
Darstellung = D_Lotusbrot;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Lotusbrot::~Lotusbrot()
{
}
//---------------------------------------------------------------------------
IStatus Lotusbrot::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{
int		i;

itercount = 0;
iterstatus = start;

Raster = ModeNr;
if ( Raster > 16000 ) Raster = 16000;
if ( Raster < 2 ) Raster = 2;
RasterSize = zmaxi / ( long double )Raster;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

for ( i=0; i<Raster; i++)
	levels[i] = 0;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Lotusbrot::iterate_run(int isteps)
{
int			is,ri,rs;
long double	rd;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;

	ia->Rechnen();
	rd = sqrtl((long double)r);
    rd /= RasterSize;

    if ( rd < Raster ) ri = rd; else ri = Raster-1;
    levels[ri]++;

    if ( r > zmaxbi )
    	{
        iterstatus = outside;
	    break;
		}
    }
rd = 0;
ri = 0;
rs = 0;

for ( is=0; is<Raster; is++ )
	{
	if ( levels[is] > 0 )
    	{
    	ri++;
        }
    if ( levels[is] > rs )
    	{
    	rs = levels[is];
        rd = is;
        }
    }

ex = 0x0000;
ey = 0x0000;
zi = ri;
rd *= RasterSize; 			// Berechnung von za weil es kein (Long Double) -> Bigint gibt !!!
rd *= 30000;
ri = rd;
za = ri;
za /= 30000;				// za gibt den Z-Wert an der am h�ufigsten auftritt ( KonvergationsLevel )
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Center of Orbit  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*


Ausgaben:
I:
Z:			R von Centerpoint
x,y:        Position Center of Orbit

*/
CenterOfOrbit::CenterOfOrbit() : BigIntIter()
{
Darstellung = D_CenterOfOrbit;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
CenterOfOrbit::~CenterOfOrbit()
{
}
//---------------------------------------------------------------------------
IStatus CenterOfOrbit::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

xc.zero();
yc.zero();
xct.zero();
yct.zero();
bmin = 999999;

bmin_nr = 0;
iscan = 1;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus CenterOfOrbit::iterate_run(int isteps)
{
long		is;
bigint      x2,y2;                  // f�r Berechnung |z| of Center

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;

	ia->Rechnen();
    if ( bmin > r )
    //	if ( r > 0 )
        	{         						// Periode emitteln ( Bubblebrotmethode )
            bmin = r;
            bmin_nr = itercount;
            }
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
	    ex = xc;
		ex /= iscan;					// Center
		ey = yc;
		ey /= iscan;
        zi = itercount;
        x2 = ex;                        // Berechnung |z| von Center
        x2 *= x2;
        y2 = ey;
        y2 *= y2;
        x2 += y2;
		x2.sqrt();
        za = x2;
		return iterstatus;
        }
    xct += ax;
    yct += ay;
    if (( itercount % bmin_nr ) == 0 )		// Wenn volle Periode da ist, addieren
    	{
	    xc += xct;
    	yc += yct;
        xct.zero();
        yct.zero();
        iscan = itercount;
        }
    }
ex = xc;
ex /= iscan;
ey = yc;
ey /= iscan;
zi = itercount;
        x2 = ex;                        // Berechnung |z| von Center
        x2 *= x2;
        y2 = ey;
        y2 *= y2;
        x2 += y2;
		x2.sqrt();
        za = x2;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Size of Orbit  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*


Ausgaben:
I:			Itercount
Z:			Size of Orbit
x,y:

*/
SizeOfOrbit::SizeOfOrbit() : BigIntIter()
{
Darstellung = D_SizeOfOrbit;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
SizeOfOrbit::~SizeOfOrbit()
{
}
//---------------------------------------------------------------------------
IStatus SizeOfOrbit::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

xmin = 999999;
ymin = 999999;
xmax = -999999;
ymax = -999999;

bmin_nr = 0;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus SizeOfOrbit::iterate_run(int isteps)
{
long		is;
long double	xd,yd;					// f�r Berechnung size

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;

	ia->Rechnen();
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
        za = ( xmax - xmin ) * ( ymax - ymin );		// Size
		return iterstatus;
        }
    xd = ax;
    yd = ay;
    if ( xmin > xd ) xmin = xd;
    if ( xmax < xd ) xmax = xd;
    if ( ymin > yd ) ymin = yd;
    if ( ymax < yd ) ymax = yd;
    }
za = ( xmax - xmin ) * ( ymax - ymin );			// Size
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Mindiff  ###########################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Auswertung der Iteranzahl-Differenz bei Z-Min und Z-Min+1
Ansonsten wie Bubblebrot

Ausgaben:
I:
Z:
x,y:

*/

Mindiff::Mindiff() : BigIntIter()
{
Darstellung = D_Mindiff;

}
//---------------------------------------------------------------------------
IStatus Mindiff::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

//BigIntIter::iterate_start( aix, aiy, cix, ciy, imaxi, zmaxi);
ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmax = zmaxi;

bmin[0] = 20000;
imin[0] = -1;
bmin[1] = 20000;
imin[1] = -1;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Mindiff::iterate_run(int isteps)
{
int			is;
bigint		az;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    itercount++;

    ax *= ay;
    ax.mal2();
    ax += cx;

    ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    if ( itercount > 201 )
    	{
        is--;
	    az = ax2;
    	az += ay2;
		az.sqrt();
	    if ( (bmin[0] > az ) && ( az > 0 ) )
    		{
	        bmin[0] = az;
    	    imin[0] = itercount;
        	imin[1] = itercount;
	        }
    	else if ( (bmin[1] > az ) && ( az > 0 ) && (itercount > imin[0]) )
    		{
	        bmin[1] = az;
    	    imin[1] = itercount;
        	}
        }
    if ( ((long double)ax > zmax) || ((long double)ay > zmax) )
    	{
        iterstatus = outside;
        is = 0;
        }
    }
zi = imin[1] - imin[0];
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*


Ausgaben:
I:
Z:
x,y:

*/


Pabw::Pabw() : BigIntIter()
{
Darstellung = D_Pabw;
}
//---------------------------------------------------------------------------
IStatus Pabw::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmax = zmaxi;

bmin[0] = 20000;
imin[0] = -1;
bmin[1] = 20000;
imin[1] = -1;
bmin[2] = 20000;
imin[2] = -1;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Pabw::iterate_run(int isteps)
{
int			is;
long double	r;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;

    ax *= ay;
    ax.mal2();
    ax += cx;

    ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += (long double)ay2;
    r = sqrtl(r);
    if ( r > 0 )
    	{
	    if ( (bmin[0] > r) )
    		{
        	bmin[0] = r;
	        imin[0] = itercount;
    	    imin[1] = itercount;
        	imin[2] = itercount;
	        }
    	else if ( (bmin[1] > r) && (itercount > imin[0]) )
    		{
	        bmin[1] = r;
    	    imin[1] = itercount;
        	imin[2] = itercount;
	        }
    	else if ( (bmin[2] > r) && (itercount > imin[1]) )
		   	{
        	bmin[2] = r;
	        imin[2] = itercount;
    	    }
        }
    if ( r > zmax )
    	{
        iterstatus = outside;
        is = 0;
        }
    }
zi = (imin[1] - imin[0]) - (imin[2] - imin[1]);
//z = (imin[1] - imin[0]);
//if ( z !=(imin[2] - imin[1]) )	z = 0;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
// ZminDiff #########################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Auswertung der Differnz bei Z-Min und Z-Min+1


Ausgaben:
I:
Z:
x,y:

*/


Zmindiff::Zmindiff() : BigIntIter()
{
Darstellung = D_Zmindiff;

}
//---------------------------------------------------------------------------
IStatus Zmindiff::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

//BigIntIter::iterate_start( aix, aiy, cix, ciy, imaxi, zmaxi);
ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmax = zmaxi;

bmin[0] = 20000;
imin[0] = -1;
bmin[1] = 20000;
imin[1] = -1;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Zmindiff::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;

    ax *= ay;
    ax.mal2();
    ax += cx;

    ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += ay2;
	r.sqrt();
    if ( (bmin[0] > r) && (r > 0) )
    	{
        bmin[0] = r;
        imin[0] = itercount;
        imin[1] = itercount;
        }
    else if ( (bmin[1] > r) && (r > 0) && (itercount > imin[0]) )
    	{
        bmin[1] = r;
        imin[1] = itercount;
        }
    if ( r > zmax )
    	{
        iterstatus = outside;
        is = 0;
        }
    }
za = bmin[1] - bmin[0];
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
// ZyclusIter ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

Ausgaben:
I:			Iterationen zwischen 2 Minima --- soll Periode sein
Z:
x,y:

*/
ZyclusIter::ZyclusIter() : BigIntIter()
{
Darstellung = D_ZyclusIter;

}
//---------------------------------------------------------------------------
IStatus ZyclusIter::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

//BigIntIter::iterate_start( aix, aiy, cix, ciy, imaxi, zmaxi);
ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmax = zmaxi;
zi = 0;

bmin[0] = 20000;
imin[0] = -1;
bmin[1] = 20000;
imin[1] = -1;
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus ZyclusIter::iterate_run(int isteps)
{
#define ZTMAXITER	200000
#define DSTABSIZE	100
#define	EPSILON		8 //1000000

int			is,ri;
long double	axd,ayd,ax2d,ay2d,cxd,cyd,r;

axd = (long double)ax;
ayd = (long double)ay;
ax2d = (long double)ax2;
ay2d = (long double)ay2;
cxd = (long double)cx;
cyd = (long double)cy;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

while ( is > 0 )
	{
    itercount++;

    axd *= ayd;
    axd *=2;
    axd += cxd;

    ayd  = ay2d;
    ayd -= ax2d;
    ayd += cyd;

	ax2d  = axd;
    ax2d *= axd;
	ay2d  = ayd;
    ay2d *= ayd;

	r = ax2d;
	r += ay2d;
	r = sqrtl(r);
    if ( itercount > 200000 )
    	{
        is--;
        ri = r * 10000; 						// Epsilon
	    if ( (bmin[0] > ri) && (ri > 0) )
    		{
        	bmin[0] = ri;
	        imin[0] = itercount;
    	    imin[1] = itercount;
        	}
	    else if ( (bmin[1] > ri) && (ri > 0) && (itercount > imin[0]) )
    		{
        	bmin[1] = ri;
	        imin[1] = itercount;
    	    }
        }
    if ( r > zmax )
    	{
        iterstatus = outside;
        zi = 0;
        return iterstatus;
        }
	}
zi = imin[1] - imin[0];
iterstatus = inside;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

Ausgaben:
I:
Z:
x,y:

*/
Zyclus::Zyclus() : BigIntIter()
{
Darstellung = D_Zyclus;

}
//---------------------------------------------------------------------------
IStatus Zyclus::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

//BigIntIter::iterate_start( aix, aiy, cix, ciy, imaxi, zmaxi);
ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmax = zmaxi;
zi = 0;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Zyclus::iterate_run(int isteps)
{
int			i,is,zti,zh;
bool		isok;
long double	axd,ayd,ax2d,ay2d,cxd,cyd,ztd;
byte	 	zt[2000];

axd = (long double)ax;
ayd = (long double)ay;
ax2d = (long double)ax2;
ay2d = (long double)ay2;
cxd = (long double)cx;
cyd = (long double)cy;

#define ZTMAXITER	200000

if ( iterstatus == outside )
	return iterstatus;
for ( zti=0; zti < 2000; zti++) zt[zti] = 0;
i = 0;
isok = false;
while ( i < ZTMAXITER )
	{
    i++;

    axd *= ayd;
    axd *=2;
    axd += cxd;

    ayd  = ay2d;
    ayd -= ax2d;
    ayd += cyd;

	ax2d  = axd;
    ax2d *= axd;
	ay2d  = ayd;
    ay2d *= ayd;

	ztd = ax2d;
	ztd += ay2d;
	ztd = sqrtl(ztd);
    if ( ztd > 2 )
    	{
        iterstatus = outside;
        zi = 0;
        return iterstatus;
        }
    zti = ztd * 1000;
    if ( zt[zti] == 10 )
    	{
        zi = 0;
        iterstatus = inside;
		isok = true;
        for ( zh=0; zh < 2000; zh++)
        	if ( zt[zh] > 0 )
	        	if ( zt[zh] != 10 )
    	        	{
					for ( zti=0; zti < 2000; zti++) zt[zti] = 0;
					isok = false;
                    is = i + ( i / 5 ) + 3;
                    if ( is > ZTMAXITER )
                    	is = i + 1000;
                    while ( i < is )
						{
						i++;

					    axd *= ayd;
					    axd *=2;
					    axd += cxd;

					    ayd  = ay2d;
					    ayd -= ax2d;
					    ayd += cyd;

						ax2d  = axd;
					    ax2d *= axd;
						ay2d  = ayd;
					    ay2d *= ayd;

						ztd = ax2d;
						ztd += ay2d;
						ztd = sqrtl(ztd);
					    if ( ztd > 2 )
					    	{
					        iterstatus = outside;
					        zi = 0;
					        return iterstatus;
					        }
                    	}
                    break;
	                }
                else
                	{
                	zi += 1;
                    }
		if ( ok ) break;
        }
    else
	    zt[zti]++;
	}
zi = i;						// Maxiter Auswertung
return iterstatus;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Grenzzyclus  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).

Ausgaben:
I:
Z:
x,y:

*/


Grenzzyclus::Grenzzyclus( int mi) : BigIntIter()
{
Darstellung = D_Grenzzyclus;

spur = new long[mi+1];
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Grenzzyclus::~Grenzzyclus()
{

delete[] spur;
}
//---------------------------------------------------------------------------
IStatus Grenzzyclus::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;
LastIterRy = ay;
LastIterRx = ax;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich

thisspur = 0x001;
spur[0] = thisspur;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Grenzzyclus::iterate_run(int isteps)
{
int			is,gzc,probe;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )                // iteration scannen
	{
    is--;
    itercount++;

    ax *= ay;
    ax.mal2();
    ax += cx;

    ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += ay2;
    thisspur <<= 1;                             // Spur erstellen
    thisspur |= ( LastIterRx < ax );
    thisspur <<= 1;
    thisspur |= ( LastIterRy < ay );
    thisspur <<= 1;
    thisspur |= ( LastIterRz < r );
/*
    thisspur <<= 1;
    thisspur |= ax.isNeg();
    thisspur <<= 1;
    thisspur |= ay.isNeg();
*/
    spur[itercount] = thisspur;
    LastIterRx = ax;
    LastIterRy = ay;
    LastIterRy = r;
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
        zi = 0;
        return iterstatus;
        }
    }

#define STARTSCAN 100

probe = spur[STARTSCAN];
gzc = 0;
for ( is=STARTSCAN; is<itercount; is++  )            // Scan auswerten
    {
    if ( probe == spur[is] )
       gzc++;
    }

if ( gzc > 0 )
   zi = ( itercount - STARTSCAN ) / gzc;
else
   zi = 0;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  MinSwingIn  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Damit kann beobachtet werden wie sich das kleinste Z w�hrend einer Iteration einpendelt bis es
konvergiert ist.

Ausgaben:
I:
Z:
x,y:


Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).
*/


//MinSwingIn::MinSwingIn( int mi) : BigIntIter()
MinSwingIn::MinSwingIn( ) : BigIntIter()
{
Darstellung = D_MinSwingIn;

//spur = new long[mi+1];
spur = new long[1010+1];
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
MinSwingIn::~MinSwingIn()
{

delete[] spur;
}
//---------------------------------------------------------------------------
IStatus MinSwingIn::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ax2  = ax;
ax2 *= ax;
ay2  = ay;
ay2 *= ay;
LastIterR3 = LastIterR2 = ax2 + ay2;

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich

thisspur = 0x001;
spur[0] = thisspur;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus MinSwingIn::iterate_run(int isteps)
{
int			is,gzc,probe,mlpin,mlc,mlpout,prm;

mlpin = 0;
if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )                // iteration scannen
	{
    is--;
    itercount++;

    ax *= ay;
    ax.mal2();
    ax += cx;

    ay  = ay2;
    ay -= ax2;
    ay += cy;

	ax2  = ax;
    ax2 *= ax;
	ay2  = ay;
    ay2 *= ay;
    r = ax2;
    r += ay2;
    mlc = 0;
    mlpout = mlpin;

    while ( r < ml[mlpout] )                 // Minimuml�nge z�hlen
          {
          mlc++;
          if ( mlpout > 0 )
             mlpout--;
          else
              mlpout = 14;
          if ( mlpout == mlpin )
             break;
          }

    if ( mlpin < 14 )                        // Neue Iteration eintragen
       mlpin++;
    else
        mlpin = 0;
    ml[mlpin] = r;

    thisspur <<= 1;                             // Spur erstellen
    thisspur |= ( LastIterR2 < r );
    spur[itercount] = ( thisspur & 0xFFFFFFF0 ) | mlc;
    LastIterR2 = r;

    if ( r > zmaxbi )							// Ende wenn Iteration divergiert
    	{
        iterstatus = outside;
        zi = 0;
        return iterstatus;
        }
    }

#define STARTSCAN 50

prm = 0;
for ( is=STARTSCAN; is<itercount && is<(STARTSCAN+200); is++  )            // L�ngstes Minimum in Spur suchen
    {
    gzc = spur[is] & 0x00F;
    if ( prm < gzc )
       {
       prm = gzc;
       probe = spur[is];
       }
    }
gzc = 0;
for ( is=STARTSCAN; is<itercount; is++  )            // Scan auswerten
    {
    if ( probe == spur[is] )
       gzc++;
    }

if ( gzc > 0 )
   zi = ( itercount - STARTSCAN ) / gzc;			// zi = Anzahl wiederholungen der Perioden ?
else
   zi = 0;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  SeekTops  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Standart Apfelm�nnchen-Auswertung---> Versuch statt Betr(z) f�r Abbruch Betr(i) und Betr(r) vergleichen

Ausgaben:
I:			Die erreichte Iterationsanzahl bis MaxI.
Z:          Z der letzten Iteration
x,y:        Position der letzten Iteration

*/
SeekTops::SeekTops() : BigIntIter()
{
Darstellung = D_SeekTops;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
SeekTops::~SeekTops()
{

}
//---------------------------------------------------------------------------
IStatus SeekTops::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );
bmin = 20000000;

ex = ay;
ey = ax;
zi = itercount;
za = ax * ax;
za += ay * ay;
za.sqrt();
return iterstatus;
}
//---------------------------------------------------------------------------
IStatus SeekTops::iterate_run(int isteps)
{
int			is,iterbmin;
bigint		aaa,lastr;
bigint		grenze;
bigint		axlast,aylast;

axlast = aylast = bmin;
grenze = Pm->Toleranz;
if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
	if ( is < 1 )
		return iterstatus;
	}
else
	is = isteps;

lastr = iterbmin = 100000;
iterstatus = inside;
zi = NaN;
while ( is > 0 )
	{
	is--;
	itercount++;
	ia->Rechnen();
	if ( (itercount % iterbmin) == 0 ) {		// Nur die Minseite der H�llkurve testen
		aaa = lastr - r;
		aaa.abs();
		if ( aaa < grenze ) {
			zi = NaN;
			break;
			}
		lastr = r;
		}
	r = ( axlast - ax ) + ( aylast - ay );
	r.abs();
	if (bmin > r) 								// N�chstes bmin suchen
		{
		if  (r > 0)
			{
			bmin = r;
			axlast = ax;
			aylast = ay;
			iterbmin = itercount;
			}
		else {
			zi = NaN;
			break;
			}
		}
	if ( r > zmaxbi )
		{
		iterstatus = outside;
		zi = itercount;				// Apfelm�nnchen Auswertung
		break;
		}
	}
ex = ay;								// Wegen alter Version, die gedrehte Koordinaten hatte !!!!
ey = ax;
zi = itercount;
za = r;
za.sqrt();
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  StartPointDiffergent  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Sucht den Startpunkt einer langen Iterationsfolge, die langsam divergiert.
Diese beginnt nahe dem Radius 0,5.
Sie ist gekennzeichnet durch den Einsprungpunkt diagonal gegen�ber.
Kann im Iterationsverlauf mehrmals vorkommen.

Ausgaben:
I:          Die Nummer dex letzten Aussprungs
Z:       	Die Anzahl der Einspr�nge bis MaxI.
x,y:		Der Ort des letzten Aussprungs

*/
StartPointDiffergent::StartPointDiffergent() : BigIntIter()
{
Darstellung = D_StartPointDiffergent;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
StartPointDiffergent::~StartPointDiffergent()
{

}
//---------------------------------------------------------------------------
IStatus StartPointDiffergent::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

xf = 0;
yf = 0;
r05 = ( 0.5 * 0.5 );
ra = 0.1;						// Radius 0.5 abstand maximal
fb = ModeZs;					// Fangbereich der Diagonaldifferenz

zi = 0;
za.zero();
ex = 20000;				  // Wenn Auswertung kein Ergebnis bringt,
ey = 20000;                 // dann Ergebnisort ausserhalb der Messfl�che !

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus StartPointDiffergent::iterate_run(int isteps)
{
int				is,it,im;
//long double		rt,xt,yt,axf,ayf;
long double		rt,ax1,ax2,ay1,ay2;
bigint			abst;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

im = 0;
iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
    ia->Rechnen();

    abst = r;
    abst -= r05;
    rt = abst;
    rt = fabsl(rt);
    if ( rt < fb )
    	{
        if ( ( itercount - im ) == 1 )		// diese Iteration als erste nahe 0,5
        	{
           	ax1 = ax;
            ay1 = ay;
        	}
        else if ( ( itercount - im ) == 2 )		// n�chste iteration wieder nahe an 0,5
        	{
           	ax2 = ax;
            ay2 = ay;
            ax2 -= ax1;
            ay2 -= ay1;
            ax2 *= ax2;
            ay2 *= ay2;
            rt = ax2 + ay2;
            rt = sqrtl( rt );
            rt -= 1.0;
		    rt = fabsl(rt);
            if ( rt < ( fb + fb ))				// ist Abstand gleich 1.0 +- Fanggereich ?
            	{
			    ax1 = ax;
				ay1 = ay;
                }
            else
	            im = itercount;					// ansonsten alles von vorne
        	}
        else if ( ( itercount - im ) < 20 )		// n�chste 20 iterationen immerwieder nahe an der letzten
        	{
           	ax2 = ax;
            ay2 = ay;
            ax2 -= ax1;
            ay2 -= ay1;
            ax2 *= ax2;
            ay2 *= ay2;
            rt = ax2 + ay2;
            rt = sqrtl( rt );
		    rt = fabsl(rt);
            if ( rt < ( fb + fb ))				// ist Abstand +- Fanggereich ?
            	{
			    ax1 = ax;
				ay1 = ay;
                }
            else
	            im = itercount;					// ansonsten alles von vorne
        	}
        else if ( ( itercount - im ) == 20 )   	// Letzte iteration wieder nahe an der letzten
        	{
           	ax2 = ax;
            ay2 = ay;
            ax2 -= ax1;
            ay2 -= ay1;
            ax2 *= ax2;
            ay2 *= ay2;
            rt = ax2 + ay2;
            rt = sqrtl( rt );
		    rt = fabsl(rt);
            if ( rt < ( fb + fb ))				// ist Abstand +- Fanggereich ?
            	{
			    ex = ax;
				ey = ay;
                zi = itercount;
				za += 1;
                }
            else
	            im = itercount;					// ansonsten alles von vorne
        	}
        }
    else
	    im = itercount;
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		return iterstatus;
        }
    }
return iterstatus;

/*----------------------------------Version 1
    if (( r - r05 ) < (bigint)0.02 )		// Einsprungpunkt nahe Radius 0,5
    	{
        if (( xf + ax ) < (bigint)0.1 )			// ist einprungpunkt diagonal ?
			if (( yf + ay ) < (bigint)0.1 )
            	{
			    ex = ax;
				ey = ay;
                zi++;
                }
        }
*/
/*-----------------------------------Version 2
    axf = ax;
    ayf = ay;
	rt = r;
    rt -= r05;
    rt = fabsl(rt);
    if ( rt < ra )		// Einsprungpunkt nahe Radius 0,5
    	{
        xt = ( xf + axf );
        yt = ( yf + ayf );
        xt = fabsl(xt);
        yt = fabsl(yt);
        if ( xt < fb )			// ist einprungpunkt diagonal ?
			if ( yt < fb )
            	{
			    ex = ax;
				ey = ay;
                zi++;
                if ( zi > 1 )
                	{
                    if (( itercount - it ) > im )		// l�ngsten Verlauf suchen
                    	im = itercount - it;
                    }
                it = itercount;
                }
        }
    xf = axf;
    yf = ayf;

    if ( r > zmaxbi )
    	{
        if ( zi >= 1 )
           	{
            if (( itercount - it ) > im )		// einzigen oder letzten Verlauf speichern
               	im = itercount - it;
            }
        za = (bigint)im;
        iterstatus = outside;
		return iterstatus;
        }
    }
zi = 0;
za.zero();
return iterstatus;
*/
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Actiondetect  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es soll ermittelt werden, ob ein Verlauf einen diagonalsprung aufweist

Ausgaben:
I:              Iternummer f�r Z
Z:				Sprungdiffernz f�r gr��ten diagonalsprung
x,y:

*/


Actiondetect::Actiondetect() : BigIntIter()
{
Darstellung = D_Actiondetect;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Actiondetect::~Actiondetect()
{

}
//---------------------------------------------------------------------------
IStatus Actiondetect::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

zi = 0;
za.zero();

lastx.zero();
lasty.zero();
lastz.zero();
unten.zero();
oben.zero();
obenmax.zero();
verlauf = 0x0;
itermax = 0;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Actiondetect::iterate_run(int isteps)
{
int			is;
bigint		dx,dy;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
	ia->Rechnen();

    lastx -= ax; 			// za = entfernung zwischen 2 ergebnissen hoch 2
    lasty -= ay;
    lastx *= lastx;
    lasty *= lasty;
    za = lastx;
    za += lasty;
    lastx = ax;
    lasty = ay;

    switch ( verlauf )
    {
    case 0:		if ( lastz < za )
    				{
		    		verlauf = 1;
                    }
    			break;
    case 1:		if ( lastz > za )
    				{
		    		verlauf = 2;
                    oben = lastz;
                    }
    			else
                	verlauf = 1;
    			break;
    case 2:		if ( lastz > za )
    				{
		    		verlauf = 3;
                    }
    			else
                	verlauf = 1;
    			break;
    case 3:     if ( lastz < za )
    				{
		    		//verlauf = 4;
                    unten = oben - lastz;
                    klein = unten;
					klein /= 10;
                    }
//    			break;						kein break... mit default weitermachen !
    default:	if ( klein < za )
    				{
                    verlauf++;
                    }
    			else
                	verlauf = 0;
                break;
    case 20:	if ( obenmax < unten )
			    	{
			    	obenmax = unten;
			        itermax = itercount - 1;
			        }
    			verlauf = 0;
                break;
	}
    lastz = za;

    if ( r > zmaxbi )
    	{
        iterstatus = outside;
        za = obenmax;
	    ex = obenmax;
		ey = za;
    	zi = itermax;
		return iterstatus;
        }
    }
ex = obenmax;
ey = za;
za.zero();
zi = 0;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  AereaOfOrbit  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*


Ausgaben:
I:			Die belegten Fl�chenpunkte
Z:
x,y:

*/
unsigned	BitNr[] = { 0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80,0x100,0x200,0x400,0x800,0x1000,0x2000,0x4000,0x8000,0x10000,0x20000,0x40000,0x80000,0x100000,0x200000,0x400000,0x800000,0x1000000,0x2000000,0x4000000,0x8000000,0x10000000,0x20000000,0x40000000,0x80000000 };

#define		AHeight		0x0400   //4096


AereaOfOrbit::AereaOfOrbit() : BigIntIter()
{
Darstellung = D_AereaOfOrbit;

aerea = new unsigned[ AHeight * AHeight / 32 ];
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
AereaOfOrbit::~AereaOfOrbit()
{

delete [] aerea;
}
//---------------------------------------------------------------------------
IStatus AereaOfOrbit::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{
int		i,asize;

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

asize = AHeight * AHeight / 32;
for ( i = 0; i < asize; i++ )
	aerea[i] = 0;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus AereaOfOrbit::iterate_run(int isteps)
{
int			i,is,apx,apy,apb,asize,ah2,ah4;
unsigned	a1,a2;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

asize = AHeight * AHeight / 32;
ah2 = AHeight / 2;
ah4 = AHeight / 4;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
    ia->Rechnen();
	apx = (ax * (bigint)ah4 );
	apy = (ay * (bigint)ah2 );
    apx += ah2;
    apy += ah2;
    if ( apx >= 0 )
   		if ( apx < AHeight )
		    if ( apy >= 0 )
   				if ( apy < AHeight )
                	{
                    apb = apx % 32;
                    apx = apx / 32;
                    aerea[apy+apx] |= BitNr[apb];
                    }
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		break;
        }
    }
is = 0;
for ( i = 0; i < asize; i++ )
	{
    a1 = aerea[i];
	for ( apb=0; apb<32; apb++ )
    	{
        a2 = a1 & BitNr[apb];
    	if ( a2 > 0 )
        	is++;
        }
    }
zi = is;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  SternSeek  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*

Ausgaben:
I:          Drehwinkel 0..360
Z:          Periodenanzahl
x,y:        Position "Center of Orbit"

*/
SternSeek::SternSeek() : BigIntIter()
{
Darstellung = D_SternSeek;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
SternSeek::~SternSeek()
{

}
//---------------------------------------------------------------------------
IStatus SternSeek::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{
int		i;

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = ( imaxi > 360 )? 360 : imaxi;;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

xc = 0x0000;
yc = 0x0000;

for ( i=0; i<630; i++ )
    w[i] = 0;
for ( i=0; i<360; i++ )
	{
    xp[i] = 0;
    yp[i] = 0;
    }

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus SternSeek::iterate_run(int isteps)
{
long		is,i,iw;
long double	xd,yd,xs,ys,xw,yw,t,a;					// f�r Berechnung size

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
	ia->Rechnen();
    xp[itercount] = ax;
    yp[itercount] = ay;

    itercount++;
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		break;
        }
    xc += ax;
    yc += ay;
    }
ex = xc;
ex /= itercount;
ey = yc;
ey /= itercount;
xd = xc;
xd /= itercount;
yd = yc;
yd /= itercount;

/*for ( i=0; i<360; i++)
	{
    xw = xp[i] - xd;
    yw = yp[i] - yd;
    if ( yw != 0.0 && xw != 0.0 )
    	{
	    a = atan2l( yw, xw );
	    a *= 10;         			// soll 100 sein
    	a += 314;
	    iw = a;
    	w[iw] = 1;
        }
    }

iw = 0;
for ( i=0; i<630; i++ )
    if ( w[i] > 0 )
    	iw++;

zi = iw;
*/
long double  m = 9999.9,b;

xs = xp[0];							// iw bringt die selben Ergebnisse wie Bubblebrot !
ys = yp[0];
for ( i=1; i<360; i++ )
	{
    xw = xp[i] - xs;
    yw = yp[i] - ys;
    b = xw * xw + yw * yw;
    if ( b != 0.0 )
    	{
		a = sqrtl( b );
    	if ( a < m )
    		{
	        m = a;
    	    iw = i; 				// zi = Periodenanzahl
        	}
        }
    }

xw = xp[0] - xd;  					// Winkeldiffernz errechnen
yw = yp[0] - yd;
if ( yw != 0.0 && xw != 0.0 )
    a = atan2l( yw, xw );
else
	a = 0;

xw = xp[iw] - xd;
yw = yp[iw] - yd;
if ( yw != 0.0 && xw != 0.0 )
    b = atan2l( yw, xw );
else
	b = 0;

a = a - b;
if ( a > 3.1415926 )
	a -= 6.2831853;
else if ( a < -3.1415926 )
	a += 6.2831853;

za = a;
zi = iw;
//za = ( xc * xc ) + ( yc * yc );				// Radius mittelpunkt
//za.sqrtl();
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Steigung  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
																				Auswertung der Iterationsnummer bei Z-Min
Statt dem Radius(z) wird dessen Quadrat zur Auswertung benutzt, das
erspart die sqrtl()-Rechenzeit ( ca. 75% der Gesamtzeit ).

Ausgaben:
I:          Iterationsabstand zwischen 1 + 2
Z:          Z-differenz zwischen Max1 und Max2
x,y:

*/


Steigung::Steigung() : BigIntIter()
{
Darstellung = D_Steigung;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Steigung::~Steigung()
{

}
//---------------------------------------------------------------------------
IStatus Steigung::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

itercount = 0;
iterstatus = start;
imax = imaxi;
zmaxbi = ( zmaxi * zmaxi ); 		// Quadrat von zmaxi zum Vergleich

bmin = 20000000;
imin = 1;
iup = 1;
idown = 1;
epsilon = ModeZs;

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Steigung::iterate_run(int isteps)
{
int			is;
long double bb;

zi = 0;
za = 0x0000;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
	is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

zi = 0;
za = 0.0;
iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
	ia->Rechnen();
    if  (r > 0)
    	{
        if (bmin > r)
        	{
	        bmin = r;                           // wenn neues Z-Min, die ganze Messung von vorne
            bup = r;
            bdown = r;
            bdownlast = r;
            imin = itercount;
            iup = itercount;
            idown = itercount;
	        }
        else
            {
            if (( itercount % imin ) == 0 )
                if ( r > bup )                              // oberen Wendepunkt suchen
                    {
                    bup = r;
                    bdown = r;
                    iup = itercount;
                    }
                else                                        // gefunden....
                    if ( r < bdown )                        // unteren Wendepunkt suchen....
                        {
                        bdown = r;
                        idown = itercount;
                        }
                    else                                    // gefunden
                        {
                        b1 = bdownlast;
                        b2 = bdown;
						b1.sqrt();
						b2.sqrt();
                        bb = b2 - b1;
                        if ( bb < epsilon )                 // Ende erreicht?
                            {
                            zi = idown - iup;
                            za = b2-b1;
                            for ( is=100-is; is>0; is--)       // inside nur wenn minimum 100 Iter
                            	{
                            	ia->Rechnen();
                                if ( r > zmaxbi )
                                    {
                                    iterstatus = outside;
                                    zi = 0;
                                    za = 0.0;
                                    }
                                }
                            break;
                            }
                        bdownlast = bdown;
                        bup = bdown;
                        }
            }
        if ( r > zmaxbi )
    	    {
            iterstatus = outside;
	        break;
		    }
        }
    }

ex = 0x0000;
ey = 0x0000;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  SteigungPeriode  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es wird die xte Schwingung (Periode) beginend ab Z-Min (oder Vielfachem) gemessen
Periodendauer in Iterationen,

Ausgaben:
I:
Z:          Steigung
x,y:        nix,nix

*/

SteigungPeriode::SteigungPeriode() : BigIntIter()
{
Darstellung = D_SteigungPeriode;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
SteigungPeriode::~SteigungPeriode()
{
}
//---------------------------------------------------------------------------
IStatus SteigungPeriode::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{
int		i;

pernr = ModeNr;
itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

bmin = 20000000;
imin = 1;
iup = 1;
idown = 1;

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus SteigungPeriode::iterate_run(int isteps)
{
int			is,pn;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
	ia->Rechnen();
    if  (r > 0)
    	{
        if (bmin > r)
        	{
	        bmin = r;                           // wenn neues Z-Min, die ganze Messung von vorne
            bup = r;
            bdown = r;
            imin = itercount;
            iup = itercount;
            idown = itercount;
            pn = pernr;
	        }
        else
            {
            if ((( itercount % imin ) == 0 ) && pn > 0 )
                if ( r > bup )                              // oberen Wendepunkt suchen
                    {
                    bup = r;
                    bdown = r;
                    iup = itercount;
                    }
                else
                    if ( r < bdown )                        // unteren Wendepunkt suchen
                        {
                        bdown = r;
                        idown = itercount;
                        }
                    else
                        {
                        if ( pn > 1 )                       // wenn gew�nschte Periode nicht erreicht, dann von vorne
                            {
                            imin = idown;
                            iup = idown;
                            bmin = bdown;
                            bup = bdown;
                            }
                        pn--;                               // wenn gew�nschte Periode erreicht, ist pn = 0
                        }
            }
        if ( r > zmaxbi )
    	    {
            iterstatus = outside;
	        break;
		    }
        }
    }

zi = 0;
za = 0.0;
if ( iterstatus == inside )
    if ( idown > iup )
        {
        zi = ( idown - imin );
		bup.sqrt();
		bmin.sqrt();
        za = bup - bmin;
        }

ex = 0x0000;
ey = 0x0000;

return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  FirstIter  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es wird das ergebnis der ersten Iteration von der 2.Subtrahiert.
Innerhalb der MBM sollte z2 kleiner als z1 sein?
Ein positives ergebnis ist also innerhalb der MBM. ......Stimmt nicht!!!!

Ausgaben:
I:
Z:          Z = z1 - z2 ;
x,y:        Position der letzten Iteration

*/
FirstIter::FirstIter() : BigIntIter()
{
Darstellung = D_FirstIter;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
FirstIter::~FirstIter()
{

}
//---------------------------------------------------------------------------
IStatus FirstIter::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );
z2.zero();
z1.zero();

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus FirstIter::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
    ia->Rechnen();
    if ( itercount == 1 )
    	{
        z1 = r;
		z1.sqrt();
        }
    if ( itercount == 6 )
    	{
        z2 = r;
		z2.sqrt();
        za = z1;
        za -= z2;
		ex = ay;
		ey = ax;
        zi = itercount;
		return iterstatus;
        }
    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		ex = ay;
		ey = ax;
        zi = itercount;
        za.zero();
		return iterstatus;
        }
    }
ex = ay;
ey = ax;
zi = itercount;
za.zero();
return iterstatus;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------
//  E-Weg  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Es werden alle Entfernungen zwischen 2 Iterationsergebnissen aufsummiert.

Ausgaben:
I:              Iternummer f�r Z
Z:				Summe
x,y:

*/


EWeg::EWeg() : BigIntIter()
{
Darstellung = D_EWeg;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------
EWeg::~EWeg()
{

}
//---------------------------------------------------------------------------
IStatus EWeg::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;
ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

zi = 0;
za.zero();

lastx.zero();
lasty.zero();

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus EWeg::iterate_run(int isteps)
{
int			is;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
	ia->Rechnen();

    lastx -= ax; 			// za = entfernung zwischen 2 ergebnissen hoch 2
    lasty -= ay;
    lastx *= lastx;
    lasty *= lasty;
    za += lastx;
    za += lasty;
    lastx = ax;
    lasty = ay;

    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		ex = ay;
		ey = ax;
		za.sqrt();
    	zi = itercount;
		return iterstatus;
        }
    }
ex = ay;
ey = ax;
za.sqrt();
zi = itercount;
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
//  Grundwelle  ######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Grundwelle-Auswertung

Ausgaben:
I:			Die erreichte Iterationsanzahl bis MaxI.
Z:          Z der letzten Iteration
x,y:        Position der letzten Iteration

*/
Grundwelle::Grundwelle() : BigIntIter()
{
Darstellung = D_Grundwelle;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------
Grundwelle::~Grundwelle()
{

}
//---------------------------------------------------------------------------
IStatus Grundwelle::iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs)
{
int i;

itercount = 0;
iterstatus = start;

ax = aix;
ay = aiy;
cx = cix;
cy = ciy;

gwnr = ModeNr;
if ( gwnr > 4 ) gwnr = 4;
for ( i=0; i<=gwnr; i++ )
    {
    ra[i].zero();
    rb[i].zero();
    rc[i].zero();
    icb[i] = 0;
    }

ia->Vorbereiten();

imax = imaxi;
zmax = zmaxi;
zmaxbi = ( zmaxi * zmaxi );

return iterstatus;
}
//---------------------------------------------------------------------------
IStatus Grundwelle::iterate_run(int isteps)
{
int			is,i;
bigint      rend;

if ( iterstatus == outside )
	return iterstatus;
if ( itercount + isteps > imax )
	{
    is = imax - itercount;
    if ( is < 1 )
    	return iterstatus;
    }
else
    is = isteps;

iterstatus = inside;
while ( is > 0 )
	{
    is--;
    itercount++;
    ia->Rechnen();

    rb[0] = r;
    for ( i=1; i<=gwnr; i++ )
        {
        ra[i] = rb[i];
        rb[i] = rc[i];
        rc[i] = rb[i-1];
        if ( ra[i] < rb[i] )
           if ( rc[i] < rb[i] )
              {
              icb[i] = itercount;
              break;
              }
        }

    if ( r > zmaxbi )
    	{
        iterstatus = outside;
		ex = ay;
		ey = ax;
        zi = icb[gwnr];
        za = rb[gwnr];
		za.sqrt();
		return iterstatus;
        }
    }
ex = ay;
ey = ax;
zi = icb[gwnr];
za = rb[gwnr];
za.sqrt();
return iterstatus;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------

