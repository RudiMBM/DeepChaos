//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "OrbitAnalyse.h"
#include "ZeitReihe.h"
#include "BildForm.h"
#include "DCMAIN.h"
#include "PhasenAnalyse.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPhasenWd *PhasenWd;
//---------------------------------------------------------------------------
__fastcall TPhasenWd::TPhasenWd(TComponent* Owner)
	: TForm(Owner)
{

Sf = "PhasenWindow";
Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", Constraints->MinWidth );
Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", Constraints->MinHeight );

}
//---------------------------------------------------------------------------

void __fastcall TPhasenWd::FormClose(TObject *Sender, TCloseAction &Action)
{

DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
DCWd->SettingsFile->WriteInteger(Sf, "Width", Width );
DCWd->SettingsFile->WriteInteger(Sf, "Heigth", Height );
}
//---------------------------------------------------------------------------

void __fastcall TPhasenWd::FormResize(TObject *Sender)
{

if ( ClientHeight > ClientWidth )
	ClientWidth =  ClientHeight;
else
	ClientHeight =  ClientWidth;
}
//---------------------------------------------------------------------------

void __fastcall TPhasenWd::FormKeyNow( WORD &Key )
{

}
//---------------------------------------------------------------------------

