//---------------------------------------------------------------------------

#ifndef AnimationH
#define AnimationH

#include "jpeg.hpp"

//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>
#include "LMDCheckListBox.hpp"
#include "LMDCustomCheckListBox.hpp"
#include "LMDCustomImageListBox.hpp"
#include "LMDCustomListBox.hpp"
#include <CheckLst.hpp>

#define	APMAX 100

//---------------------------------------------------------------------------
//			F�r die Animation
//---------------------------------------------------------------------------
typedef		enum			{leer, neu, bearbeitet, done, gel�scht } TDAniStatus;

typedef		struct		 {
							TMainParams		AParam;
							String			Bez;
							String			FileName;
							TDAniStatus		Status;
							} TDAnimationParam;


//---------------------------------------------------------------------------

class TPxyz
{
private:

public:
						TPxyz();
			void		neg();
			void		div( long double );
			long double	tdiff( const TPxyz& );
//			TPxyz		tdiff( const TPxyz& );
			TPxyz		mirrow( const TPxyz& );
			void   		operator-=(const TPxyz&);
			void   		operator+=(const TPxyz&);


			bigint		X,Y;
			long double	Z;


};
//---------------------------------------------------------------------------

class TBezier
{
private:

public:
			TPxyz	p0,p1,p2,p3,p4,p5,p6;

					TBezier();
};
//---------------------------------------------------------------------------

class TAnimationWd : public TForm
{
__published:	// IDE-verwaltete Komponenten
	TButton *RefFileBtn;
	TListBox *ListBox;
	TOpenDialog *OpenRefFile;
	TButton *DelBtn;
	TButton *MakeBtn;
	TButton *StopBtn;
	TButton *ErledigtBtn;
	TButton *UpBt;
	TButton *DownBt;
	TCheckBox *BildShowCb;
	TCheckBox *BezierShowCb;
	TButton *LoadFileBtn;
	TButton *SaveFileBtn;
	TEdit *Edit1;
	TLabel *Label6;
	TButton *NeuesBildBtn;
//	void __fastcall FormMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall RefFileBtnClick(TObject *Sender);
	void __fastcall DelBtnClick(TObject *Sender);
	void __fastcall MakeBtnClick(TObject *Sender);
	void __fastcall StopBtnClick(TObject *Sender);
	void __fastcall ListBoxDrawItem(TWinControl *Control, int Index, TRect &Rect, TOwnerDrawState State);
	void __fastcall UpBtClick(TObject *Sender);
	void __fastcall DownBtClick(TObject *Sender);
	void __fastcall ListBoxClick(TObject *Sender);
	void __fastcall NeuesBildBtnClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);


private:	// Benutzer-Deklarationen

		TMainParams		pt,mp0,mp1,mp2;

		signed long int			mx0,my0,mx3,my3,mx6,my6;
		bigint					delta;
		long double				deltad;
		TBezier					Bz;
		bool					StopFlag;
		int						Speed,Beschleunigung;
		TBildWd					*VorschauWd;
		TDAnimationParam		*AP[APMAX];

public:		// Benutzer-Deklarationen
			__fastcall TAnimationWd(TComponent* Owner);
	void    __fastcall MakeTake( int APindex );
};
//---------------------------------------------------------------------------
extern PACKAGE TAnimationWd *AnimationWd;
//---------------------------------------------------------------------------
#endif
