//---------------------------------------------------------------------------

#ifndef ZeitReiheH
#define ZeitReiheH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ToolWin.hpp>
#include <TypeTrans.hpp>

#include "Tastencodes.h"
#include "LMDBaseEdit.hpp"
#include "LMDControl.hpp"
#include "LMDCustomBevelPanel.hpp"
#include "LMDCustomControl.hpp"
#include "LMDCustomEdit.hpp"
#include "LMDCustomPanel.hpp"
#include "LMDEdit.hpp"
#include "LMDCustomExtSpinEdit.hpp"
#include "LMDCustomMaskEdit.hpp"
#include "LMDSpinEdit.hpp"
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include <Menus.hpp>

#define	zfMesslinie		0x0040404

//---------------------------------------------------------------------------

class TBildV
{
public:
					TBildV();
		void		SetHeight( int );
		void		SetMin( bigint* );
		void		SetMax( bigint* );
		int			P( bigint* );
		bigint	   	P( int );
		int	   		Y( bigint* );
		double	   	Yd( bigint* );
		bigint	   	Y( int mpos );
		bool   		isinside( bigint* );

		bigint		VTop,VBottom;

private:
		int			BildHeight;
		bigint		delta;
		long double deltad;

};


//---------------------------------------------------------------------------

class TBildX
{
public:
					TBildX();
		void		SetWidth( int );
		void		SetMinMax( int, int );
		int			I( int iternr );
		double		Id( int iternr );
		int		   	Ivon( int mpos );
		int		   	Ibis( int mpos );
		int	   		DivX( int nr );
		int	   		DivI( int nr );
		bool		isinside( int xpos );

		int			Xleft,Xright;
		int			IterPdiv;
		int			IAbstand;           // Distanz zwischen Iter in Pixel

private:
		int			BildWidth;
		long double MpDist;
		int         Ia2;
};


//---------------------------------------------------------------------------

class TZeitRWd : public TForm
{
//	friend class TVertZoom;

__published:	// IDE-verwaltete Komponenten
	TStatusBar *StatusBar;
	TToolBar *ZRToolBar;
	TPanel *OptPl;
	TGroupBox *AnzeigeGb;
	TCheckBox *mitRCb;
	TCheckBox *mitArgCb;
	TCheckBox *mitXCb;
	TCheckBox *mitYCb;
	TCheckBox *mitECb;
	TCheckBox *CheckBox1;
	TCheckBox *CheckBox2;
	TLabel *Label29;
	TLMDSpinEdit *RepXteEd;
	TLabel *Label30;
	TLMDSpinEdit *StartXteEd;
	TToolButton *ZeichnenTb;
	TLabel *Label3;
	TLMDSpinEdit *IterAbEd;
	TLabel *Label5;
	TLMDSpinEdit *IterBisEd;
	TCheckBox *IterTestLineCb;
	TToolButton *ZoomInVTb;
	TToolButton *ToolButton1;
	TToolButton *ToolButton2;
	TToolButton *ToolButton3;
	TToolButton *ZoomInHTb;
	TToolButton *PvTb;
	TToolButton *ToolButton4;
	TToolButton *D_Tb;
	TCheckBox *SofortRechnenCb;
	TLabel *VomLabel;
	TComboBox *TpQuelleCb;
	TSavePictureDialog *SaveDlg;
	TMainMenu *MainMenu1;
	TMenuItem *DateiMi;
	TMenuItem *SpeichernAlsMi;
	TMenuItem *BeendenMi;
	TCheckBox *DiffRefCb;
	TToolButton *ZoomOutVTb;
	TImage *ZrIm;
	TPanel *yAchsePl;
	TLabel *Label8;
	TLabel *Label9;
	TLabel *Label1;
	TLabel *Label4;
	TLabel *Label6;
	TLabel *Label2;
	TLabel *Label7;
	TLMDEdit *ObenGrenzeEd;
	TLMDEdit *MessLinieEd;
	TLMDEdit *UntenGrenzeEd;
	TLMDEdit *IterNrEd;
	TLMDEdit *VsizeEd;
	TLMDEdit *MinzEd;
	TLMDEdit *Diffmml;
	TLMDEdit *HelpEd;
	void __fastcall FormPaint(TObject *Sender);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall ZrImMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall ZeichnenTbClick(TObject *Sender);
	void __fastcall SpinBtnClick(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall ZrImMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall ZrImMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall ZoomInVTbClick(TObject *Sender);
	void __fastcall ZoomInHTbClick(TObject *Sender);
	void __fastcall PvTbClick(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall SpeichernAlsMiClick(TObject *Sender);
	void __fastcall BeendenMiClick(TObject *Sender);

public:		// Benutzer Deklarationen
			__fastcall 	TZeitRWd(TComponent* Owner);
	void 	__fastcall 	TpMouseMove( Word Key );
	void  	__fastcall	FormKeyNow( WORD &Key );

	bigint				CursorXbi,CursorYbi;				// Koordinaten am Cursor



private:	// Benutzer Deklarationen
		void __fastcall PaintZoom( TRect zr );
		void __fastcall PaintNow(TObject *Sender);
		void __fastcall PaintIterLine( int x, TColor c, bool f );
		void  ( __closure 	*CommandKD)(WORD &Key);
		void 			DateiKeyDown(WORD &Key);
		void  			NoKeyDown(WORD &Key);
		void __fastcall TZeitRWd::SpeichernAs(TObject *Sender);
		void __fastcall Zeichnen(TObject *Sender);
		void __fastcall ZeichnenDot(int x, int y, bigint *biy, TColor c);
		bool __fastcall zrdSpeichern();

		TCanvas				*ZrC,*PiC;
		Graphics::TBitmap	*PreImageBitmap;
		TStringList 		*zrdSL;


		Char			CommandKey;
		TRect			zoomrahmen;
		int				Xdown,Ydown;				// Mouse down merker
		TBildV			BildV;
		TBildX			BildX;
		TMainParams		Params;
		BigIntIter		*bii,*Refii;

		String			Sf;
		TStatusPanel 	*Statusp1,*Statusp2,*Statusp0;


#define	KxAnz 7                                          // Nur 7 weil km01 nicht gezeichnet wird
		bigint			Km2,Km1,Km05,K0,K05,K1,K2,Km01;
		bigint			*Kx[KxAnz];
		bigint			MessLinie;

		int				IterTestLinie;
		int				LastMaxIter;

		bool 			warschon;

};
//---------------------------------------------------------------------------
extern PACKAGE TZeitRWd *ZeitRWd;
//---------------------------------------------------------------------------
#endif
