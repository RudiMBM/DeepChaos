//---------------------------------------------------------------------------

#ifndef PhasenAnalyseH
#define PhasenAnalyseH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TPhasenWd : public TForm
{
__published:	// IDE-verwaltete Komponenten
	TStatusBar *StatusBar;
	TPanel *ALP;
	void __fastcall FormResize(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);


private:	// Benutzer Deklarationen
		String				Sf;


public:		// Benutzer Deklarationen
	__fastcall TPhasenWd(TComponent* Owner);
			void  __fastcall	FormKeyNow( WORD &Key );

//				TDMbmParam			*Params;

};
//---------------------------------------------------------------------------
extern PACKAGE TPhasenWd *PhasenWd;
//---------------------------------------------------------------------------
#endif
