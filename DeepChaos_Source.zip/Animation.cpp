//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "Tastencodes.h"
#include "Bigint.h"
#include "Global.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "HelpForm.h"
#include "ZeitReihe.h"
#include "PhasenAnalyse.h"
#include "OrbitAnalyse.h"
#include "BildForm.h"
#include "DCMAIN.h"
#include "ThreadErzeugen.h"
#include "Animation.h"
//---------------------------------------------------------------------------
/*
p0 = Startp.
p1 = Startrichtungspunkt
p2 = Endrichtungspunkt
p3 = Endp.

step 0,0 bis 1,0 ( LinienAufl�sung )

Vector GetPointOnBezierCurve( Vector p0, Vector p1, Vector p2, Vector p3, float step )
{

float u = 1.0 - step;
float t2 = t * t;
float u2 = u * u;
float u3 = u2 * u;
float t3 = t2 * t;

return ( (u3) * p0 + (3.0 * u2 * t) * p1 + (3.0 * u * t2) * p2 + (t3) * p3 );
}

*/
//--------------------------------------------------------------------------------
TPxyz::TPxyz(){}

void	TPxyz::neg()
{

X.neg();
Y.neg();
Z *= -1;
}

void 	TPxyz::operator-=(const TPxyz& o)
{

X -= o.X;
Y -= o.Y;
Z -= o.Z;
}

void 	TPxyz::operator+=(const TPxyz& o)
{

X += o.X;
Y += o.Y;
Z += o.Z;
}

void	TPxyz::div( long double d )
{

X /= d;
Y /= d;
Z /= d;
}

long double	TPxyz::tdiff( const TPxyz& o)
{
bigint		cm,cq,cs;
long double	rs;

cm = X;
cm -= o.X;
cs = cm;
cs *= cm;
cm = Y;
cm -= o.Y;
cq = cm;
cq *= cm;
cs += cq;
cm = Z;
cm -= o.Z;
cq = cm;
cq *= cm;
cs += cq;
//cs.sqrt();
rs = cs;
return sqrt(rs);
}

TPxyz	TPxyz::mirrow( const TPxyz& o)
{
TPxyz	e;

e.X = X - o.X;
e.X = (bigint)o.X + e.X;
e.Y = Y - o.Y;
e.Y = (bigint)o.Y + e.Y;
e.Z = Z - o.Z;
e.Z = o.Z + e.Z;
return ( e );
}
//---------------------------------------------------------------------------
TBezier::TBezier(){}


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "LMDCheckListBox"
#pragma link "LMDCustomCheckListBox"
#pragma link "LMDCustomImageListBox"
#pragma link "LMDCustomListBox"
#pragma resource "*.dfm"
TAnimationWd *AnimationWd;
//---------------------------------------------------------------------------
__fastcall TAnimationWd::TAnimationWd(TComponent* Owner): TForm(Owner)
{
int		i;

StopFlag = false;
//jp = new TJPEGImage();
for ( i=0; i<APMAX; i++ ) AP[i] = NULL;

}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::FormActivate(TObject *Sender)
{

//OpenRefFile->InitialDir = DCWd->PfadEd->Text;
DCWd->Sftemp = "Animation";
if ( VorschauWd == NULL )
	{
	Application->CreateForm(__classid(TBildWd), &VorschauWd );
	DCWd->BildWdTab[AnimationsEditWd] = VorschauWd;
	DCWd->BildWdTab[AnimationsEditWd]->WdNr = AnimationsEditWd;
//	AktivesFenster = BildWdTab[AnimationsEditWd];
	VorschauWd->Top = DCWd->SettingsFile->ReadInteger(DCWd->Sftemp, "Top", Top );
	VorschauWd->Left = DCWd->SettingsFile->ReadInteger(DCWd->Sftemp, "Left", Width);
	VorschauWd->Sf = DCWd->Sftemp;
	}
else
	{
	VorschauWd->Visible = true;
	VorschauWd->BringToFront();
	}
DCWd->EDP->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::FormClose(TObject *Sender, TCloseAction &Action)
{

if ( VorschauWd != NULL ) VorschauWd->Close();
VorschauWd = NULL;
DCWd->BildWdTab[AnimationsEditWd] = NULL;
Action = caFree;
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::MakeBtnClick(TObject *Sender)
{
int			APindex = 0;

StopFlag = false;

while ( AP[APindex] != NULL ){
	if ( AP[APindex+1] != NULL ) MakeTake( APindex );
	APindex++;
	}
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::MakeTake( int APindex )
{

}
//---------------------------------------------------------------------------

/*
void __fastcall TAnimationWd::MakeBtnClick(TObject *Sender)
{
int			iFileHandle;
char	 	vers[33];
TMainParams pt;
int			bn,i,x,BildNr,Speedl,FileLine;
long double lengt = 1.0;
long double	deltadstart;
TBildWd		*Bwd;
TPxyz		pb,pbo;
bigint		t,ts;
String		fn;


StopFlag = false;
Speedl = 1;
Speed = 4;
Beschleunigung = 1;
i = 1;
bn = 0;
while ( DCWd->BildWdTab[i] != NULL && i<= BildWdMaxNr+1 )
	i++;
if ( i>=BildWdMaxNr ) return;
bn = i;
		{
		iFileHandle = FileOpen( ListBox->Items->Strings[0], fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &pt, sizeof(pt)); 		// erst tempor�r laden f�r Bilderstellung
			DCWd->BildNeu( bn );
			DCWd->BildWdTab[bn]->Params = pt;
			DCWd->BildWdTab[bn]->GoBtnNow2();
			DCWd->DisplMbmEdit();
			FileRead(iFileHandle, DCWd->BildWdTab[bn]->Ergebnis, (sizeof(long double) * pt.BildSizeX * pt.BildSizeY ));
			DCWd->BildShow(bn);
			DCWd->BildWdTab[bn]->Bildgerechnet = true;
			DCWd->BildWdTab[bn]->NeuZeichnen();
			DCWd->BildWdTab[bn]->Statusp2->Text = OpenRefFile->FileName;
			Bwd = DCWd->BildWdTab[bn];
			}
		FileClose(iFileHandle);
		}
mp0 = pt;
Speed = pt.Speed;
Beschleunigung = pt.Beschleunigung;
		{
		iFileHandle = FileOpen( ListBox->Items->Strings[1], fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &mp1, sizeof(pt));
			}
		FileClose(iFileHandle);
		}
		{
		iFileHandle = FileOpen( ListBox->Items->Strings[2], fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &mp2, sizeof(pt));
			}
		FileClose(iFileHandle);
		}
Bz.p0.X = mp0.cx;
Bz.p0.Y = mp0.cy;
Bz.p0.Z = mp0.BildSize;
Bz.p3.X = mp1.cx;
Bz.p3.Y = mp1.cy;
Bz.p3.Z = mp1.BildSize;
Bz.p6.X = mp2.cx;
Bz.p6.Y = mp2.cy;
Bz.p6.Z = mp2.BildSize;
deltadstart = mp0.BildSize / mp0.BildSizeX;
deltad = mp1.BildSize / mp1.BildSizeX;

Bz.makeP1P2( deltadstart / deltad );                      								// erster Take
pbo = Bz.p0;
t = 0.0001;
ts = 0.0001;
BildNr = 0;
while ( t < (bigint)1.0 )
	{
	Bz.setT( t );
	Bz.getP( pb );
	lengt = pb.tdiff( pbo );
	lengt /= deltad;
	x = lengt;
	if ( x >= Speedl )
		{
		if ( Speedl < Speed )
			{
			Speedl += Beschleunigung;
			if ( Speedl > Speed )
				Speedl = Speed;
			}
		else if ( Speedl > Speed )
			{
			Speedl -= Beschleunigung;
			if ( Speedl < Speed )
				Speedl = Speed;
			}
		Bwd->Params.cx = pb.X;
		Bwd->Params.cy = pb.Y;
		Bwd->Params.BildSize = pb.Z;
		deltad = Bwd->Params.BildSize / Bwd->Params.BildSizeX;
		if (  ErledigtLb->Items->Strings[0].Pos("erl.") == 0 )
			{
			Bwd->KommandoSend( "r" );
			fn = ChangeFileExt(ListBox->Items->Strings[0], "") + "_B" + FormatFloat("000000",BildNr) + ".jpg";
			jp->Assign(Bwd->BildIm->Picture->Bitmap);
			jp->SaveToFile(fn);
			}
		pbo = pb;
		BildNr++;
		}
	Application->ProcessMessages();
	if ( StopFlag == true ) return;
	t += ts;
	}
ErledigtLb->Items->Strings[0] = "erl.";
ListBox->Repaint();
for ( FileLine=3; FileLine < ListBox->Items->Count; FileLine++ )      // alle zwischen Takes
	{
	Bz.p0 = Bz.p3;
	Bz.p1 = Bz.p0;
	pb = Bz.p2;
	pb -= Bz.p0;
	pb.neg();
	Bz.p1 += pb;
	Bz.p3 = Bz.p6;
		{
		iFileHandle = FileOpen( ListBox->Items->Strings[FileLine], fmOpenRead);
		FileRead(iFileHandle, vers, 32);
		vers[32] = 0x00;
		if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &mp2, sizeof(pt));
			}
		FileClose(iFileHandle);
		}
	Bz.p6.X = mp2.cx;
	Bz.p6.Y = mp2.cy;
	Bz.p6.Z = mp2.BildSize;
	deltadstart = mp2.BildSize / mp2.BildSizeX;
	Speed = mp2.Speed;
	Beschleunigung = mp2.Beschleunigung;

	Bz.makeP2( deltadstart / deltad );
	t = 0.0001;
	ts = 0.0001;
	BildNr = 0;
	while ( t < (bigint)1.0 )
		{
		Bz.setT( t );
		Bz.getP( pb );
		lengt = pb.tdiff( pbo );
		lengt /= deltad;
		x = lengt;
		if ( x >= Speedl )
			{
			if ( Speedl < Speed )
				{
				Speedl += Beschleunigung;
				if ( Speedl > Speed )
					Speedl = Speed;
				}
			else if ( Speedl > Speed )
				{
				Speedl -= Beschleunigung;
				if ( Speedl < Speed )
					Speedl = Speed;
				}
			Bwd->Params.cx = pb.X;
			Bwd->Params.cy = pb.Y;
			Bwd->Params.BildSize = pb.Z;
			deltad = Bwd->Params.BildSize / Bwd->Params.BildSizeX;
			if ( deltad < 0 )
				Bz.getP( pb );
			if (  ErledigtLb->Items->Strings[FileLine-2].Pos("erl.") == 0 )
				{
				Bwd->KommandoSend( "r" );
				fn = ChangeFileExt(ListBox->Items->Strings[FileLine-2], "") + "_B" + FormatFloat("000000",BildNr) + ".jpg";
				jp->Assign(Bwd->BildIm->Picture->Bitmap);
				jp->SaveToFile(fn);
				}
			pbo = pb;
			BildNr++;
			}
		Application->ProcessMessages();
		if ( StopFlag == true ) return;
		t += ts;
		}
	ErledigtLb->Items->Strings[FileLine-2] = "erl.";
	ListBox->Repaint();
	}
	{                  											// letzter Take
	Bz.p0 = Bz.p3;
	Bz.p1 = Bz.p0;
	pb = Bz.p2;
	pb -= Bz.p0;
	pb.neg();
	Bz.p1 += pb;
	Bz.p3 = Bz.p6;
	t = 0.0001;
	ts = 0.0001;
	BildNr = 0;
	while ( t < (bigint)1.0 )
		{
		Bz.setT( t );
		Bz.getP( pb );
		lengt = pb.tdiff( pbo );
		lengt /= deltad;
		x = lengt;
		if ( x >= Speedl )
			{
			if ( Speedl < Speed )
				{
				Speedl += Beschleunigung;
				if ( Speedl > Speed )
					Speedl = Speed;
				}
			else if ( Speedl > Speed )
				{
				Speedl -= Beschleunigung;
				if ( Speedl < Speed )
					Speedl = Speed;
				}
			Bwd->Params.cx = pb.X;
			Bwd->Params.cy = pb.Y;
			Bwd->Params.BildSize = pb.Z;
			deltad = Bwd->Params.BildSize / Bwd->Params.BildSizeX;
			if (  ErledigtLb->Items->Strings[FileLine-2].Pos("erl.") == 0 )
				{
				Bwd->KommandoSend( "r" );
				fn = ChangeFileExt(ListBox->Items->Strings[FileLine-1], "") + "_B" + FormatFloat("000000",BildNr) + ".jpg";
				jp->Assign(Bwd->BildIm->Picture->Bitmap);
				jp->SaveToFile(fn);
				}
			pbo = pb;
			BildNr++;
			}
		Application->ProcessMessages();
		if ( StopFlag == true ) return;
		t += ts;
		}
ErledigtLb->Items->Strings[FileLine-2] = "erl.";
ListBox->Repaint();
	}
*/
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::StopBtnClick(TObject *Sender)
{

StopFlag = true;
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::RefFileBtnClick(TObject *Sender)
{
int			i;

if ( OpenRefFile->Execute())
	{
	for ( i=0; i<OpenRefFile->Files->Count; i++ )
		{
		ListBox->Items->Insert(ListBox->ItemIndex, OpenRefFile->Files->Strings[i]);
		ListBox->ItemIndex += 1;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::DelBtnClick(TObject *Sender)
{
int 		i;

i=0;
while ( i<ListBox->Items->Count && !ListBox->Selected[i] )
	i++;
while ( ListBox->Selected[i] )
	ListBox->Items->Delete(i);
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::ListBoxDrawItem(TWinControl *Control, int Index, TRect &Rect,
		  TOwnerDrawState State)
{

ListBox->Canvas->FillRect(Rect);
ListBox->Canvas->TextOut(Rect.left+05,Rect.top," bla bl�a");
ListBox->Canvas->TextOut(Rect.left+30,Rect.top,ListBox->Items->Strings[Index]);
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::UpBtClick(TObject *Sender)
{
int 		i;

for ( i=0; i<ListBox->Items->Count; i++ )
	{
	if ( ListBox->Selected[i] )
		{
		if ( i == 0 ) return;
		ListBox->Items->Exchange(i-1,i);
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::DownBtClick(TObject *Sender)
{
int 		i;

for ( i=0; i<ListBox->Items->Count; i++ )
	{
	if ( ListBox->Selected[i] )
		{
		if ( i == 0 ) return;
		ListBox->Items->Exchange(i+1,i);
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::ListBoxClick(TObject *Sender)
{
int			iFileHandle;
char	 	vers[33];
TMainParams pt;
int 		i,bn;

if ( BildShowCb->Checked == false ) return;
i=0;
while ( i<ListBox->Items->Count && !ListBox->Selected[i] )
	i++;
if ( ListBox->Selected[i] )
	{
	if ( VorschauWd == NULL )
		{
		bn = 1;
		while ( DCWd->BildWdTab[bn] != NULL && bn<= BildWdMaxNr+1 )
			bn++;
		if ( bn>=BildWdMaxNr ) return;
		DCWd->BildNeu( bn );
		VorschauWd = DCWd->BildWdTab[bn];
		}
	iFileHandle = FileOpen( ListBox->Items->Strings[i], fmOpenRead);
	FileRead(iFileHandle, vers, 32);
	vers[32] = 0x00;
	if ( strcmp("DeepChaosV2Parameter.Vers1",vers) == 0 )
			{
			FileRead(iFileHandle, &pt, sizeof(pt)); 		// erst tempor�r laden f�r Bilderstellung
			VorschauWd->Params = pt;
			VorschauWd->GoBtnNow2();
			DCWd->DisplMbmEdit();
			FileRead(iFileHandle, VorschauWd->Ergebnis, (sizeof(long double) * pt.BildSizeX * pt.BildSizeY ));
			DCWd->BildShow(VorschauWd->WdNr);
			VorschauWd->Bildgerechnet = true;
			VorschauWd->NeuZeichnen();
			VorschauWd->Statusp2->Text = OpenRefFile->FileName;
			}
	FileClose(iFileHandle);
	}
}
//---------------------------------------------------------------------------

void __fastcall TAnimationWd::NeuesBildBtnClick(TObject *Sender)
{
int		i;

i = ListBox->Items->Count;
ListBox->Items->Insert(ListBox->ItemIndex, "Bild " + IntToStr(i));
}
//---------------------------------------------------------------------------

/*
void __fastcall TAnimationWd::FormMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y)
{
int			x,y;
long double	xd,yd;
bigint		t,ts;
TPxyz		pb,pbo;

switch( ListBox1->ItemIndex )
	{
	case 0:	mx0 = X; my0 = Y; break;
	case 1:	mx3 = X; my3 = Y; break;
	case 2:	mx6 = X; my6 = Y; break;
	}

ZrC = Canvas;
ZrC->Brush->Color = clWhite;    //clBlack;
ZrC->Pen->Color = 0x0707070;
ZrC->Pen->Style = psSolid;
ZrC->FillRect(ZrC->ClipRect);
ZrC->Pen->Color = clRed;
ZrC->Ellipse(mx0-2,my0-2,mx0+2,my0+2);
ZrC->Pen->Color = clGreen;
ZrC->Ellipse(mx3-2,my3-2,mx3+2,my3+2);
ZrC->Pen->Color = clBlue;
ZrC->Ellipse(mx6-2,my6-2,mx6+2,my6+2);

deltad = 2.0e-10;
delta = deltad;
Bz.p0.X = mx0;
Bz.p0.X *= delta;
Bz.p0.Y = my0;
Bz.p0.Y *= delta;
Bz.p0.Z.zero();
Bz.p3.X = mx3;
Bz.p3.X *= delta;
Bz.p3.Y = my3;
Bz.p3.Y *= delta;
Bz.p3.Z.zero();
Bz.p6.X = mx6;
Bz.p6.X *= delta;
Bz.p6.Y = my6;
Bz.p6.Y *= delta;
Bz.p6.Z.zero();

Bz.makeP1P2();
ZrC->Pen->Color = clSilver;
ZrC->MoveTo(mx0,my0);
xd = Bz.p1.X;
xd /= deltad;
x = xd;
yd = Bz.p1.Y;
yd /= deltad;
y = yd;
ZrC->LineTo(x,y);

ZrC->MoveTo(mx3,my3);
xd = Bz.p2.X;
xd /= deltad;
x = xd;
yd = Bz.p2.Y;
yd /= deltad;
y = yd;
ZrC->LineTo(x,y);

long double lengt = 1.0;

pb = Bz.p0;
t = 0.001;
ts = 0.001;
while ( t < (bigint)1.0 )
	{
	pbo = pb;
	do {
		Bz.setT( t );
		Bz.getP( pb );
		lengt = pb.tdiff( pbo );
		lengt /= deltad;
		x = lengt;
		t += ts;
		}
	while ( x < 20 );
	ZrC->Pen->Color = clBlack;
	xd = pb.X;
	xd /= deltad;
	x = xd;
	yd = pb.Y;
	yd /= deltad;
	y = yd;
	ZrC->Ellipse(x-1,y-1,x+1,y+1);
	t += ts;
	}

pb = Bz.p0;
Bz.p0 = Bz.p3;
Bz.p3 = Bz.p6;
Bz.p6 = pb;
Bz.p1 = Bz.p0;
pb = Bz.p2;
pb -= Bz.p0;
pb.neg();
Bz.p1 += pb;
Bz.makeP2();
t = 0.99;
ts = 0.01;
while ( t > 0 )
	{
	Bz.setT( t );
	Bz.getP( pb );
	ZrC->Pen->Color = clBlack;
	xd = pb.X;
	xd /= deltad;
	x = xd;
	yd = pb.Y;
	yd /= deltad;
	y = yd;
	ZrC->Ellipse(x-1,y-1,x+1,y+1);
	t -= ts;
	}

}
*/
//---------------------------------------------------------------------------

