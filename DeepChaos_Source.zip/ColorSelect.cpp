//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

//#include "BigInt.h"
//#include "Global.h"
//#include "StructDefs.h"
//#include "Params.h"
//#include "BigIntIter.h"
//#include "MbmAnz.h"
//#include "Main.h"

#include "ColorSelect.h"
//#include "Colorbar.h"

//---------------------------------------------------------------------
#pragma resource "*.dfm"
TColorsSelect *ColorsSelect;
//---------------------------------------------------------------------
__fastcall TColorsSelect::TColorsSelect(TComponent* AOwner)
	: TForm(AOwner)
{

ModellSelect->Items->Add("Rot - Gr�n");
ModellSelect->Items->Add("Rot - Blau");
ModellSelect->Items->Add("Blau - Gr�n");
ModellSelect->ItemIndex = 1;
newpos = 0;

}
//---------------------------------------------------------------------
void __fastcall TColorsSelect::PaintColorField(TObject *Sender)
{
int		cx,cy,cz,m;
int		x,y;

switch ( ModellSelect->ItemIndex )
	{
	case 0: cx = 0x00000001; cy = 0x00000100; cz = 0x00010000; break;
	case 1: cx = 0x00000001; cy = 0x00010000; cz = 0x00000100; break;
	case 2: cx = 0x00010000; cy = 0x00000100; cz = 0x00000001; break;
	}

m = acz->Width;
for ( y=255; y>=0; y-- )
	{
	acz->Canvas->Pen->Color = cz * y;
	acz->Canvas->MoveTo(0,y);
	acz->Canvas->LineTo(m,y);
	}
m = acy->Width;
for ( y=255; y>=0; y-- )
	{
	acy->Canvas->Pen->Color = cy * y;
	acy->Canvas->MoveTo(0,y);
	acy->Canvas->LineTo(m,y);
	}
m = acx->Height;
for ( y=255; y>=0; y-- )
	{
	acx->Canvas->Pen->Color = cx * y;
	acx->Canvas->MoveTo(y,0);
	acx->Canvas->LineTo(y,m);
	}

m =  cz * ( ThirtColor->Position );
for ( x=0; x<ColorField->Width; x++ )
	{
	for ( y=0; y<ColorField->Height; y++)
		{
		ColorField->Canvas->Pixels[x][y] = (cx * x)+(cy * y) + m;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::ColorFieldMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
//NewColor->Color = ColorField->Canvas->Pixels[X][Y];
int		r,g,b,f;

f = ColorField->Canvas->Pixels[X][Y];
NewColor->Color = f;
r = f & 0x000000ff;
g = ( f & 0x0000ff00 ) >> 8;
b = ( f & 0x00ff0000 ) >> 16;
RotEd->Text = IntToStr( r );
GruenEd->Text = IntToStr( g );
BlauEd->Text = IntToStr( b );
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::PanelClick(TObject *Sender)
{
int		r,g,b,f;

f = ((TPanel *)Sender)->Color;
NewColor->Color = f;
r = f & 0x000000ff;
g = ( f & 0x0000ff00 ) >> 8;
b = ( f & 0x00ff0000 ) >> 16;
RotEd->Text = IntToStr( r );
GruenEd->Text = IntToStr( g );
BlauEd->Text = IntToStr( b );
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::RotEdChange(TObject *Sender)
{
__int64		r,g,b,f;

r = StrToIntDef( RotEd->Text, 0 );
g = StrToIntDef( GruenEd->Text, 0 );
b = StrToIntDef( BlauEd->Text, 0 );
r = ( r > 255 )? 255 : r;
g = ( g > 255 )? 255 : g;
b = ( b > 255 )? 255 : b;

f = HelligkeitTB->Position;
r = ( r * f ) / 1000;
g = ( g * f ) / 1000;
b = ( b * f ) / 1000;
r = ( r > 255 ) ? 255 : r;
g = ( g > 255 ) ? 255 : g;
b = ( b > 255 ) ? 255 : b;

HexRotLb->Caption = IntToHex( r,2 ) + "  ( " + IntToStr( r ) + " )";
HexGr�nLb->Caption = IntToHex( g,2 ) + "  ( " + IntToStr( g ) + " )";
HexBlauLb->Caption = IntToHex( b,2 ) + "  ( " + IntToStr( b ) + " )";

g = g << 8;
b = b << 16;
f = r | g | b;
NewColor->Color = f;
}
//---------------------------------------------------------------------------


void __fastcall TColorsSelect::FormActivate(TObject *Sender)
{

isobreiteOld = StrToInt(IsoBreite->Text);
HelligkeitTB->Position = 1000;
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::FormCloseQuery(TObject *Sender,
      bool &CanClose)
{

if ( isobreiteOld > 0 )
	{
    if ( StrToInt(IsoBreite->Text) == 0 )
    	{
        IsoBreite->Text = IntToStr(isobreiteOld);
        CanClose = false;
        }
    if ( StrToInt(IsoBreite->Text) > 8000 )
    	{
        IsoBreite->Text = "8000";
        CanClose = false;
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::FarbTabNrEdKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
int		ft;

ft = FarbTabNrEd->Tag;
if ( Key == VK_DOWN ) {
	if ( ft < 0 ) ft = 0;
	else
		if ( ft < MaxTabs )
			ft += 1;
	}
if ( Key == VK_UP ) {
	if ( ft > 0 ) ft -= 1;

	}
if ( Key == VK_INSERT ) {
	ft = -1;
	FarbTabNrEd->Text = "New";
	}
if ( Key == VK_DELETE ) {
	ft = -2;
	OKBtnClick(NULL);
	return;
	}
if ( ft >= 0 ) FarbTabNrEd->Text = IntToStr(ft);
FarbTabNrEd->Tag = ft;
}
//---------------------------------------------------------------------------

void __fastcall TColorsSelect::OKBtnClick(TObject *Sender)
{
switch ( FarbTabNrEd->Tag ) {
	case -2:
				break;
	case -1:
				break;
	default:
				break;
	}
}
//---------------------------------------------------------------------------

