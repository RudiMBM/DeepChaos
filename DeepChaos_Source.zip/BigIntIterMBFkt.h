#ifndef BigIntIterH
#define BigIntIterH


#define	OBERWELLEN		10
#define TRACKLEVELS		3200  //ANZDIGITS*32

/*-----------------------------------------------------------------------------

Steuerparameter :
        bigint			*icx,*icy;			// Iteratewert f�r imagin�r C, oder JuliaPunkt
        bigint			*spx,*spy;			// Startwert f�r Standart, oder Juliakoordinaten
        unsigned		imin,imax;			// Grenzwert f�r Iterationenanzahl ( unterer und oberer )
        long double		rmax;				// Grenzwert f�r maximalen Radius
        int				emode,emodenr;		// Erzeugungsart und -nummer

Ergebnisse, je nach Mode :
        unsigned		ei;					// Ergebnis-Iterationsz�hler
        long double		er;					// Ergebnis-Radius
        bigint			ex,ey;				// Koordinaten des Ergebnisses

------------------------------------------------------------------------------*/


class bigintiter// : public bigint
{

public:
						bigintiter();

		unsigned		iterate( bigint *icx,bigint *icy,bigint *spx,bigint *spy,TDMbmParameter *parm,TDIterErgebnis *erg );
		unsigned		iterate_start( bigint *icx,bigint *icy,bigint *spx,bigint *spy,TDMbmParameter *parm,TDIterErgebnis *erg );
		unsigned		iterate_cont();
		unsigned		iterate_all();

private:
		void			iterateinit();
		unsigned		iteratenow();	// Return = Iterationsz�hler

        unsigned		ic;			  	// Iterationscounter
		bigint 			ax,ay;          // Checkpointregister
		bigint 			ax2,ay2;

};

//---------------------------------------------------------------------------
#endif
