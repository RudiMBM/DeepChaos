#ifndef StructDefsH
#define StructDefsH


//---------------------------------------------------------------------------
//      	Zwischenergebnisse bei der Iteration , zum Weiterrechnen
//---------------------------------------------------------------------------
struct		TDCheckpoint { 	int 	iterNr;
							bigint 	cpx;
							bigint 	cpy;
							bigint  cp2x;
							bigint  cp2y;
							};

//---------------------------------------------------------------------------
// 			ErgebnisDaten nach Erzeugen der gesamten MBM
//---------------------------------------------------------------------------
struct		TDMbmErgebnis {
							long double 	InnerMin,InnerMax,OuterMin,OuterMax,MbSize;
							AnsiString		Masstab;
							};
//---------------------------------------------------------------------------
// 			ErgebnisDaten nach einem eizelnen Iterationsgang
//---------------------------------------------------------------------------
struct		TDIterErgebnis {
							unsigned		ei;		 	// Ergebnis-Iterationsz�hler
					        long double		er;			// Ergebnis-Result:je nach Auswertung
							bigint			ex,ey;		// Koordinaten des Ergebnisses
							};

//---------------------------------------------------------------------------
// 			ErgebnisDaten nach einem eizelnen Iterationsgang
//---------------------------------------------------------------------------
struct		TDIterPoint 	{
							bigint			ipx,ipy;		// Koordinaten des Ergebnisses
							};

//---------------------------------------------------------------------------
//			F�r die Gr��entabelle
//---------------------------------------------------------------------------
struct		TDGroessen {
							long double		OberGrenze;
							long double		Faktor;
							int				Exp;
							char*			Bez;
							};

//---------------------------------------------------------------------------
//			F�r die Colorerzeugung
//---------------------------------------------------------------------------
struct		TDColors 	{	long			Color32;
							long			ColorBitmap;
							unsigned char	ColorB;
							unsigned char	ColorG;
							unsigned char	ColorR;
						};


struct 		TDColorTabelle {							                // Daten zum Erzeugen einer Farbe
							int 	pos;
							int		color;
							int		isobreite;
							};

struct 		TDColorBarData {							                // Daten zum Erzeugen der Colorbar
							TDColorTabelle	ColorTabelle[COLORTABS];
							__int16			ScalaLogPoint;				// Logarythmuspoint bei Tabellennummer -8191...0...+8191
							__int8         	BlendenMode;
							__int8         	LogFaktor;                  // Exponent-Faktor 0 bis 2
							long double		Level;
							long double		Scala;
							};

/*
//---------------------------------------------------------------------------
// 			Daten zum Erzeugen der gesamten MBM  ( Version 2 )
//---------------------------------------------------------------------------
struct		TDMbmParam {
							int				MaxIter;					// Anzahl - Erstellungsgrenzen
							int				VorlaufIter;            	// Vorlauf
							int				ZusatzMode;             	// "Anzeige mit:" On-Off Flags
							int 			Erstellungsdauer;       	// in Sekunden
							int				ItercountMax,ItercountMin; 	// Tats�chlich erreichte Iterationen
							int				RepeatJede;                 // Nur jede xte Iteration Zeigen
							int				frei2;
							int				frei3;
							__int16        	FertigBisX;				// Unfertig gerechnet, nur bis Koord.X  ( Y)
							__int16         FertigBisY;
							__int16			BildSizeX;				// Bildbreite in Pixel
							__int16			BildSizeY;				// Bildh�he in Pixel
							__int16			Amode;		  			// Anzeigemode
							__int16			Mmode;  				// Menge-Art
							__int16			Emode;					// Erstellungsmode
							__int16			EmodeNr;				// ErstellungsNummer f�r Auswertungart
							__int16			ErstArt;				// Erstellungsrechenart
							__int16			Rmode;					// Rechengenauigkeit in Anz Bit ( 32 Bit Steps )
							__int16			BmodeR;					// bei Ergebnisort: Referenz-Fl�che
							__int16			RelativM;				// bei Z-Absolut: 	Relativmode
							__int16			BmodeF;                 // bei Ergebnisort: Aufl�sungsfaktor  1 ... n
							__int16			BmodeB;                 // bei Ergebnisort: Bereich ( Inside-Outside-Beide )
							__int16			AFBilder;				// Anzahl Film Bilder
							__int8			BlendenMode;
							__int8			frei8;
							__int16			freii16b;
							__int16			freii16c;
							__int16			freii16d;
							bigint		 	cx,cy;			        // Bild Zentrum Koordinaten
							bigint		 	rx,ry;					// Referenz Zentrum f�r Ergebnisort
							bigint			jpx,jpy;                // Julia Punkt
							bigint			tpx,tpy;                // Test Punkt
							bigint		 	lsx,lsy;			    // Linienstartpunkt
							bigint		 	lex,ley;				// Linienendpunkt
							bigint			zcx,zcy;				// letztes Zoomcenter
							bigint			imagx,imagy;			// Imagin�rpunkt f�r grafic-Berechnung
							bigint			refpx,refpy;			// Referenzpunkt f�r Entfernungsmessung
							long double		BildSize;				// Bildbreite
							long double		ZoomSize;				// Zoombreite
							long double		RefSize;				// Referenzbildbreite
							long double 	MaxRadius;
							long double 	InnerMin,InnerMax,OuterMin,OuterMax;
							long double		MbmSize;
							long double		Zscala;					// Farbenparameter
							long double		Zlevel;
							long double		EmodeZusatz;			// Zusatzparameter f�r Auswertungart ( Grenzwert )
							long double		RefBildSV;              // ReferenzBild Seitenverh�ltnis ( x / y = RefBildSV )
							long double		freild2;
							long double		freild3;
							long double		freild4;
							bool			isCycleZoom;			// true wenn zoom is Cycle
							TDColorBarData	ColorBarData;
							Char			CTFile[80];             // Filename ColorTab
							Char			BMFile[80];             // Filename Bitmap/Jpg
							Char			RBFile[80];				// Filename Referenzbild
							};

*/
//---------------------------------------------------------------------------
//			Konstanden f�r Betriebsart
//---------------------------------------------------------------------------

//-----------------------------------------------------------------------------
#endif
