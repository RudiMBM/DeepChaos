//---------------------------------------------------------------------------

#ifndef DatenBankFormH
#define DatenBankFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TDbWd : public TForm
{
__published:	// IDE-verwaltete Komponenten
	TStatusBar *StatusBar;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);


private:	// Benutzer Deklarationen
    	String		Sf;

public:		// Benutzer Deklarationen
	__fastcall TDbWd(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDbWd *DbWd;
//---------------------------------------------------------------------------
#endif
