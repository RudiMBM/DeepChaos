#ifndef BigIntIterH
#define BigIntIterH
//---------------------------------------------------------------------------

#define	OBERWELLEN		10
#define TRACKLEVELS		3200  //ANZDIGITS*32

class		Iter_Art;

//---------------------------------------------------------------------------
/*
#define	ok         	1
#define fehler      2
#define inside      4
#define outside     8
#define outofRange  16
*/

enum	EStatus { start=0, ok=1, fehler=2, inside=4, outside=8, outofRange=16 };

class IStatus
{
public:
			int			status;

			IStatus();
			void		operator=(EStatus);
			bool		operator==(EStatus);
						operator int();
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class BigIntIter
{
public:
			friend  	Iter_Art;

            Iter_Art	*ia;
			int			Darstellung,imax,itercount;
			long double	zi, zmax;

			bigint		ex,ey;
            bigint      za,zmaxbi;
			bigint		ax,ay,cx,cy;
			bigint		ax2,ay2,r;
			bigint		PixelSizeMask;

            IStatus		iterstatus;
			TMainParams *Pm;

                        BigIntIter();
virtual                 ~BigIntIter();

			void		SetParam( TMainParams* );
virtual		IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_PreRun(int isteps);
virtual		IStatus		iterate_run(int isteps);

private:

};
//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Apfelmaennchen : public BigIntIter
{
public:
						Apfelmaennchen();
						~Apfelmaennchen();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

						bigint		bmin,bminz;
private:

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Bubblebrot : public BigIntIter
{
public:
						Bubblebrot();
						~Bubblebrot();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			bigint		bmin,bminz;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MinCount : public BigIntIter
{
public:
						MinCount();
						~MinCount();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			bigint		bmin,bminz;
			int			isum;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Cyclebrot : public BigIntIter
{
public:
						Cyclebrot();
						~Cyclebrot();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			bigint		bmin,bminz,messradius;
            int			repeat;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Runout : public BigIntIter
{
public:
						Runout();
						~Runout();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			bigint		bmin,bminz;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class LastPeak : public BigIntIter
{
public:
						LastPeak();
						~LastPeak();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			bigint		bmin,bminz,bmax;
			int			bmaxi;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Lotusbrot : public BigIntIter
{
public:
						Lotusbrot();
						~Lotusbrot();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);
            int			Raster;
            long double	RasterSize;

            __int16		levels[16000];					

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class CenterOfOrbit : public BigIntIter
{
public:
						CenterOfOrbit();
						~CenterOfOrbit();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
			bigint		xc,yc,xct,yct,bmin;     	// f�r berechnung Center
            int			bmin_nr,iscan;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class SizeOfOrbit : public BigIntIter
{
public:
						SizeOfOrbit();
						~SizeOfOrbit();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
			long double	xmin,xmax,ymin,ymax;		// f�r berechnung size
            int			bmin_nr;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Mindiff : public BigIntIter
{
public:
						Mindiff();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
			bigint		bmin[2];
            int			imin[2];

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Pabw : public BigIntIter
{
protected:
			long double	bmin[3];
            int			imin[3];

public:
						Pabw();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Zmindiff : public BigIntIter
{
protected:
			bigint		bmin[2];
            int			imin[2];

public:
						Zmindiff();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class ZyclusIter : public BigIntIter
{
protected:

public:
						ZyclusIter();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
			int			bmin[2];
            int			imin[2];

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Zyclus : public BigIntIter
{
protected:

public:
						Zyclus();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Grenzzyclus : public BigIntIter
{
public:
						Grenzzyclus( int mi );
						~Grenzzyclus();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			long        *spur,thisspur;
            bigint      LastIterRx,LastIterRy,LastIterRz;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class MinSwingIn : public BigIntIter
{
public:
//						MinSwingIn( int mi );
						MinSwingIn( );
						~MinSwingIn();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

			long        *spur,thisspur;
            bigint      LastIterR2,LastIterR3;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

#define		SEEKTOPSSIZE	20

class SeekTops : public BigIntIter
{
public:
						SeekTops();
						~SeekTops();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

						bigint		bmin,bminz;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Actiondetect : public BigIntIter
{
public:
						Actiondetect();
						~Actiondetect();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
            bigint		lastx,lasty,lastz,oben,unten,obenmax,klein;
            int			verlauf,itermax;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class StartPointDiffergent : public BigIntIter
{
public:
						StartPointDiffergent();
						~StartPointDiffergent();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
            long double		xf,yf,ra,fb;
            bigint			r05;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class AereaOfOrbit : public BigIntIter
{
public:
						AereaOfOrbit();
						~AereaOfOrbit();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
        	unsigned	*aerea;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class SternSeek : public BigIntIter
{
public:
						SternSeek();
						~SternSeek();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
			bigint		xc,yc;						// f�r berechnung Center
            long double	xp[360],yp[360];			// positionen f�r jede Iteration
			short		w[630];
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Steigung : public BigIntIter
{
public:
						Steigung();
						~Steigung();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
            bigint      bmin,bup,bdown,bdownlast,b1,b2;
            int         imin,iup,idown;
            long double epsilon;

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class SteigungPeriode : public BigIntIter
{
public:
						SteigungPeriode();
						~SteigungPeriode();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);
private:
            bigint      bmin,bup,bdown;
            int         imin,iup,idown;
            int         pernr;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class FirstIter : public BigIntIter
{
public:
						FirstIter();
						~FirstIter();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

            bigint		z1,z2;

private:

};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class EWeg : public BigIntIter
{
public:
						EWeg();
						~EWeg();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
            bigint		lastx,lasty;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------

class Grundwelle : public BigIntIter
{
public:
						Grundwelle();
						~Grundwelle();

			IStatus		iterate_start(bigint aix, bigint aiy, bigint cix, bigint ciy, int imaxi, long double zmaxi, int ModeNr, long double ModeZs);
			IStatus		iterate_run(int isteps);

private:
            bigint      ra[5],rb[5],rc[5];
            int         icb[5],gwnr;
};

//------------------------------------------------------------------------------------------------------------------------------------------------------
//######################################################################################################################################################
//------------------------------------------------------------------------------------------------------------------------------------------------------
#endif
