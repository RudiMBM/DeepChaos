//----------------------------------------------------------------------------
#ifndef DCMAINH
#define DCMAINH
//----------------------------------------------------------------------------
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <StdCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <Controls.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <Classes.hpp>
#include <Windows.hpp>
#include <System.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include "LMDBaseEdit.hpp"
#include "LMDControl.hpp"
#include "LMDCustomBevelPanel.hpp"
#include "LMDCustomControl.hpp"
#include "LMDCustomEdit.hpp"
#include "LMDCustomMaskEdit.hpp"
#include "LMDCustomPanel.hpp"
#include "LMDMaskEdit.hpp"
#include "LMDEdit.hpp"
#include "LMDComboBox.hpp"
#include "LMDCustomComboBox.hpp"
#include "LMDThemedComboBox.hpp"
#include "LMDCustomExtSpinEdit.hpp"
#include "LMDSpinEdit.hpp"
//#include "LMDBiTrackBar.hpp"
//#include "LMDCustomBiTrackBar.hpp"
//#include "LMDCustomTrackBar.hpp"
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
class TDCWd : public TForm
{
__published:
    TImageList *ImageList1;
	TMainMenu *MainMenu;
	TMenuItem *DateiMenu;
    TMenuItem *FileOpenItem;
	TMenuItem *SaveMenu;
	TMenuItem *SaveAsMenu;
	TMenuItem *N1;
	TMenuItem *QuitMenu;
	TMenuItem *BearbeitenMenu;
	TMenuItem *HelpMenu;
    TMenuItem *HelpAboutItem;
	TPanel *TopP;
	TScrollBar *DCScrollbar;
	TPanel *ScrollP;
	TPanel *EDP;
	TPanel *ALP;
	TPanel *CSP;
	TPanel *StatistikP;
	TPanel *BLP;
	TMenuItem *FensterMenu;
	TMenuItem *Bild1Menu;
	TMenuItem *Bild2Menu;
	TMenuItem *Bild3Menu;
	TLabel *EDH;
	TLabel *Label2;
	TLabel *CSH;
	TLabel *Label4;
	TLabel *Label5;
	TPanel *AMP;
	TLabel *Label1;
	TPanel *DPP;
	TLabel *Label3;
	TLMDEdit *RealXEd;
	TLabel *Label6;
	TLabel *Label7;
	TLMDEdit *ImagYEd;
	TLabel *Label8;
	TLabel *Label9;
	TLMDEdit *CursYEd;
	TLabel *Label11;
	TLMDEdit *REd;
	TLabel *Label12;
	TLMDEdit *ArgEd;
	TLabel *Label13;
	TLMDEdit *CPosXEd;
	TLabel *Label14;
	TLMDEdit *CPosYEd;
	TLabel *Label15;
	TLabel *Label16;
	TLMDEdit *TpYEd;
	TLabel *Label17;
	TLMDEdit *ColorNrEd;
	TLMDComboBox *EmodeCb;
	TLMDComboBox *AmodeCb;
	TLMDComboBox *ErstArtCB;
	TLabel *Label18;
	TLabel *Label19;
	TLabel *Label20;
	TLabel *Label21;
	TLabel *Label22;
	TLMDComboBox *MmodeEd;
	TLabel *Label29;
	TLMDSpinEdit *VorlaufIterEd;
	TLMDSpinEdit *MaxIterEd;
	TLabel *Label30;
	TLabel *Label31;
	TMenuItem *Bild4Menu;
	TLMDSpinEdit *RmodeCB;
	TMenuItem *ZeitreihenAnalyse1;
	TMenuItem *Datenbank1;
	TStatusBar *StatusBar;
	TMenuItem *TcMenue;
	TLabel *Label33;
	TLMDEdit *ErgebnisEd;
	TLabel *Label34;
	TLMDEdit *BlendeMinEd;
	TLabel *Label35;
	TLMDEdit *BlendeMaxEd;
	TComboBox *BlendenModeCb;
	TLabel *Label36;
	TLabel *Label40;
	TLabel *Label41;
	TLMDEdit *DatenBankPfEd;
	TLabel *Label42;
	TLabel *Label43;
	TLMDEdit *FarbPalettenPfEd;
	TLMDEdit *PfadEd;
	TLabel *Label44;
	TLMDEdit *MinIterAnzEd;
	TLabel *Label45;
	TLMDEdit *MaxIterAnzEd;
	TLabel *Label46;
	TLMDEdit *MinErgAnzEd;
	TLabel *Label47;
	TLMDEdit *MaxErgAnzEd;
	TLabel *Label49;
	TLMDEdit *AmSizeEd;
	TLabel *Label50;
	TLMDEdit *ErstellDauerEd;
	TLabel *Label48;
	TLMDEdit *BildSizeEd;
	TPanel *OPP;
	TLabel *Label51;
	TPanel *EndP;
	TPanel *EDPi;
	TLabel *Label67;
	TLabel *Label68;
	TLabel *Label69;
	TLMDEdit *ImagpXEd;
	TLMDEdit *ImagpYEd;
	TPanel *EDPr;
	TLabel *Referenz;
	TLabel *Label38;
	TLabel *Label39;
	TLMDEdit *RefBildXEd;
	TLMDEdit *RefBildYEd;
	TLabel *Label37;
	TLMDEdit *RefBildSizeEd;
	TLabel *Label53;
	TLMDEdit *ReferenzDateiED;
	TLabel *Label54;
	TLMDEdit *FensterEd;
	TPanel *EDPj;
	TLabel *Label56;
	TLabel *Label57;
	TLMDEdit *JpXEd;
	TLMDEdit *JpYEd;
	TLabel *Label23;
	TPanel *EDPl;
	TLabel *Label24;
	TLabel *Label25;
	TLabel *Label55;
	TLMDEdit *StartXEd;
	TLMDEdit *StartYEd;
	TLabel *Label58;
	TLabel *Label59;
	TLabel *Label60;
	TLMDEdit *EndYEd;
	TLMDEdit *EndXEd;
	TPanel *ColorNrP;
	TLabel *Label61;
	TLMDEdit *HistEd;
	TLMDEdit *CursXEd;
	TGroupBox *GroupBox1;
	TCheckBox *AmKoordinaten;
	TCheckBox *AmSternenhimmel;
	TCheckBox *AmJuliapunkt;
	TCheckBox *AmTestpunkt;
	TCheckBox *AmZoomrahmen;
	TCheckBox *AmImaginaerpunkt;
	TCheckBox *AmLinie;
	TLabel *NrLabel;
	TLabel *Label32;
	TLabel *Label62;
	TLMDComboBox *ReferenzMengeCb;
	TLabel *BubblebrotPraezLb;
	TLMDSpinEdit *BubblebrotPraezEd;
	TLabel *Label64;
	TLMDComboBox *BubblebrotBerCB;
	TLMDEdit *MaxRadiusEd;
	TLMDEdit *ErstellungsmodeZusatzEd;
	TMenuItem *Phasenraum1;
	TMenuItem *OrbitanalyseMenu;
	TMenuItem *PunkteMenu;
	TMenuItem *PunkteSubMenu2;
	TMenuItem *Ladenvon2;
	TMenuItem *Bild1Mi;
	TMenuItem *Bild2;
	TMenuItem *Bild3;
	TMenuItem *Bild4;
	TMenuItem *Orbitanalyse2;
	TMenuItem *Datenbank3;
	TMenuItem *Setzen2;
	TMenuItem *N00real00imag2;
	TMenuItem *ManEingabeMnu;
	TMenuItem *PunkteSubMenu3;
	TMenuItem *Ladenvon3;
	TMenuItem *Bild5;
	TMenuItem *Bild6;
	TMenuItem *Bild7;
	TMenuItem *Bild8;
	TMenuItem *Orbitanalyse3;
	TMenuItem *Datenbank4;
	TMenuItem *Setzen3;
	TMenuItem *N00real00imag3;
	TMenuItem *N10real00imag3;
	TMenuItem *PunkteSubMenu4;
	TMenuItem *Ladenvon4;
	TMenuItem *Bild9;
	TMenuItem *Bild10;
	TMenuItem *Bild12;
	TMenuItem *Bild13;
	TMenuItem *Orbitanalyse4;
	TMenuItem *Datenbank5;
	TMenuItem *Setzen4;
	TMenuItem *N00real00imag4;
	TMenuItem *N10real00imag4;
	TMenuItem *PunkteSubMenu5;
	TMenuItem *Ladenvon5;
	TMenuItem *Bild14;
	TMenuItem *Bild15;
	TMenuItem *Bild16;
	TMenuItem *Bild17;
	TMenuItem *Orbitanalyse5;
	TMenuItem *Datenbank6;
	TMenuItem *Setzen5;
	TMenuItem *N00real00imag5;
	TMenuItem *N10real00imag5;
	TMenuItem *PunkteSubMenu6;
	TMenuItem *Ladenvon6;
	TMenuItem *Bild18;
	TMenuItem *Bild19;
	TMenuItem *Bild20;
	TMenuItem *Bild22;
	TMenuItem *Orbitanalyse6;
	TMenuItem *Datenbank7;
	TMenuItem *Setzen6;
	TMenuItem *N00real00imag6;
	TMenuItem *N10real00imag6;
	TMenuItem *Position2;
	TMenuItem *alsNeuindieDB1;
	TMenuItem *UpdateaktDBSatz1;
	TMenuItem *OptionenMenu;
	TMenuItem *ParameterMenu;
	TMenuItem *vonBild11;
	TMenuItem *vonBild21;
	TMenuItem *vonBild31;
	TMenuItem *vonBild41;
	TMenuItem *vonderDB1;
	TMenuItem *NeuBerechnenMi;
	TMenuItem *ZoomBerechnenMi;
	TMenuItem *NeuZeichnenMi;
	TMenuItem *VomCursor1;
	TCheckBox *AmBildCenter;
	TCheckBox *AmReferenzpunkt;
	TLMDSpinEdit *ErstellungsmodeNummerEd;
	TLMDEdit *RefPyEd;
	TLMDEdit *DistEd;
	TLabel *Label66;
	TLabel *Label70;
	TLabel *Label71;
	TLMDEdit *RefPxEd;
	TToolBar *MainTb;
	TToolButton *ToolButton14;
	TToolButton *Datei_Tb;
	TToolButton *BearbTb;
	TToolButton *ParamTb;
	TToolButton *PunkteTb;
	TToolButton *OptionenTb;
	TToolButton *FensterTb;
	TToolButton *HelpTb;
	TMenuItem *ColorierenMi;
	TMenuItem *VolleGroesseMi;
	TToolButton *ToolButton16;
	TMenuItem *ZoomeinrichtenMi;
	TToolButton *Bild1Tb;
	TToolButton *Bild4Tb;
	TToolButton *Bild2Tb;
	TToolButton *OrbTb;
	TToolButton *DbTb;
	TToolButton *ZrTb;
	TToolButton *PhaseTb;
	TToolButton *Bild3Tb;
	TToolButton *ToolButton34;
	TToolButton *ToolButton1;
	TMenuItem *CycleZoomMi;
	TMenuItem *Wo1;
	TMenuItem *Bild11;
	TMenuItem *Bild21;
	TMenuItem *Bild31;
	TMenuItem *Bild41;
	TMenuItem *Orbitanalyse1;
	TMenuItem *Testpunkt1;
	TMenuItem *Referenzpunkt1;
	TMenuItem *aktDatenbank1;
	TMenuItem *Bild110;
	TMenuItem *Bild23;
	TMenuItem *Bild32;
	TMenuItem *Bild42;
	TToolButton *WoTb;
	TMenuItem *groesstesErgebnis1;
	TComboBox *ZAuswertungCB;
	TMenuItem *vonOrbitWd;
	TMenuItem *vomCursor2;
	TMenuItem *vomCursor3;
	TMenuItem *vomCursor4;
	TMenuItem *Anschlussbild1;
	TMenuItem *BildOben1;
	TMenuItem *BildRechts1;
	TMenuItem *BildUnten1;
	TMenuItem *BildLinks1;
	TOpenDialog *OpenRefFile;
	TLabel *Label10;
	TMenuItem *dDateiMenu;
	TMenuItem *BildOpenMi;
	TMenuItem *BeendenMi;
	TMenuItem *Referenzpunkt2;
	TMenuItem *Center1;
	TMenuItem *ZoomladenMi;
	TMenuItem *Bild111;
	TMenuItem *Bild24;
	TMenuItem *Bild33;
	TMenuItem *Bild43;
	TMenuItem *Bildcenterladen1;
	TMenuItem *TestpunktMi1;
	TButton *TestiterBt;
	TLMDEdit *DistFpEd;
	TLabel *Label26;
	TLabel *ImagPktAllertLb;
	TLMDSpinEdit *SpeedEd;
	TLMDSpinEdit *BeschleunigungEd;
	TLabel *Label27;
	TLabel *Label28;
	TSpeedButton *AnimProgBtn;
	TLMDEdit *ToleranzEd;
	TLabel *Label63;
	TLMDComboBox *BilderPfEd;
	TLMDComboBox *OptionenCb;
	TLabel *Label65;
	TPanel *SZP;
	TLabel *Label72;
	TLMDSpinEdit *CoresCountEd;
	TLabel *Label74;
	TLabel *Label75;
	TLMDEdit *ToleranzWinkelEd;
	TLabel *Label76;
	TLMDEdit *ArgumentRpTpEd;
	TMenuItem *vomCursor5;
	TMenuItem *LadenVon1;
	TMenuItem *Setzen1;
	TMenuItem *N00real00imag1;
	TLMDEdit *TpXEd;
	TMenuItem *BildO3;
	TCheckBox *OversampleChk;
	TLMDSpinEdit *PfadNummerEd;
	TLabel *Label52;
	void __fastcall QuitNow(TObject *Sender);
    void __fastcall HelpAbout1Execute(TObject *Sender);
	void __fastcall PanelOpenClick(TObject *Sender);
	void __fastcall DCScrollbarChange(TObject *Sender);
	void __fastcall PanelDragOver(TObject *Sender, TObject *Source, int X, int Y, TDragState State, bool &Accept);
	void __fastcall PanelEndDrag(TObject *Sender, TObject *Target, int X, int Y);
	void __fastcall BildBtClick(TObject *Sender);
	void __fastcall ZrTbClick(TObject *Sender);
	void __fastcall showHelpTbtClick(TObject *Sender);
	void __fastcall ErstArtCBChange(TObject *Sender);
	void __fastcall DbTbClick(TObject *Sender);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall PhasenraumBtClick(TObject *Sender);
	void __fastcall OaTbClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall DisplMbmEdit( );
	void __fastcall AnzeigeChange(TObject *Sender);
	bool __fastcall GetEditParameter( );
	bool __fastcall GetZeichnenParameter( );
	void __fastcall BlendenModeCbChange(TObject *Sender);
	void __fastcall NeuZeichnenBtnClick(TObject *Sender);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall ComputeDistanz(TObject *Sender);
	void __fastcall FormDeactivate(TObject *Sender);
	void __fastcall MitOptionClick(TObject *Sender);
	void __fastcall BildMenuClick(TObject *Sender);
	void __fastcall KommandoMenuClick(TObject *Sender);
	void __fastcall TestiterBtClick(TObject *Sender);
	void __fastcall EmodeCbChange(TObject *Sender);
	void __fastcall ReferenzDateiEDCustomButtons0Click(TObject *Sender, int index);
	void __fastcall RmodeCBChange(TObject *Sender);
	void __fastcall FileOpenItemClick(TObject *Sender);
	void __fastcall DateiMenuClick(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall DisplayHint(TObject *Sender);
	void __fastcall AnimProgBtnClick(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall FarbPalettenPfEdAfterExit(TObject *Sender);
	void __fastcall ReferenzDateiEDAfterExit(TObject *Sender);


private:
	void	 	__fastcall BildLoading();

	TToolButton		*BildTbA[BildWdMaxNr];
	String			BildNamen[BildWdMaxNr];
	TPanel			*Pp[14];
	TMainParams		dcwparam;
	void 		__fastcall FlagsAnzeige( TCheckBox*, bool );

public:
	virtual 	__fastcall TDCWd(TComponent *AOwner);
	bool	 	__fastcall BildShow(int bn);
	void	 	__fastcall BildNeu(int bn);
	void	 	__fastcall BildClose(int bn);
	void 		__fastcall StatusAnzeige( );

	TBildWd			*BildWdTab[BildWdMaxNr];				// 0 = OrbitWd
	TBildWd			*AktivesBild;
	TBildWd			*AktivesFenster;
	TBildWd			*MenueFenster;
	TOrbitWd		*OrbitWd;
	int				SelectedWdNr;
	TLMDEdit*		BigIntEd[AnzBigInts];

	TCustomIniFile* SettingsFile;
	String			Sftemp;							// tempor�rer Settingsfilename f�r Abholung durch andere Fenster

	int				schrott;
};
//----------------------------------------------------------------------------
extern PACKAGE TDCWd *DCWd;
//----------------------------------------------------------------------------
#endif
