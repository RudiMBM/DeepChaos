//---------------------------------------------------------------------------

#ifndef BildFormH
#define BildFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include "LMDBaseEdit.hpp"
#include "LMDControl.hpp"
#include "LMDCustomBevelPanel.hpp"
#include "LMDCustomControl.hpp"
#include "LMDCustomEdit.hpp"
#include "LMDCustomExtSpinEdit.hpp"
#include "LMDCustomMaskEdit.hpp"
#include "LMDCustomPanel.hpp"
#include "LMDSpinEdit.hpp"
#include <Menus.hpp>
#include <ToolWin.hpp>

//---------------------------------------------------------------------------

class TZoom
{
public:
		int			cx,cy,Breite;
		bool		Cycle;

					TZoom();
					TZoom(int,int,int);
		void   		NewPos(int x, int y);
		void   		NewWidth(int);
		void 		WidthChange(int hc);
					operator TRect();

private:
		int			h2,w3,win;
		int			mode;				// 0=Rechteck     1=Kreis
};

//---------------------------------------------------------------------------
class TBildKoo
{
public:
		bigint		cxl,cxr,cyt,cyb;

					TBildKoo();
		void		Set(TMainParams*);
		bool		IsInside(TMainParams*);
		bool		IsInside(bigint *x, bigint *y);
		bool		XInside(bigint *x);
		bool		YInside(bigint *y);
		int			X(bigint &x);
		int			Y(bigint &y);
		long double	Xd(bigint &x);
		long double	Yd(bigint &y);
		long double	Xd(int x);
		long double	Yd(int y);
		long double	Xd(long double x);
		long double	Yd(long double y);
		int			X(long double x);
		int			Y(long double y);
		bigint		X(int x);
		bigint		Y(int y);
		long double PixelAbstand( int x );
		int  		PixelAbstand( long double dx );

private:
		bigint		delta;
		long double deltad;
		TMainParams	*pl;
};

//---------------------------------------------------------------------------
class TBildWd : public TForm
{

__published:	// IDE-verwaltete Komponenten
	TPanel *BildSizeP;
	TLabel *Label1;
	TListBox *BildSizeLb;
	TButton *GoBtn;
	TStatusBar *StatusBar;
	TPanel *AnzP;
	TImage *BildIm;
	TTimer *Timer1;
	TSavePictureDialog *SaveDlg;
	TOpenDialog *OpenDlg;
	TToolBar *BWdTbar;
	TToolButton *D_Tb;
	TToolButton *B_Tb;
	TToolButton *P_Tb;
	TToolButton *Pkt_Tb;
	TToolButton *O_Tb;
	TToolButton *F_Tb;
	TToolButton *ToolButton9;
	TToolButton *ToolButton10;
	TToolButton *rTb;
	TToolButton *zTb;
	TToolButton *iTb;
	TToolButton *StopTb;
	TToolButton *ToolButton1;
	TToolButton *W_Tb;
	TLMDSpinEdit *BildxEd;
	TLMDSpinEdit *BildyEd;
	void __fastcall GoBtnClick(TObject *Sender);
	void __fastcall BildImMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall BildImMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,int X, int Y);
	void __fastcall StatusBarDrawPanel(TStatusBar *StatusBar, TStatusPanel *Panel, const TRect &Rect);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall BildSizeLbClick(TObject *Sender);
	void __fastcall SpeichernAs(TObject *Sender);
	void __fastcall DateiOeffnen(TObject *Sender);
	void __fastcall BildImMouseEnter(TObject *Sender);
	void __fastcall FormDeactivate(TObject *Sender);
	void __fastcall KommandoTbClick(TObject *Sender);
	void __fastcall StopTbClick(TObject *Sender);
	void __fastcall rTbClick(TObject *Sender);
	void __fastcall zTbClick(TObject *Sender);
	void __fastcall iTbClick(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall FormShow(TObject *Sender);

public:		// Benutzer Deklarationen
		TColorBarWd *ColorBarWd;

			 __fastcall TBildWd(TComponent* Owner);
		void __fastcall NeuZoom();
virtual	void __fastcall NeuZeichnen();
		void 			RefreshAnzeige( int );
virtual	void __fastcall NeuRechnen( bool );
virtual	void __fastcall GetBlende();
		void __fastcall	FormKeyNow( WORD &Key );
virtual	void __fastcall GoBtnNow();
virtual	void __fastcall GoBtnNow2();
		void __fastcall ReadLastSession();
		void __fastcall KommandoSend( String );
		void __fastcall PaintKoordinaten();

					int					WdNr;
					bool				Bildgerechnet;                  // ist ein berechnetes Bild im Ergebnis
					bool				GoIsDone,BerechnenLaeuft;
					TMainParams			Params;
					TBildKoo			BildKoo;							// Bildkoordinaten
					int					ErgebnisSize;
					long double			*Ergebnis;
					MbmAnz				*Anzeige;

					int					Auswertungsliste[D_Max_Anzahl];
					TStringList			*D_Namen;

					TStatusPanel 		*Statusp1,*Statusp2,*Statusp0;
					String				Sf;								// Settingsfile Parameter
					String				WorkingFile;
					TStringList 		*zrdSL;


typedef		void  ( __closure *ZusatzAnzeige)();
					ZusatzAnzeige  		ZusatzAnzeigeTab[32];

protected:
					Graphics::TBitmap	*ImageBitmap;
					bigint				CursorXbi,CursorYbi;				// Koordinaten am Cursor
					bigint				SaveXbi,SaveYbi;					// Wiederherstellung nach ESC
					long double			SaveZoomSize;
					bool				SaveZoomCycle;

private:	// Benutzer Deklarationen
	void __fastcall PaintFk(int x, int y, TColor pc);
	void __fastcall PaintLine(bigint *xs, bigint *ys, bigint *xe, bigint *ye);
	bool __fastcall TextDateiWrite( UnicodeString );
	void __fastcall SpeichernZsa( String Filebez );

	void  DateiKeyDown(WORD &Key);				// Funktionen f�r Tastenerkennung
	void  ParamKeyDown(WORD &Key);
	void  PunktKeyDown(WORD &Key);
	void  CursorKeyDown(WORD &Key);
	void  GetKeyDown(WORD &Key);
	void  ZoomKeyDown(WORD &Key);
	void  SetFromPunktKey( WORD &Key);
	void  WhereIsKeyDown(WORD &Key);
	void  NoKeyDown(WORD &Key);
	void  OptionKeyDown( WORD &Key);
	void  AnzMitKeyDown( WORD &Key);
	void  ( __closure *CommandKD)(WORD &Key);
	bool  ZeichneKoordinaten( bigint *xbi, bigint *ybi, TColor c );
	bool  ZeichneBildKoo( TBildKoo *bk, TColor c );

	void __fastcall BildImCursorMove(int X, int Y, WORD Key);

	Char		CommandKey,FktKey,OptKey;
	int			bildsizex,bildsizey;			// Bildsize im Bitmap
	int			Bezierpx,Bezierpy;
	int			cx,cy,cs;                       // Koordinaten f�r Punkte und Size f�r Zoom
	bigint		*pktx,*pkty;                    // Zeiger auf ausgew�hlten Punkt
	TLMDEdit	*pktxEd,*pktyEd;				// oben zugeh�riges Editfeld
	TZoom		zoomrahmen;
	int			ZusatzModeTemp;


							long double			*ErgebnisA;			// F�r "Compare Versuche zB: a - b = Erg.
							long double			*ErgebnisB;        	// F�r "Compare Versuche zB: a - b = Erg.
							Graphics::TBitmap	*HmbmBitmap;		// hinterlegte MBM

	void   ShowKoordinaten();
	void   ShowAnsicht();
	void   ShowSternenhimmel();
	void   ShowJuliapunkt();
	void   ShowTestpunkt();
	void   ShowHinterlegteMBM();
	void   ShowZoomrahmen();
	void   ShowIterNrOrt();
	void   ShowCenterOfOrbit();
	void   ShowImaginaerpunkt();
	void   ShowMinZ();
	void   ShowOrbitLinien();
	void   ShowBildCenter();
	void   ShowLinie();
	void   ShowLinienStart();
	void   ShowLinienEnd();
	void   ShowReferenzpunkt();
	void   ShowFirstIter();
    void   ShowBezierVector();
};
//---------------------------------------------------------------------------
//extern PACKAGE TBildFormF *BildFormF;
//---------------------------------------------------------------------------
#endif
