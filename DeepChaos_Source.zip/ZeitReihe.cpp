//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "string.h"
#include "Global.h"
#include "Bigint.h"
#include "StructDefs.h"
#include "Params.h"
#include "ColorBar.h"
#include "BigIntIter.h"
#include "MbmAnz.h"
#include "OrbitAnalyse.h"
#include "ZeitReihe.h"
#include "BildForm.h"
#include "DCMAIN.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "LMDBaseEdit"
#pragma link "LMDControl"
#pragma link "LMDCustomBevelPanel"
#pragma link "LMDCustomControl"
#pragma link "LMDCustomEdit"
#pragma link "LMDCustomPanel"
#pragma link "LMDEdit"
#pragma link "LMDCustomExtSpinEdit"
#pragma link "LMDCustomMaskEdit"
#pragma link "LMDSpinEdit"
#pragma resource "*.dfm"

#define SBHFaktor 100

TZeitRWd *ZeitRWd;
//---------------------------------------------------------------------------

TBildV::TBildV()
{

VTop = 2.1;
VBottom = -0.1;
SetHeight( 200 );
}

void	TBildV::SetHeight( int bh )
{

BildHeight = bh;
delta = VTop;
delta -= VBottom;
delta /= BildHeight;
deltad = delta;
}

void   	TBildV::SetMin( bigint *min )
{

VBottom = *min;
SetHeight( BildHeight );
}

void   	TBildV::SetMax( bigint *max )
{

VTop = *max;
SetHeight( BildHeight );
}

bigint	TBildV::P( int mpos)
{
bigint	b;

b = delta;
b *= mpos;
return ( VTop - b );
}

int	   	TBildV::Y( bigint *val )
{
long double d;

d = ( VTop - *val );
d /= deltad;
if ( d > BildHeight ) d = BildHeight - 1;
if ( d < 0 ) d = 0;
return d;
}

double	   	TBildV::Yd( bigint *val )
{
long double d;

d = ( VTop - *val );
d /= deltad;
if ( d > BildHeight ) d = BildHeight - 1;
if ( d < 0 ) d = 0;
return d;
}

bool   TBildV::isinside( bigint *val )
{
if ( *val < VBottom ) return false;
if ( *val > VTop ) return false;
return true;
}

bigint	   	TBildV::Y( int mpos )
{
bigint i;
i = delta;
i *= ( BildHeight - mpos );
i += VBottom;
return i;
}

//---------------------------------------------------------------------------

TBildX::TBildX()
{
BildWidth = 550;
SetMinMax( 0, 110 );
}

void	TBildX::SetWidth( int w)
{
BildWidth = w;
MpDist = BildWidth;
MpDist /= ( Xright - Xleft );
IAbstand = MpDist;
Ia2 = IAbstand / 2;
}

void	TBildX::SetMinMax( int v, int b )
{

Xleft = v;
Xright = b;
if ( ( Xright - Xleft ) < 10 ) Xright = Xleft + 10;
MpDist = BildWidth;
MpDist /= ( Xright - Xleft );
IAbstand = MpDist;
Ia2 = IAbstand / 2;
IterPdiv = ( Xright - Xleft ) / 100;
if ( IterPdiv < 1 ) IterPdiv = 1;
IterPdiv *= 10;
}

int	   	TBildX::DivX( int nr )
{
int    		r;
long double	x;

if ( nr < 1 ) return 0;
r = IterPdiv - ( Xleft % IterPdiv );
x = IterPdiv * ( nr - 1 );
x += r;
x *= MpDist;
return x;
}

int	   	TBildX::DivI( int nr )
{
int    		r,x;

if ( nr < 1 ) return Xleft;
r = IterPdiv - ( Xleft % IterPdiv );
x = IterPdiv * ( nr - 1 );
x += Xleft;
x += r;
return x;
}

bool	TBildX::isinside( int xpos )
{
if ( xpos < 0 ) return false;
if ( xpos >= BildWidth ) return false;
return true;
}

int		TBildX::I( int iternr )
{
long double d;

d = ( iternr - Xleft );
d *= MpDist;
return d;
}

double		TBildX::Id( int iternr )
{
long double d;

d = ( iternr - Xleft );
d *= MpDist;
return d;
}

int	   	TBildX::Ivon( int mpos )
{
long double	d;

d = mpos;
d /= MpDist;
d += 0.5;
d += Xleft;
return d;
}

int	   	TBildX::Ibis( int mpos )
{
long double	d;

d = mpos;
d /= MpDist;
d += 0.5;
d += 1.0 / MpDist;
d += Xleft;
return d;
}

//---------------------------------------------------------------------------
__fastcall TZeitRWd::TZeitRWd(TComponent* Owner)
	: TForm(Owner)
{
bigint	b;

Sf = "ZeitReihenWindow";

PreImageBitmap = new Graphics::TBitmap();
PreImageBitmap->PixelFormat = pf32bit;
PreImageBitmap->Height = ZrIm->Height;
PreImageBitmap->Width = ZrIm->Width;
ZrC = ZrIm->Picture->Bitmap->Canvas;
PiC = PreImageBitmap->Canvas;

Statusp0 = StatusBar->Panels->Items[0];
Statusp1 = StatusBar->Panels->Items[1];
Statusp2 = StatusBar->Panels->Items[2];

zoomrahmen.Left = 0;
zoomrahmen.Top = 0;
zoomrahmen.Bottom = ZrIm->Height;
zoomrahmen.Right = ZrIm->Width;
CommandKey = 0;
CommandKD = &NoKeyDown;

K0 = 0.0;
K05 = 0.5;
K1 = 1.0;
K2 = 2.0;
Km01 = -0.1;
Km05 = -0.5;
Km1 = -1.0;
Km2 = -2.0;
Kx[0] = &K0;
Kx[1] = &Km2;
Kx[2] = &Km1;
Kx[3] = &Km05;
Kx[4] = &K05;
Kx[5] = &K1;
Kx[6] = &K2;
BildX.SetWidth( ZrIm->Width );
IterAbEd->LineSize = BildX.IterPdiv;
IterBisEd->LineSize = BildX.IterPdiv;
BildX.SetMinMax ( IterAbEd->Value, IterBisEd->Value );
b.str2bigint( ObenGrenzeEd );
	BildV.SetMax( &b );
b.str2bigint( UntenGrenzeEd );
	BildV.SetMin( &b );
IterTestLinie = 0;
LastMaxIter = 200;
warschon = false;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormActivate(TObject *Sender)
{

if ( !warschon )
	{
	Top = DCWd->SettingsFile->ReadInteger(Sf, "Top", 0 );
	Left = DCWd->SettingsFile->ReadInteger(Sf, "Left", 0 );
	Width = DCWd->SettingsFile->ReadInteger(Sf, "Width", Constraints->MinWidth );
	Height = DCWd->SettingsFile->ReadInteger(Sf, "Heigth", Constraints->MinHeight );
	}
warschon = true;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormClose(TObject *Sender, TCloseAction &Action)
{

DCWd->SettingsFile->WriteInteger(Sf, "Top", Top );
DCWd->SettingsFile->WriteInteger(Sf, "Left", Left );
DCWd->SettingsFile->WriteInteger(Sf, "Width", Width );
DCWd->SettingsFile->WriteInteger(Sf, "Heigth", Height );

delete PreImageBitmap;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormPaint(TObject *Sender)
{

switch ( CommandKey )
	{
	case comZoom:	PaintZoom( zoomrahmen );		break;
	}
}
//---------------------------------------------------------------------------
void __fastcall TZeitRWd::PaintNow(TObject *Sender)
{
int			i,ip;
long double id;
int			FontSize = 12;    				// Schriftgr��e in Pixel
double		xd,yd,xt,yt;

ZrC->Brush->Color = clWhite;    //clBlack;
ZrC->Pen->Color = clBlack;
ZrC->Pen->Width = 2;
ZrC->Pen->Style = psSolid;
ZrC->FillRect(ZrC->ClipRect);
ZrC->Rectangle(ZrC->ClipRect);
BildV.VTop.bigint2str(ObenGrenzeEd,false);
BildV.VBottom.bigint2str(UntenGrenzeEd,false);
MessLinie.bigint2str(MessLinieEd,false);
ZrC->Pen->Width = 1;
for ( i=0; i<KxAnz; i++ )								// Pegel Zeichnen
	{
	if ( BildV.isinside( Kx[i] ))
		{
		ip = BildV.Y( Kx[i] );
		ZrC->Pen->Color = (i==0) ? clBlack : clSilver;
		ZrC->MoveTo( 0, ip);
		ZrC->LineTo( ZrIm->Width, ip );
		if ( zrdSL != NULL )
			{
			yd = BildV.Yd( Kx[i] );
			xd = 0;
			xt = ZrIm->Width;
			zrdSL->Add("Y  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  "+FormatFloat("000000.000",xt)+";  "+FormatFloat("000000.000",yd)+";  &H"+IntToHex(ZrC->Pen->Color,6)+";");
			}
		}
	}
ZrC->Font->Name = "Arial";
ZrC->Font->Size = FontSize;                    			// Schriftgr��e in Pixel
ZrC->Font->Pitch = fpFixed;
ZrC->Font->Color = clBlue;
ZrC->Brush->Style = bsClear;
for ( i=1; i< 50; i++ )								// Divs Zeichnen
	{
	ip = BildX.DivX( i );
	if ( BildX.isinside( ip ) )
		{
		ZrC->MoveTo(ip,0);
		ZrC->LineTo(ip,ZrIm->Height);
		ZrC->TextOut(ip+1,ZrIm->Height-8-FontSize,IntToStr(BildX.DivI( i )));
		if ( zrdSL != NULL )
			{
			yd = 0;
			xd = BildX.Id(ip);
			yt = ZrIm->Height;
			xt = ip;
			zrdSL->Add("X  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  "+FormatFloat("000000.000",xt)+";  "+FormatFloat("000000.000",yt)+";  &H"+IntToHex(ZrC->Pen->Color,6)+";  "+IntToStr(BildX.DivI( i ))+";");
			}
		}
	else
		break;
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::TpMouseMove( Word Key )
{
if ( SofortRechnenCb->Checked )
	{
	Params = DCWd->AktivesFenster->Params;
	if (( Key == comTestpoint ) & ( TpQuelleCb->ItemIndex < 1 ))
		Zeichnen(NULL);
	if (( Key == comRefpoint ) & ( TpQuelleCb->ItemIndex == 1 ))
		Zeichnen(NULL);
	if (( Key == isMouseMove ) & ( TpQuelleCb->ItemIndex == 2 ))
		{
		Zeichnen(NULL);
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZeichnenTbClick(TObject *Sender)
{

Params = DCWd->AktivesFenster->Params;
if ( TpQuelleCb->ItemIndex < 1 )
	{
	CursorXbi = Params.tpx;
	CursorYbi = Params.tpy;
	}
if ( TpQuelleCb->ItemIndex == 1 )
	{
	CursorXbi = Params.refpx;
	CursorYbi = Params.refpy;
	}
Zeichnen(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZeichnenDot(int zi, int y, bigint *biy, TColor c)
{
double	xd,yd;
int		x;

x = xd = BildX.Id( zi );
if ( zrdSL != NULL )
	{
	yd = BildV.Yd( biy );
	zrdSL->Add("P  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  &H"+IntToHex(c,6)+";  ");
	}
ZrC->Pixels[x][y] = c;
ZrC->Pixels[x][y+1] = c;
x++;
ZrC->Pixels[x][y] = c;
ZrC->Pixels[x][y+1] = c;
}
//---------------------------------------------------------------------------


void __fastcall TZeitRWd::Zeichnen(TObject *Sender)
{
bigint	b0,b1,mzb;
int		i0,i1,mzi;
IStatus is;
int		y,x,yX,xX,yY,xY;
bool	dm;					// Differenz-Mode
double	yd,xd;

dm = false;
if ( DiffRefCb->Checked ) dm = true;
b1 = BildV.VTop;
b0 = BildV.VBottom;
if ( ObenGrenzeEd->Modified )
	b1.str2bigint( ObenGrenzeEd);
if ( UntenGrenzeEd->Modified )
	b0.str2bigint( UntenGrenzeEd);
if ( b0 >= b1 ) return;
	BildV.SetMax( &b1 );
	BildV.SetMin( &b0 );
VsizeEd->Text = L"~ " + FloatToStrF( (long double)(b1 - b0), ffExponent, 9, 5 );
i0 = ( IterAbEd->Modified )?IterAbEd->Value:BildX.Xleft;
i1 = ( IterBisEd->Modified )?IterBisEd->Value:BildX.Xright;
if ( i0 < i1 )
	BildX.SetMinMax ( i0, i1 );
else
	{
	IterAbEd->Value = i0;
	IterBisEd->Value = i1;
	}
IterAbEd->LineSize = BildX.IterPdiv;
IterBisEd->LineSize = BildX.IterPdiv;
PaintNow(Sender);

bii = new Apfelmaennchen;
if (dm) Refii = new Apfelmaennchen;
if ( BildX.IAbstand > 2 )
	{
Params.VorlaufIter = i0;              			// nun Verlauf (Linien) zeichnen
Params.MaxIter = i1;
bii->SetParam( &Params );
if (dm) Refii->SetParam( &Params );
if (Params.Mmode == 0 )
	{
			is =   bii->iterate_start(Params.jpy,Params.jpx,CursorYbi,      CursorXbi,  Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.jpy,Params.jpx,Params.refpy,Params.refpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
if ( Params.Mmode == 1 )
	{
			is =   bii->iterate_start(Params.tpy,  Params.tpx,  Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.refpy,Params.refpx,Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
is = bii->iterate_PreRun( i0 + StartXteEd->Value);
if (dm) Refii->iterate_PreRun( i0 + StartXteEd->Value);
x = xX = yX = BildX.I( bii->zi );
y = BildV.Y( &(bii->za) );
yX = BildV.Y( &(bii->ex) );
yY = BildV.Y( &(bii->ey) );
ZrC->Pen->Color = 0x00101010;

do {                                         				// Iter-Schleife
	is = bii->iterate_run(RepXteEd->Value);
	if (dm) Refii->iterate_run(RepXteEd->Value);
	if ( mitRCb->Checked )
		{
		ZrC->MoveTo( x,y );
		x = BildX.I( bii->zi );
		if (dm) bii->za -= Refii->za;
		y = BildV.Y( &(bii->za) );
		ZrC->LineTo( x, y );
		}
	if ( mitXCb->Checked )
		{
		ZrC->MoveTo( xX,yX );
		xX = BildX.I( bii->zi );
		if (dm) bii->ex -= Refii->ex;
		yX = BildV.Y( &(bii->ex) );                   //BildV.Y( &(bii->ex) );
		ZrC->LineTo( xX, yX );
		}
	if ( mitYCb->Checked )
		{
		ZrC->MoveTo( xY,yY );
		xY = BildX.I( bii->zi );
		if (dm) bii->ey -= Refii->ey;
		yY = BildV.Y( &(bii->ey) );
		ZrC->LineTo( xY, yY );
		}
	} while ( (is == inside) && (bii->itercount < i1) );
	}                                                     // Verlauf Zeichnen ende

Params.VorlaufIter = i0;								// Nun Punkte zeichnen
Params.MaxIter = i1;
mzb = 1000;
bii->SetParam( &Params );
if (dm) Refii->SetParam( &Params );
if (Params.Mmode == 0 )
	{
			is =   bii->iterate_start(Params.jpy,Params.jpx,CursorYbi,      CursorXbi,  Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.jpy,Params.jpx,Params.refpy,Params.refpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
if ( Params.Mmode == 1 )
	{
			is =   bii->iterate_start(Params.tpy,  Params.tpx,  Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.refpy,Params.refpx,Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
is = bii->iterate_PreRun( i0 + StartXteEd->Value);
if (dm) Refii->iterate_PreRun( i0 + StartXteEd->Value);
do {                                         				// Iter-Schleife , Punkte zeichnen
	is = bii->iterate_run(RepXteEd->Value);
	if (bii->za < mzb )
		{                                                                                         /* TODO : Minz funkt nicht wenn nur von..bis iteriert wird */
		mzb = bii->za;										// Min Z suchen
		mzi = bii->zi;
		PaintIterLine( mzi, clMoneyGreen, true );
        }
	if (dm) Refii->iterate_run(RepXteEd->Value);
	x = bii->zi;
	if ( mitRCb->Checked )
		{
		if (dm) bii->za -= Refii->za;
		y = BildV.Y( &(bii->za) );
		ZeichnenDot( x, y, &(bii->za), clBlack );
		}
	if ( mitXCb->Checked )
		{
		if (dm) bii->ex -= Refii->ex;
		y = BildV.Y( &(bii->ex) );
		ZeichnenDot( x, y, &(bii->ex), clRed );
		}
	if ( mitYCb->Checked )
		{
		if (dm) bii->ey -= Refii->ey;
		y = BildV.Y( &(bii->ey) );
		ZeichnenDot( x, y, &(bii->ey), clPurple );
		}
	} while ( (is == inside) && (bii->itercount < i1) );
LastMaxIter = bii->itercount;
if ( is == outside )
	PaintIterLine( bii->itercount, clRed, true );
MinzEd->Text = IntToStr( mzi );
	PaintIterLine( mzi, clGreen, true );

delete bii;
if (dm) delete Refii;
PreImageBitmap->Assign( ZrIm->Picture->Bitmap );
if (IterTestLineCb->Checked) PaintIterLine( IterTestLinie, clFuchsia, false );
}
//---------------------------------------------------------------------------

bool __fastcall TZeitRWd::zrdSpeichern()
{
zrdSL = new TStringList();

zrdSL->Add("   ZeitReihenDaten");
zrdSL->Add("T  Mess-Obergrenze:   " + ObenGrenzeEd->Text);
zrdSL->Add("T  Mess-Untergrenze:  " + UntenGrenzeEd->Text);
Params.tpx.bigint2str(HelpEd,false);
zrdSL->Add("T  Real(X):  		  " + HelpEd->Text);
Params.tpy.bigint2str(HelpEd,false);
zrdSL->Add("T  Imagin�r(Y): 	  " + HelpEd->Text);
//zrdSL->Add("B  "+FormatFloat("000000.000",ZrIm->Width)+";  "+FormatFloat("000000.000",ZrIm->Height)+";  &H"+IntToHex(ImagPl->Color,6)+";  ");
Zeichnen(NULL);
zrdSL->SaveToFile("D:\\Test\\zr.zrd");
delete zrdSL;
zrdSL = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormResize(TObject *Sender)
{

ZrIm->Picture->Bitmap->Width = ZrIm->Width;
ZrIm->Picture->Bitmap->Height = ZrIm->Height;
PreImageBitmap->Height = ZrIm->Height;
PreImageBitmap->Width = ZrIm->Width;

BildV.SetHeight( ZrIm->Height );
BildX.SetWidth( ZrIm->Width );
IterAbEd->LineSize = BildX.IterPdiv;
IterBisEd->LineSize = BildX.IterPdiv;
zoomrahmen.Left = 0;
if ( zoomrahmen.Top > ZrIm->Height ) zoomrahmen.Top = 0;
if ( zoomrahmen.Bottom > ZrIm->Height ) zoomrahmen.Bottom = ZrIm->Height;
zoomrahmen.Right = ZrIm->Width;
PaintNow(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZrImMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{

if ( Button == mbLeft )
	{
	zoomrahmen.Top = Y;
	zoomrahmen.Bottom = Y;
	zoomrahmen.Left = X;
	zoomrahmen.Right = X;
	PaintZoom( zoomrahmen );
	}
if ( Button == mbRight )
	{
	IterTestLinie = BildX.Ivon(X);
	PaintIterLine( IterTestLinie, clFuchsia, false );
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZrImMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift,  int X, int Y)
{
int		x,y;

if ( Button == mbLeft )
	{
	zoomrahmen.Bottom = Y;
	zoomrahmen.Right = X;
	if ( zoomrahmen.Top > zoomrahmen.Bottom )
		{
		y = zoomrahmen.Top;
		zoomrahmen.Top = zoomrahmen.Bottom;
		zoomrahmen.Bottom = y;
		}
	if ( zoomrahmen.Left > zoomrahmen.Right )
		{
		x = zoomrahmen.Left;
		zoomrahmen.Left = zoomrahmen.Right;
		zoomrahmen.Right = x;
		}
	PaintZoom( zoomrahmen );
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZrImMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{

DCWd->CPosXEd->Text = IntToStr(X);
DCWd->CPosYEd->Text = IntToStr(Y);
DCWd->FensterEd->Text = L"Zeitreihe";
IterNrEd->Text = IntToStr( BildX.Ivon(X) ) + "..." + IntToStr( BildX.Ibis(X) );
Diffmml->Text = IntToStr( BildX.Ivon(X)-IterTestLinie ) + "..." + IntToStr( BildX.Ibis(X)-IterTestLinie );
DCWd->ErgebnisEd->Text = IterNrEd->Text;
BildV.Y(Y).bigint2str(MessLinieEd,false);
DCWd->REd->Text = L"~ " + FloatToStrF( (long double)(BildV.Y(Y)), ffExponent, 9, 5 );
//MessLinieEd->Repaint();
if ( Shift.Contains(ssLeft) )
	{
	ZrIm->Picture->Bitmap->Assign( PreImageBitmap );
	zoomrahmen.Bottom = Y;
	zoomrahmen.Right = X;
	PaintZoom( zoomrahmen );
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)

{
int		i,ix,iy;
int		*x,*y;
int	  	bn = 0;

}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::PaintZoom( TRect zr )
{

ZrIm->Picture->Bitmap->Assign( PreImageBitmap );
ZrC->Pen->Color = clBlue;
ZrC->Pen->Style = psSolid;
ZrC->Brush->Style = bsClear;
ZrC->Rectangle(zr);
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::SpinBtnClick(TObject *Sender)
{

(( TLMDSpinEdit* )Sender)->Modified = true;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::PaintIterLine( int x, TColor c, bool f )
{
int		bx;
double	xd,yd,xt,yt;

if (!f) ZrIm->Picture->Bitmap->Assign( PreImageBitmap );
bx = BildX.I( x );
ZrC->Pen->Color = c;
ZrC->Pen->Style = psDot;
//ZrC->Brush->Color = clBlack;
ZrC->MoveTo( bx, ZrIm->Height );
ZrC->LineTo( bx, 0 );
ZrC->Font->Color = c;
ZrC->TextOut( bx+2,15,IntToStr( x ));
if ( zrdSL != NULL )
	{
	yd = 0;
	xd = BildX.Id( x );;
	yt = ZrIm->Height;
	xt = BildX.Id( x );;
	zrdSL->Add("M  "+FormatFloat("000000.000",xd)+";  "+FormatFloat("000000.000",yd)+";  "+FormatFloat("000000.000",xt)+";  "+FormatFloat("000000.000",yt)+";  &H"+IntToHex(c,6)+";  "+IntToStr( x )+"; ");
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::ZoomInVTbClick(TObject *Sender)
{
int		i0,i1;
IStatus is;
int		y,x;
bigint	min,max,mgo,mgu;
bool	dm,oi,in;					// Differenz-Mode , Zoom out oder in

dm = false;
if ( DiffRefCb->Checked ) dm = true;
oi = (((TToolButton * )Sender)->Tag == 2 );
i0 = BildX.Ivon( zoomrahmen.Left );
i1 = BildX.Ibis( zoomrahmen.Right );
mgo = BildV.P( zoomrahmen.top );
mgu = BildV.P( zoomrahmen.Bottom );
max = -200000000;
min = 200000000;

Params = DCWd->AktivesFenster->Params;
Params.MaxIter = i1;
bii = new Apfelmaennchen;
if (dm) Refii = new Apfelmaennchen;
bii->SetParam( &Params );
if (dm) Refii->SetParam( &Params );
if (Params.Mmode == 0 )
	{
			is =   bii->iterate_start(Params.jpy,Params.jpx,Params.tpy,  Params.tpx,  Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.jpy,Params.jpx,Params.refpy,Params.refpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
if ( Params.Mmode == 1 )
	{
			is =   bii->iterate_start(Params.tpy,  Params.tpx,  Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	if (dm) is = Refii->iterate_start(Params.refpy,Params.refpx,Params.jpy,Params.jpx,Params.MaxIter,Params.MaxRadius, Params.EmodeNr, Params.EmodeZusatz );
	}
is = bii->iterate_PreRun( i0 );
if (dm) Refii->iterate_PreRun( i0 );
do {                                         	// Iter-Schleife
	is = bii->iterate_run(RepXteEd->Value);
	if (dm) is = Refii->iterate_run(RepXteEd->Value);
	if ( mitRCb->Checked )
		{
		if (dm) bii->za -= Refii->za;
		in = (( bii->za > mgu ) & ( bii->za < mgo ));
		if (oi) in = !in;
		if (in)
			{
			if ( bii->za < min ) min = bii->za;
			if ( bii->za > max ) max = bii->za;
			}
		}
	if ( mitXCb->Checked )
		{
		if (dm) bii->ex -= Refii->ex;
		in = (( bii->ex > mgu ) & ( bii->ex < mgo ));
		if (oi) in = !in;
		if (in)
			{
			if ( bii->ex < min ) min = bii->ex;
			if ( bii->ex > max ) max = bii->ex;
			}
		}
	if ( mitYCb->Checked )
		{
		if (dm) bii->ey -= Refii->ey;
		in = (( bii->ey > mgu ) & ( bii->ey < mgo ));
		if (oi) in = !in;
		if (in)
			{
			if ( bii->ey < min ) min = bii->ey;
			if ( bii->ey > max ) max = bii->ey;
			}
		}
	} while ( (is == inside) && (bii->itercount < i1) );
delete bii;
delete Refii;

mgo = max;
mgo -= min;
mgo /= 10;
max += mgo;						// damit Punkte nicht am oberen oder unterem Rand kleben
min -= mgo;
BildV.SetMax( &max );
BildV.SetMin( &min );
BildV.VTop.bigint2str(ObenGrenzeEd,false);
BildV.VBottom.bigint2str(UntenGrenzeEd,false);
VsizeEd->Text = L"~ " + FloatToStrF( (long double)(max - min), ffExponent, 9, 5 );
ZeichnenTbClick( Sender );
}
//---------------------------------------------------------------------------


void __fastcall TZeitRWd::ZoomInHTbClick(TObject *Sender)
{
int		l,r;

l = BildX.Ivon( zoomrahmen.Left );
r = BildX.Ivon( zoomrahmen.Right );
IterAbEd->Value = l;
IterBisEd->Value = r;
IterAbEd->Modified = true;
IterBisEd->Modified = true;
ZeichnenTbClick( Sender );
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::PvTbClick(TObject *Sender)
{

IterAbEd->Value = 0;
IterBisEd->Value = LastMaxIter + 20;
IterAbEd->Modified = true;
IterBisEd->Modified = true;
K2.bigint2str(ObenGrenzeEd,false);
Km01.bigint2str(UntenGrenzeEd,false);
ObenGrenzeEd->Modified = true;
UntenGrenzeEd->Modified = true;
ZeichnenTbClick( Sender );
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormKeyPress(TObject *Sender, wchar_t &Key)
{
WORD	w;

if ( Key < L'0' | Key > L'9' )
	{
	w = Key;
	FormKeyNow( w );
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::FormKeyNow( WORD &Key )
{

CommandKD( Key );

switch ( Key )
	{
	case menDatei:      Statusp1->Text = "Datei";
						CommandKD = &DateiKeyDown;
						break;
	}
switch ( Key )
	{
	case VK_ESCAPE:
	case VK_RETURN:		Statusp1->Text = "";
						CommandKD = &NoKeyDown;
						break;
	}

}
//---------------------------------------------------------------------------

void  TZeitRWd::NoKeyDown(WORD &Key){}
//---------------------------------------------------------------------------

void TZeitRWd::DateiKeyDown(WORD &Key)
{

switch ( Key )
	{
	case comSaveAs:		SpeichernAs( NULL );
						break;
	}

Key = VK_ESCAPE;
CommandKD = &NoKeyDown;
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::SpeichernAs(TObject *Sender)
{
int			iFileHandle,sel,pos;
bool		ok;
String		fn;

ok = false;
SaveDlg->Title = "DeepChaosV2 - " + Statusp0->Text;
SaveDlg->InitialDir = DCWd->BilderPfEd->Text;
if ( SaveDlg->Execute() )
	{
	pos = SaveDlg->FileName.Pos( "." );
	fn = SaveDlg->FileName.Delete( pos, 4 );
	if ( SaveDlg->FileName.Pos( ".bmp" ) > 2 ) sel = 1;
	if ( SaveDlg->FileName.Pos( ".jpg" ) > 2 ) sel = 2;
	if ( SaveDlg->FileName.Pos( ".prm" ) > 2 ) sel = 4;
	if ( SaveDlg->FileName.Pos( ".dcp" ) > 2 ) sel = 8;
	if ( SaveDlg->FileName.Pos( ".txt" ) > 2 ) sel = 16;
	if ( SaveDlg->FileName.Pos( ".zrd" ) > 2 ) sel = 32;
	if ( SaveDlg->FileName.Pos( ".all" ) > 2 )
		{
		sel = 0x0ff;
		if (!DirectoryExists(fn))
			{
			if (!CreateDir(fn))
				throw Exception("Verzeichnis " + fn + "kann nicht erstellt werden");
			}
		fn += fn.SubString( fn.LastDelimiter("\\"),99 );
		}
	if ( sel & 1 )													//-----------------  bmp
		{
		ZrIm->Picture->Bitmap->SaveToFile( fn + ".bmp" );
		ok = true;
		}
	if ( sel & 32 )													//-----------------  zrd
		{
		zrdSpeichern( );
		ok = true;
		}
	if ( ok ) Statusp2->Text = SaveDlg->FileName;
	}
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::SpeichernAlsMiClick(TObject *Sender)
{
SpeichernAs(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TZeitRWd::BeendenMiClick(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------

